package com.ice.config.editor;

import javax.swing.*;
import com.ice.config.ConfigureEditor;
import com.ice.config.ConfigPropertyChangeListener;

public abstract class ConfigureToggleEditor extends ConfigureEditor
implements  TogglePropertyChangeListener
{
    /** introduced jsalerno **/
    protected ToggleButtonChangeListener tbcl;

    public ConfigureToggleEditor(String str)
    {
		super( str );
    }

    protected void addToggleActionListener(
        ButtonGroup group,
        ConfigPropertyChangeListener listener)
    {
        tbcl = new ToggleButtonChangeListener(group, this, listener);
    }

    protected void removeToggleActionListener()
    {
        tbcl = null;
    }

    /**
     * Ok, the <code>ToggleButtonChangeListener</code> has fired off a change.
     * We are a <code>TogglePropertyChangeListener</code> and this is our interface impl.
     * We call our superclass function to fire off to inform all registered
     * <code>ConfigPropertyChangeListener</code>'s notification via that interafce's
     * <code>propertyModified</code> method.
     *
     */
    public void propertyChanged(ConfigPropertyChangeListener changeListener)
    {
        fireConfigChangeEvent(changeListener);
    }
}