package com.ice.config;

public class ConfiguratorTest
{
    public static void main(String[] args)
    {
        try
        {
    		Class class_app1 = Class.forName("com.ice.config.demo.DemoConfigurator2");
	    	Configurator app1 = (Configurator)class_app1.newInstance();
		    app1.initialize( args, "demo", "com.ice.config.demo.rsrcui");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            System.exit(1);
        }
    }
}