package com.ice.config.demo;

import com.ice.config.*;
import com.ice.pref.UserPrefs;
import com.ice.jcvsii.ResourceMgr;

/**
 * Title:        Netwxs
 * Description:  Internet Mobile Exchange
 * Copyright:    Copyright (c) Net:wxs Pty Ltd
 * Company:      Net:WxS Pty Ltd
 * @author Julian Salerno, julian@practica.com.au
 * @version 1.0
 */

public class DemoConfiguration2A extends DemoConfiguration1
{
    private static DemoConfiguration2A instance;
    protected static final String DEMO_2A_CONFIG_SPEC_NAME = "/com/ice/config/demo/demo2AConfigSpec.properties";

    //notice we have 2 here !!!!!
    public static final int DEMO_2A_NUM_CONTROLLERS = 1;

	protected UserPrefs	    defaultDemoPrefs2A;
    protected UserPrefs		demoPrefs2A;
    protected UserPrefs		demoSpec2A;
	protected String		demoPrefs2AFilename, demoPrefs2ADefaultsFilename;

    private ConfigurationController d2AController;
/*
    protected String getDemoSpecName()
    {
        return(DEMO_2A_CONFIG_SPEC_NAME);
    }
*/
	static
		{
		DemoConfiguration2A.instance = new DemoConfiguration2A("demo2A");
		}

	public static DemoConfiguration
	getInstance()
		{
		return DemoConfiguration2A.instance;
		}

    public DemoConfiguration2A(String name)
    {
        super(name);

        this.demoSpec2A = null;
        this.demoPrefs2A = null;
        this.defaultDemoPrefs2A = null;
    }

	protected int establishOSDistinctions()
    {
		int osType = super.establishOSDistinctions();
        switch(osType)
        {
            default:
    			this.demoPrefs2AFilename = "/com/ice/config/demo/demo2A.properties";
    			this.demoPrefs2ADefaultsFilename = "/com/ice/config/demo/demo2A_defaults.properties";
                break;
        }
        return(osType);
    }

    public void setPropertyPrefixes(String prefix)
    {
        super.setPropertyPrefixes(prefix);

		this.demoSpec2A.setPropertyPrefix(prefix);
		this.demoPrefs2A.setPropertyPrefix(prefix);
		this.defaultDemoPrefs2A.setPropertyPrefix(prefix);
    }

	public void initializePreferences( String prefix , String userHome)
    {
        super.initializePreferences(prefix, userHome);

        //the data
		this.defaultDemoPrefs2A = new UserPrefs( "Demo2A.DemoConfigDefaults", null );
        setUserHome(defaultDemoPrefs2A);

		this.demoPrefs2A = new UserPrefs( "Demo2A.DemoReleaseConfig", defaultDemoPrefs2A );
        setUserHome(demoPrefs2A);

		this.demoSpec2A = new UserPrefs( "Demo2A.DemoConfigSpec", null );
        setUserHome(demoSpec2A);

    }

    /**
     * Construct the software runtime conbfiguration controllers
     * @throws Exception if something goes drastically wrong
     */
    protected void constructConfigurationControllers() throws Exception
    {
        super.constructConfigurationControllers();

        ConfigurationController[] d2AConfigurationControllers =
            new ConfigurationController[DEMO_2A_NUM_CONTROLLERS];

        d2AConfigurationControllers[0] = d2AController =
            new DefaultConfigurationController(this.demoPrefs2A, this.demoSpec2A);

        copyIntoConfigurationControllers(d2AConfigurationControllers);
    }

	public String getDemoPrefs2AFilename(){return this.demoPrefs2AFilename;}
	public String getDemoPrefs2ADefaultsFilename(){return this.demoPrefs2ADefaultsFilename;}

    public void loadConfigurations(String loadMode, IncrementalBoundedRangeModel iModel)
    {
        super.loadConfigurations(loadMode, iModel);

        loadDemo2APreferences(loadMode);
        iModel.increment();
        if(DEBUG)
            demoPrefs.list(System.out);
    }

	public void loadDemo2APreferences(String loadMode)
    {
        loadPreferences(loadMode, this.demoPrefs2A, this.getDemoPrefs2AFilename());
        loadPreferences(loadMode, this.defaultDemoPrefs2A, this.getDemoPrefs2ADefaultsFilename());
    }

	public void loadConfigEditorSpecifications(String loadMode)
    {
        super.loadConfigEditorSpecifications(loadMode);

        loadConfigEditorSpecification(loadMode, DEMO_2A_CONFIG_SPEC_NAME, demoSpec2A);
    }

    public String getDialogTitle()
    {
        /**@todo: implement this com.ice.config.AbstractConfiguration abstract method*/
        return("Demo Configuration 2A");
    }

    /**
     * Return the number of controllers which this class will/has create(d)
     */
    public int getNumControllers()
    {
        int superCnt = super.getNumControllers();
        return(superCnt + DEMO_2A_NUM_CONTROLLERS);
    }


	public void savePreferences()
    {
        super.savePreferences();
        saveDemo2AProperties("demo software properties");
    }

	public synchronized void saveDemo2AProperties( String header )
    {
        storePreferencesToProperties(this.demoPrefs2A, this.getDemoPrefs2AFilename(), header);
    }

    protected void createActionEventDescriptor()
    {
        //get a handle to the resource manager so that we can look up the name to use
        ResourceMgr rmgr = ResourceMgr.getInstance();
        String menuItemName = rmgr.getUIString( "menu.configuration.edit.demo2A" );
        String shortcutKey = rmgr.getUIString( "menu.configuration.edit.demo2A.accelerator" );
        aed = new ActionEventDescriptor(menuItemName, shortcutKey, true);
    }

    public String getPropertyPrefix()
    {
        return("");
    }
}