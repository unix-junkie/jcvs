package com.ice.config.editor;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

import com.ice.config.*;
import com.ice.pref.*;
import com.ice.util.AWTUtilities;

public class ConfigComboEditor extends ConfigureEditor
//implements	FocusListener, ItemListener, ChangeListener
{
	protected JComboBox		combo;
    boolean editable;

    public ConfigComboEditor(boolean editable)
    {
		super( "Combo" );
        this.editable = editable;
    }
	public void
	edit( UserPrefs prefs, ConfigureSpec spec, ConfigPropertyChangeListener changeListener )
		{
		super.edit( prefs, spec, changeListener );

		this.combo.setModel
			( new DefaultComboBoxModel
				( spec.getChoices() ) );

        setUIValue(prefs, spec);
        /*
        ok, we need to get our list from the ListProviderChangeListener interface
        ListProviderChangeListener lpcl = (ListProviderChangeListener)changeListener;
        String[] comboItems = lpcl.getListArray();
        */
		}

    public void requestInitialFocus()
    {
        /**@todo: implement this com.ice.config.ConfigureEditor abstract method*/
    }
	public void
	saveChanges( UserPrefs prefs, ConfigureSpec spec )
		{
        setPrefsValue(prefs, spec);
		}
/*
	public void
	undoChanges( UserPrefs prefs, ConfigureSpec spec )
		{
        setUIValue(prefs, spec);
        setPrefsValue(prefs, spec);
/*
		String propName = spec.getPropertyName();

		String oldVal = prefs.getProperty( propName, "" );
		String newVal = (String)this.combo.getSelectedItem();

		if ( ! newVal.equals( oldVal ) )
			{
			prefs.setProperty( propName, oldVal );

			this.combo.setSelectedItem( oldVal );
			}
*
    	}
*/
    protected void addListeners(ConfigPropertyChangeListener listener)
    {
        addItemListener(combo, listener);

        if(editable)
            this.combo.setEditable(true);
        if(combo.isEditable())
        {
            for(int i = 0; i < combo.getComponentCount(); i++)
            {
                Component c = combo.getComponent(i);
                if(c instanceof JTextField)
                {
                    addKeyListener(c, listener);
                    break;
                }
            }
        }
    }

	protected JPanel
	createEditPanel()
		{
		JPanel result = new JPanel();
		result.setLayout( new GridBagLayout() );
		result.setBorder( new EmptyBorder( 5, 3, 3, 3 ) );

		int col = 0;
		int row = 0;
/*
		JLabel lbl = new JLabel( "Selection" );
		lbl.setBorder( new EmptyBorder( 1, 3, 1, 3 ) );
		AWTUtilities.constrain(
			result, lbl,
			GridBagConstraints.NONE,
			GridBagConstraints.WEST,
			col++, row, 1, 1, 0.0, 0.0 );
*/
		this.combo = new JComboBox();
        this.combo.setFont(this.getFont());

//		this.strField = new JTextField( "" );
		AWTUtilities.constrain(
			result, this.combo,
			GridBagConstraints.HORIZONTAL,
			GridBagConstraints.WEST,
			0, row++, 1, 1,  1.0, 0.0,
			new Insets( 3, 0, 0, 0 ) );
//		this.combo.addItemListener( this );
//		this.combo.addFocusListener( this );
/*
		AWTUtilities.constrain(
			result, this.combo,
			GridBagConstraints.HORIZONTAL,
			GridBagConstraints.WEST,
			col++, row++, 1, 1,  1.0, 0.0 );
*/
/*
		col = 0;
		lbl = new JLabel( "Size" );
		lbl.setBorder( new EmptyBorder( 1, 3, 1, 3 ) );
		AWTUtilities.constrain(
			result, lbl,
			GridBagConstraints.NONE,
			GridBagConstraints.WEST,
			col++, row, 1, 1, 0.0, 0.0 );

		this.sizeField = new JTextField( "0" );
		this.sizeField.addFocusListener( this );
		AWTUtilities.constrain(
			result, this.sizeField,
			GridBagConstraints.HORIZONTAL,
			GridBagConstraints.WEST,
			col++, row++, 1, 1, 1.0, 0.0 );

		col = 0;

		JPanel chkPan = new JPanel();
		chkPan.setLayout( new GridBagLayout() );
		chkPan.setBorder( new EmptyBorder( 5, 5, 5, 5 ) );
		AWTUtilities.constrain(
			result, chkPan,
			GridBagConstraints.HORIZONTAL,
			GridBagConstraints.CENTER,
			0, row++, 2, 1, 1.0, 0.0 );

		this.boldCheck = new JCheckBox( "Bold" );
		this.boldCheck.addFocusListener( this );
		this.boldCheck.addChangeListener( this );
		this.boldCheck.setHorizontalAlignment( SwingConstants.CENTER );

		this.italicCheck = new JCheckBox( "Italic" )
			{
			public Component
			getNextFocusableComponent()
				{ return combo; }
			};
		this.italicCheck.addFocusListener( this );
		this.italicCheck.addChangeListener( this );
		this.italicCheck.setHorizontalAlignment( SwingConstants.CENTER );

		AWTUtilities.constrain(
			chkPan, this.boldCheck,
			GridBagConstraints.NONE,
			GridBagConstraints.CENTER,
			0, 0, 1, 1, 0.5, 0.0 );

		AWTUtilities.constrain(
			chkPan, this.italicCheck,
			GridBagConstraints.NONE,
			GridBagConstraints.CENTER,
			1, 0, 1, 1, 0.5, 0.0 );

		JPanel exPan = new JPanel();
		exPan.setLayout( new BorderLayout() );
		exPan.setBorder(
			new CompoundBorder(
				new EmptyBorder( 5, 5, 5, 5 ),
				new CompoundBorder(
					new EtchedBorder( EtchedBorder.RAISED ),
					new EmptyBorder( 5, 10, 5, 10 )
			) ) );

		this.exLabel = new JLabel( "Sample" );
		this.exLabel.setForeground( Color.black );
		this.exLabel.setHorizontalAlignment( SwingConstants.CENTER );

		exPan.add( "Center", this.exLabel );
		AWTUtilities.constrain(
			result, exPan,
			GridBagConstraints.HORIZONTAL,
			GridBagConstraints.CENTER,
			0, row++, 2, 1, 1.0, 0.0 );
*/
		return result;
		}

    /** EVENT MANAGEMENT **
	public void itemStateChanged( ItemEvent event )
    {
//		this.showConfiguredFont();
    }

	public void focusGained( FocusEvent event )
    {
//		this.showConfiguredFont();
    }

	public void focusLost( FocusEvent event )
    {
//		this.showConfiguredFont();
    }

	public void stateChanged( ChangeEvent event )
    {
//		this.showConfiguredFont();
    }
*/
    protected void setPrefsValue(UserPrefs prefs, ConfigureSpec spec)
    {
		String propName = spec.getPropertyName();

		String oldVal = prefs.getProperty( propName, "" );
		String newVal = (String)this.combo.getSelectedItem();

		if ( ! newVal.equals( oldVal ) )
			{
			prefs.setProperty( propName, newVal );
			}
    }

    protected void setUIValue(UserPrefs prefs, ConfigureSpec spec)
    {
        super.setUIValue(prefs, spec);

		String val = prefs.getProperty( spec.getPropertyName(), null );

		this.combo.setSelectedItem( val );
		this.combo.repaint( 50 );
		this.validate();

    }

	protected void disableComponent()
    {
        combo.setEnabled(false);
    }

	protected void enableComponent()
    {
        combo.setEnabled(true);
    }
}