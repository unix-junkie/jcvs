package com.ice.jcvsii;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.border.*;

import com.ice.config.*;
import com.ice.pref.UserPrefs;
import com.ice.pref.PrefsTuple;
import com.ice.pref.PrefsTupleTable;
import com.ice.util.AWTUtilities;
/**
 * This is an editor for OS exec commands
 *
 * @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
 * @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
 *
 * @version $Revision: 1.6 $
 */
public
class		ExecCommandEditor
extends		ConfigureEditor
implements	ActionListener, ItemListener
	{
	protected PrefsTupleTable	cmdTable;

	protected JTextField		cmdText;
	protected JTextField		envText;

	protected JComboBox			cmdBox;


	public
	ExecCommandEditor()
		{
		super( "Exec Commands" );
		this.descOffset = 10;
		}

	public void
	edit( UserPrefs prefs, ConfigureSpec spec, ConfigPropertyChangeListener changeListener )
		{
		super.edit( prefs, spec, changeListener );

		this.cmdTable = Config.getInstance().getExecCmdDefinitions();

		this.cmdBox.setModel
			( new DefaultComboBoxModel
				( this.cmdTable.getKeyOrder() ) );

		this.cmdBox.setSelectedItem( null );
		this.cmdBox.repaint( 50 );
		this.validate();
		}

	public void
	saveChanges( UserPrefs prefs, ConfigureSpec spec )
		{
		this.saveCurrentCommand
			( (String) this.cmdBox.getSelectedItem() );
		String propName = spec.getPropertyName();
		prefs.setTupleTable( propName, this.cmdTable );
		}

	public void
	undoChanges( UserPrefs prefs, ConfigureSpec spec ){}

	// REVIEW I'll bet we can think of a way to move this up a level...
	public void
	commitChanges( ConfigureSpec spec, UserPrefs prefs, UserPrefs orig )
		{
		String propName = spec.getPropertyName();

		PrefsTupleTable table =
			prefs.getTupleTable( propName, null );

		orig.removeTupleTable( propName );

		if ( table != null )
			{
			orig.setTupleTable( propName, table );
			}

		Config.getInstance().loadExecCmdDefinitions();
		}

	public boolean
	isModified( ConfigureSpec spec, UserPrefs prefs, UserPrefs orig )
		{
		String propName = spec.getPropertyName();

		PrefsTupleTable nt =
			prefs.getTupleTable( propName, null );

		PrefsTupleTable ot =
			orig.getTupleTable( propName, null );

		if ( nt != null && ot != null )
			{
			if ( ! nt.equals( ot ) )
				{
				return true;
				}
			}
		else if ( nt != null || ot != null )
			{
			return true;
			}

		return false;
		}

	public void
	requestInitialFocus()
		{
		this.cmdBox.requestFocus();
		}

	public void
	saveCurrentCommand( String extVerb )
		{
		if ( extVerb != null )
			{
			String cmd = this.cmdText.getText();
			String env = this.envText.getText();

			String[] vals = new String[2];
			vals[ Config.EXEC_DEF_ENV_IDX ] = env;
			vals[ Config.EXEC_DEF_CMD_IDX ] = cmd;

			PrefsTuple tup = new PrefsTuple( extVerb, vals );

			this.cmdTable.putTuple( tup );
			}
		}

	public void
	newCommand()
		{
		String extVerb = null;

		for ( ; ; )
			{
			extVerb =
				JOptionPane.showInputDialog
					( "Enter key: .ext.verb (e.g. .java.edit)" );

			if ( extVerb == null )
				break;

			if ( extVerb.indexOf( "." ) == -1 )
				{
				JOptionPane.showMessageDialog
					( null, "The key '" + extVerb + "' is not valid.\n" +
							"The format is '.ext.verb'.\n",
						"Invalid Key", JOptionPane.WARNING_MESSAGE );
				continue;
				}

			String[] tupVals = { "", "" };
			PrefsTuple newTuple = new PrefsTuple( extVerb, tupVals );

			boolean append = true;
			for ( int i = 0, sz = this.cmdTable.size() ; i < sz ; ++i )
				{
				PrefsTuple tup = this.cmdTable.getTupleAt(i);
				if ( extVerb.compareTo( tup.getKey() ) < 0 )
					{
					append = false;
					this.cmdTable.insertTupleAt( newTuple, i );
					break;
					}
				}

			if ( append )
				this.cmdTable.appendTuple( newTuple );

			this.cmdBox.setModel
				( new DefaultComboBoxModel
					( this.cmdTable.getKeyOrder() ) );

			this.cmdBox.setSelectedItem( extVerb );
			this.cmdBox.repaint( 500 );
			break;
			}
		}

	public void
	deleteCommand()
		{
		String extVerb =
			(String) this.cmdBox.getSelectedItem();

		if ( extVerb != null )
			{
			PrefsTuple tup = this.cmdTable.getTuple( extVerb );

			if ( tup != null )
				{
				this.cmdTable.removeTuple( tup );
				this.cmdBox.removeItem( extVerb );
				}
			}
		}

	public void
	actionPerformed( ActionEvent event )
		{
		String command = event.getActionCommand();

		if ( command.equals( "NEW" ) )
			{
			this.newCommand();
			}
		else if ( command.equals( "DEL" ) )
			{
			this.deleteCommand();
			}
		}

	public void
	itemStateChanged( ItemEvent evt )
		{
		int stateChg = evt.getStateChange();

		if ( stateChg == ItemEvent.SELECTED )
			{
			String key = (String) evt.getItem();
			PrefsTuple tup = this.cmdTable.getTuple( key );
			if ( tup != null )
				{
				this.cmdText.setText
					( tup.getValueAt( Config.EXEC_DEF_CMD_IDX ) );
				this.envText.setText
					( tup.getValueAt( Config.EXEC_DEF_ENV_IDX ) );
				}
			else
				{
				// UNDONE report this to the user?
				this.cmdText.setText( "" );
				this.envText.setText( "" );
				}
			}
		else if ( stateChg == ItemEvent.DESELECTED )
			{
			this.saveCurrentCommand( (String) evt.getItem() );
			this.cmdText.setText( "" );
			this.envText.setText( "" );
			}
		}

	protected JPanel
	createEditPanel()
		{
		JLabel lbl;

		JPanel result = new JPanel();
		result.setLayout( new GridBagLayout() );
		result.setBorder( new EmptyBorder( 5, 3, 3, 3 ) );

		int cols = 3;
		int row = 0;

		JButton btn = new JButton( "New..." );
		btn.addActionListener( this );
		btn.setActionCommand( "NEW" );
		AWTUtilities.constrain(
			result, btn,
			GridBagConstraints.NONE,
			GridBagConstraints.WEST,
			0, row, 1, 1, 0.0, 0.0,
			new Insets( 0, 7, 0, 10 ) );

		this.cmdBox = new JComboBox();
		this.cmdBox.addItemListener( this );
		AWTUtilities.constrain(
			result, this.cmdBox,
			GridBagConstraints.HORIZONTAL,
			GridBagConstraints.CENTER,
			1, row, 1, 1, 1.0, 0.0 );

		btn = new JButton( "Delete" );
		btn.addActionListener( this );
		btn.setActionCommand( "DEL" );
		AWTUtilities.constrain(
			result, btn,
			GridBagConstraints.NONE,
			GridBagConstraints.EAST,
			2, row++, 1, 1, 0.0, 0.0,
			new Insets( 0, 10, 0, 7 ) );

		lbl = new JLabel( "Command:" );
		AWTUtilities.constrain(
			result, lbl,
			GridBagConstraints.NONE,
			GridBagConstraints.WEST,
			0, row++, cols, 1, 0.0, 0.0,
			new Insets( 10, 0, 1, 0 ) );

		this.cmdText = new JTextField();
		AWTUtilities.constrain(
			result, this.cmdText,
			GridBagConstraints.HORIZONTAL,
			GridBagConstraints.WEST,
			0, row++, cols, 1, 1.0, 0.0 );

		lbl = new JLabel( "Environment:" );
		lbl.setBorder( new EmptyBorder( 1, 3, 1, 3 ) );
		AWTUtilities.constrain(
			result, lbl,
			GridBagConstraints.NONE,
			GridBagConstraints.WEST,
			0, row++, cols, 1, 0.0, 0.0,
			new Insets( 10, 0, 1, 0 ) );

		this.envText = new JTextField();
		AWTUtilities.constrain(
			result, this.envText,
			GridBagConstraints.HORIZONTAL,
			GridBagConstraints.WEST,
			0, row++, cols, 1, 1.0, 0.0 );

		return result;
		}

    protected void addListeners(ConfigPropertyChangeListener changeListener)
    {
        addItemListener(cmdBox, changeListener);
        addKeyListener(cmdText, changeListener);
	}

    protected void setPrefsValue(UserPrefs prefs, ConfigureSpec spec)
    {
    }

    protected void setUIValue(UserPrefs prefs, ConfigureSpec spec)
    {
        super.setUIValue(prefs, spec);

    }

	protected void disableComponent()
    {
	    cmdText.setEditable(false);
	    envText.setEditable(false);
	    cmdBox.setEditable(false);
    }

	protected void enableComponent()
    {
	    cmdText.setEditable(true);
	    envText.setEditable(true);
	    cmdBox.setEditable(true);
    }
}