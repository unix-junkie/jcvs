package com.ice.config;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import javax.swing.BoundedRangeModel;
import java.awt.Frame;
import java.awt.Dimension;
import java.awt.Point;
import java.io.IOException;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;

import com.ice.pref.*;
import com.ice.config.editor.*;
import com.ice.config.*;
import com.ice.jcvsii.ConfigConstants;
import com.ice.util.AWTUtilities;
import com.ice.util.ResourceUtilities;
import com.ice.util.TempFileManager;
/**
 * All configurations consist of a set of <code>ConfigurationController</code>'s.
 * Each Configuration is also regsitered with the main frame ui with an <code>ActionEventDescriptor</code>.
 * And each configuration is responsible for a single <code>ConfigurationDialog</code>.
 * A user-home attribute is used to locate the location of the .properties files.
 *
 * @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
 * @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
 *
 * @version $Revision: 1.19 $
 */
public abstract class AbstractConfiguration
implements Configuration
{
    protected static final int MAC_OS   =   0;
    protected static final int WINDOWS  =   1;
    protected static final int OS2      =   2;
    protected static final int SOLARIS  =   3;
    protected static final int UNIX     =   4;

    /** A local variable that we have been told about. Apply it to all of opur UserPrefs if not null **/
    protected String userHome;
    /** An array of controllers which we build upon during initialization **/
    protected ConfigurationController[] configurationControllers = new ConfigurationController[0];
    /** A bundle of information so that some UI can display a menu item to get to us **/
    protected ActionEventDescriptor aed;
    protected String name;
    protected boolean debug;
    protected ConfigurationDialog dlg;

    private boolean firstEdit = true;
    /**
     * Constructor
     * Sets DEBUG to true
     */
    public AbstractConfiguration(String name)
    {
        this.name = name;

        createActionEventDescriptor();
    }

    protected abstract void createActionEventDescriptor();

    public ActionEventDescriptor getActionEventDescriptor()
    {
        return(aed);
    }

    public String getName(){return(name);}
    /**
     * This is method which we can call to determine whether we need to bail out or not
     */
	public void checkCriticalProperties( MainFrame parent ) throws Exception
    {}

    /**
     * @return the dialog title we would like to show
     */
    public abstract String getDialogTitle();

    /**
     * @param set the DEBUG flag for this configuration instance.
     */
	public void
	setDebug( boolean DEBUG )
		{
		this.debug = DEBUG;
		}

    /**
     * Set the user home for UserPrefs properties used by this Configuration
     * @param the path to user-home
     */
    public void setUserHome(String userHome)
    {
        this.userHome = userHome;
    }

    /**
     * Set the user home for the specified UserPrefs according to the userHome attribute here
     * @param the <code>UserPrefs</code> instance you want to repoint
     */
    protected void setUserHome(UserPrefs prefs)
    {
        if(this.userHome != null)
        {
            prefs.setUserHome(userHome);
        }
    }

    /**
     * This method is where <code>UserPrefs</code> instances are created.
     * Default prefs are created first, then the instance user prefs, and then the edit specs.
     * @param the prefix to be used for property file lookups based upon prefixes
     */
	public void
	initializePreferences( String prefix )
		{
        initializePreferences(prefix, null);
        }

    /**
     * This method is where <code>UserPrefs</code> instances are created.
     * Default prefs are created first, then the instance user prefs, and then the edit specs.
     * Calls thru to <code>establishOSDistinctions()</code>.
     * @param the prefix to be used for property file lookups based upon prefixes
     * @param the user-home for the property files used by this <code>Configuration</code>
     */
	public void initializePreferences( String prefix , String userHome)
    {
		this.establishOSDistinctions();
    }

    /**
     * A method where we ascertain the names of the actual .properties files
     * for the given runtime environment.
     * @return the name of the OS
     */
	protected int establishOSDistinctions()
    {
        return(getPlatformId(getSystemNameToLowerCase()));
    }

	protected String getSystemNameToLowerCase()
    {
		String osName = System.getProperty( "os.name" );
		osName = osName.toLowerCase();
        return(osName);
    }

    /**
     * Returns the internal represenatation of the underlying operating system.
     * MAC_OS, WINBLOWS, LINUX, SOLARIS
     */
    protected int getPlatformId(String osName)
    {
		if ( osName.startsWith( "mac os" ) )
        {
            return(MAC_OS);
        }
		else if ( osName.startsWith( "windows" ) )
        {
            return(WINDOWS);
        }
		else if ( osName.startsWith( "os/2" ) )
        {
            return(OS2);
        }
		else if ( osName.startsWith( "solaris" ) )
        {
            return(SOLARIS);
        }
		else // we assume UNIX-style
        {
            return(UNIX);
        }
    }

    /**
     * Load the properties for use in creating UserPrefs
     * @param file load technique : FILE or STREAM
     * @param the <code>UserPrefs</code> instance
     * @param the url to the properties file
     */
	public synchronized void loadPreferences(String mode, UserPrefs thePrefs, String specURL)
    {
        if(mode.equalsIgnoreCase(UserPrefsConstants.STREAM_LOADER))
        {
            loadPrefsAsStream(thePrefs, specURL);
        }
        else if(mode.equalsIgnoreCase(UserPrefsConstants.FILE_LOADER))
        {
            loadPrefsAsFile(thePrefs, specURL);
        }
        else
        {
            //default to stream
            loadPrefsAsStream(thePrefs, specURL);
        }
    }

    /**
     * Load the properties file into UserPrefs with FILE api
     * @param the <code>UserPrefs</code> instance
     * @param the url to the properties file
     */
	protected synchronized void loadPrefsAsFile(UserPrefs thePrefs, String thePrefsFilename)
    {
		InputStream in = null;
        System.out.println(thePrefsFilename);
		File prefsF = new File( thePrefs.getUserHome(), thePrefsFilename );
		if ( ! prefsF.exists() )
        {
            if(DEBUG)
			    System.err.println( "No user preferences found at '" + prefsF.getPath() + "'" );
			return;
        }

		if ( ! prefsF.canRead() )
        {
            if(DEBUG)
			    System.err.println( "ERROR Can not read user preferences at '" + prefsF.getPath() + "'" );
			return;
        }

        //ok, so let's procedd to load the prefs
		try
        {
			UserPrefsStreamLoader loader = (UserPrefsStreamLoader)
				UserPrefsLoader.getLoader( UserPrefsConstants.STREAM_LOADER );

			in = new FileInputStream( prefsF );

			loader.setInputStream( in );
			loader.loadPreferences( thePrefs );

            if(DEBUG)
			    System.err.println( "Loaded user preferences as FILE from '" + prefsF.getPath() + "'" );
        }
		catch ( IOException ex )
        {
			ex.printStackTrace();
        }
		finally
        {
			if ( in != null )
				{
				try { in.close(); }
				catch ( IOException ex ) { }
            }
        }
    }

    /**
     * Edit this configuration in a dialog relative to the specified frame
     */
	public void editConfiguration( MainFrame mf ) throws Exception
    {
		this.editConfiguration( mf, null );
    }

    /**
     * Edit this configuration in a dialog relative to the specified frame
     * Construct an MVC pattern for each <code>UserPrefs</code> before displaying the dialog
     * @param relative to frame
     * @param showing the specified properties
     */
	public void editConfiguration( MainFrame mf, String[] editProps ) throws Exception
    {
        //before we edit the properties we need to create an MVC for each
        // M=UserPref, V=ConfigurationPanel, C=ConfigurationController
        if(firstEdit)
        {
            constructConfigurationControllers();
            //then add property change listeners so that we know when a configuration has
            //changed - this allows us to prompt the user for a confirmation on whether
            //he wants to save or discard the changes
            addPropertyChangeListeners();

            firstEdit = false;
        }
        //then we create a dialog to present the views
        if(dlg == null)
		    dlg = new ConfigurationDialog(mf, getDialogTitle(), configurationControllers );

		dlg.setSize( new Dimension( 700, 500 ) );
		Point location = AWTUtilities.computeDialogLocation( dlg );
		dlg.setLocation( location.x, location.y );
		if ( editProps != null && editProps.length > 0 )
        {
			dlg.editProperties( editProps );
        }

        //this call is blocking because we use a modal dialog
        //(but we're on a separate thread, so that's ok)
		dlg.setVisible( true );
        //we call show so that the window-contained resources are re-built
        //  (since dispose() garbage collects them)
//        dlg.show();
        //ok, the dialog was closed for the blocking call to continue
        close();
    }

    public void close()
    {
        //perform a final check on the current controller
        //(esp. since this can be a call made publically from an external class such as the MainFrame)
        dlg.checkSave();
        //dialog closed
		if ( dlg.getSaveClicked() )
        {
			this.savePreferences();
        }
    }

    /**
     * Add prop change listeners to each of the <code>ConfigurationControllers</code>
     * prefs held within this configuration.
     *
     */
    protected void addPropertyChangeListeners()
    {
    /*
        for ( int i = 0 ; i < configurationControllers.length ; ++i )
        {
            configurationControllers.
            this.userAppPrefs.addPropertyChangeListener( subs[i], this );
        }
        */
    }

    /**
     * Construct the class-specific configuration controllers
     * @throws IOException if something goes drastically wrong
     */
    protected abstract void constructConfigurationControllers() throws Exception;

    /**
     * This method is where prefs files are written out to the <b>original</b> .properties file
     * from which they were originally read.
     * <b>nb : this means all properties are written back to the file - so
     * make sure all files are successfully read in</b>.
     * This is different to the original config package functionality where only
     * changes to a config property were written to a global .properties file
     * (eg. "jcvsii.txt")
     * A call is mad einternally to get a handle to a file for the named .properties
     *  file before calling thru to the overloaded method.
     * Synchronized because we hold references to many properties.
     * @param the <code>UserPrefs</code> which contain the data
     * @param the file name for writing out to
     * @param the header to write
     */
	public synchronized void storePreferencesToProperties(UserPrefs thePrefs, String theFile, String header)
    {
        try
        {
            this.storePreferenceToProperties(
                getFile(thePrefs, theFile),
                thePrefs,
                header);
		}
        catch ( IOException ex )
        {
			ex.printStackTrace();
        }
    }

    /**
     * This method is where prefs files are written out to the <b>original</b> .properties file
     * from which they were originally read.
     * <b>nb : this means all properties are written back to the file - so
     * make sure all files are successfully read in</b>.
     * This is different to the original config package functionality where only
     * changes to a config property were written to a global .properties file
     * (eg. "jcvsii.txt").
     * Synchronized because we hold references to many properties.
     * @param the <code>File</code> to be written
     * @param the <code>UserPrefs</code> which contain the data
     * @param the header to write
     */
	protected synchronized void storePreferenceToProperties( File file, UserPrefs prefs, String header )
    {
        try
        {
			UserPrefsFileLoader loader = (UserPrefsFileLoader)
				UserPrefsLoader.getLoader( UserPrefsConstants.FILE_LOADER );

			loader.setFile( file );
			loader.storePreferences( prefs );
        }
		catch ( IOException ex )
			{
			ex.printStackTrace();
			}
    }

    /**
     * @param a <code>UserPrefs</code> instance
     * @param a .properties filename
     * @return a <code>File</code> which repreents the .properties file which
     *  defines the <code>UserPrefs</code> with the given filename
     * @throws IOException when something IO goes wrong
     */
	public synchronized File getFile(UserPrefs thePrefs, String propsFilename) throws IOException
    {
		File prefsF =
			new File( thePrefs.getUserHome(), propsFilename );

		if ( ! prefsF.exists() )
			{
            if(DEBUG)
			    System.err.println(
                    "No user preferences found at '"
					+ prefsF.getPath() + "'" );
			throw new IOException("No user preferences found at '"
					+ prefsF.getPath() + "'");
			}

		if ( ! prefsF.canRead() )
			{
            if(DEBUG)
			    System.err.println
				( "ERROR Can not read user preferences at '"
					+ prefsF.getPath() + "'" );
			throw new IOException("ERROR Can not read user preferences at '"
					+ prefsF.getPath() + "'" );
			}

        return(prefsF);
    }

    /**
     * @param a <code>UserPrefs</code> instance
     * @param a .properties filename
     * @return an output stream which pipes to the .properties file which
     * defines the <code>UserPrefs</code> with the given filename
     * @throws IOException when something IO goes wrong
     */
	public OutputStream getFileOutputStream(UserPrefs thePrefs, String propsFilename) throws IOException
    {
        return(new FileOutputStream( getFile(thePrefs, propsFilename) ));
    }

    /**
     * Load the properties for the editor config specification
     * @param the file-load-mode (FILE or STREAM)
     * @param the url to the file
     * @param the destination <code>UserPrefs</code>
     */
	public void loadConfigEditorSpecification(String mode, String specURL, UserPrefs theEditSpec)
    {
        if(mode.equalsIgnoreCase(UserPrefsConstants.STREAM_LOADER))
        {
            loadPrefsAsStream(theEditSpec, specURL);
        }
        else if(mode.equalsIgnoreCase(UserPrefsConstants.FILE_LOADER))
        {
            loadPrefsAsFile(theEditSpec, specURL);
        }
        else
        {
            //default to stream
            loadPrefsAsStream(theEditSpec, specURL);
        }
    }

    /**
     * Load the properties file into UserPrefs with STREAM api
     * @param the <code>UserPrefs</code> instance
     * @param the url to the properties file
     */
	public void loadPrefsAsStream(UserPrefs theEditSpec, String specURL)
    {
		InputStream in = null;

		try
        {
            String fullPath = theEditSpec.getUserHome();
			in = ResourceUtilities.openNamedResource( specURL );

			UserPrefsStreamLoader loader = (UserPrefsStreamLoader)
				UserPrefsLoader.getLoader( UserPrefsConstants.STREAM_LOADER );

			loader.setInputStream( in );
			loader.loadPreferences( theEditSpec );

            if(DEBUG)
			    System.err.println
				( "Loaded config editor specification as STREAM from '"
					+ specURL + "'" );
        }
		catch ( IOException ex )
        {
            if(DEBUG)
			    System.err.println
				( "ERROR loading editor specification from '"
					+ specURL + "'\n      " + ex.getMessage() );
        }
		finally
        {
			if ( in != null )
				{
				try { in.close(); }
				catch ( IOException ex ) { }
            }
        }
    }

    /**
     * Append the new controllers onto the already exisitng ones.
     * @param the new <code>ConfigurationController</code>'s
     */
    protected final void copyIntoConfigurationControllers(ConfigurationController[] newControllers)
    {
        int numControllersAlready = this.configurationControllers.length;
        int numNewControllers = newControllers.length;

        ConfigurationController[] newControllerList =
            new ConfigurationController[numControllersAlready + numNewControllers];

        System.arraycopy(this.configurationControllers, 0, newControllerList, 0, numControllersAlready);
        System.arraycopy(newControllers, 0, newControllerList, numControllersAlready, numNewControllers);

        this.configurationControllers = newControllerList;
	}
}