package com.ice.config.editor;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;
import java.util.*;

import javax.swing.*;
import javax.swing.border.*;

import com.ice.cvsc.CVSLog;
import com.ice.util.ResourceUtilities;
import com.ice.util.AWTUtilities;
import com.ice.pref.UserPrefs;
import com.ice.pref.PrefsTupleTable;
import com.ice.config.*;
import com.ice.jcvsii.ResourceMgr;

import javax.swing.event.*;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
/**
* Configuration Dialog for editing a <code>Configuration</code> which consists of a set of
*  <code>ConfigurationController</code>'s.
* This class replaces the <code>ConfigDialog</code>.
*
* @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
* @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
*
* @version $Revision: 1.25 $
*/
public
class		ConfigurationDialog
extends		JDialog
implements	ActionListener, TreeSelectionListener, ConfigPropertyChangeListener
{
    public static final boolean DEBUG = System.getProperty("debugDialog") != null;

	static public final String		RCS_ID = "$Id: ConfigurationDialog.java,v 1.25 2002/03/20 07:34:00 jsalerno Exp $";
	static public final String		RCS_REV = "$Revision: 1.25 $";

    private static final int SAVE = 0;
    private static final int NOSAVE = 1;
    private static final int CANCEL = 2;

	private boolean saveClicked;

	protected ConfigureTree			tree = null;
	protected JLabel		title = null;
	protected JPanel		editorPanel = null;
	protected JSplitPane	splitter = null;

	protected ConfigureTreeModel	model = null;

    private JPanel contentPanel;
    private ConfigurationController currentController;

    protected ConfigurationController[] configurationControllers;
    protected TreePath lastPath;
    protected boolean listenToTreeEvents = true;

    protected JButton saveBtn;
    protected JButton canBtn;
    protected JButton closeBtn;

    private MainFrame mainFrameParent;

	public
	ConfigurationDialog( MainFrame mf, String title, ConfigurationController[] configurationControllers )
    {
		super( mf.getFrame(), title, true );

        this.mainFrameParent = mf;

		this.saveClicked = false;
        this.configurationControllers = configurationControllers;

		Container content = this.getContentPane();
		content.setLayout( new BorderLayout() );
/*
        jsalerno 050801 : we now have an array of UserPrefs, so we need to
        create an array of ConfigurationPanels. The best place to store the
        reference to these panels is in the UserPref class as a
        <strong>transient</strong> reference.

        To achieve this, just create the ConfigurationPanel and let the panel
        tell its own UserPrefs that it is the view for the prefs.

        @see configureConfigPanels

		this.configPan = new ConfigurePanel( prefs, specs, factory );
		content.add( BorderLayout.CENTER, this.configPan );
*/
        //new by jsalerno 050801
        configureSpecsAndTree();//configurationControllers

        //build a ui
		JPanel buttons = new JPanel();
		buttons.setLayout( new GridLayout( 1, 2 ) );

		ResourceMgr rmgr = ResourceMgr.getInstance();

		saveBtn = new JButton( rmgr.getUIString( "name.for.save" ) );
		saveBtn.addActionListener( this );
		saveBtn.setActionCommand( "SAVE" );
		buttons.add( buttonPanel( saveBtn ) );

		canBtn = new JButton( rmgr.getUIString( "name.for.cancel" ) );
		canBtn.addActionListener( this );
		canBtn.setActionCommand( "CANCEL" );
		buttons.add( buttonPanel( canBtn ) );

        //initially nothing is changed
        disableSaveOptions();

		closeBtn = new JButton( rmgr.getUIString( "name.for.close" ) );
		closeBtn.addActionListener( this );
		closeBtn.setActionCommand( "CLOSE" );
		buttons.add( buttonPanel( closeBtn ) );

		JPanel butPan = new JPanel();
		butPan.setLayout( new BorderLayout() );
		butPan.add( "East", buttons );

		JPanel southPan = new JPanel();
		southPan.setLayout( new BorderLayout() );
		southPan.add( BorderLayout.NORTH, new JSeparator( SwingConstants.HORIZONTAL ) );
		southPan.add( BorderLayout.CENTER, butPan );

		content.add( BorderLayout.SOUTH, southPan );

		this.pack();

		this.addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent we)
            {
                checkSave(currentController, true);
            }
			public void windowActivated( WindowEvent evt )
            {
                setDividerLocation( 0.3 ); // UNDONE property this.
            }
        });
    }

    private void disableSaveOptions()
    {
        disableSaveButton();
        disableCancelButton();
    }

    private void enableSaveOptions()
    {
        enableSaveButton();
        enableCancelButton();
    }

    private void disableSaveButton(){disableButton(saveBtn);}
    private void enableSaveButton(){enableButton(saveBtn);}
    private void disableCancelButton(){disableButton(canBtn);}
    private void enableCancelButton(){enableButton(canBtn);}
    private void disableButton(AbstractButton btn){setButtonEnabled(btn, false);}
    private void enableButton(AbstractButton btn){setButtonEnabled(btn, true);}

    private void setButtonEnabled(AbstractButton btn, boolean enabled)
    {
        btn.setEnabled(enabled);
    }

    private void configureConfigPanels()
    {
        for(int i = 0; i < configurationControllers.length; i++)
        {
            new ConfigurationPanel(configurationControllers[i], tree, this);
        }
    }

    private void configureSpecsAndTree()
    {
        if(DEBUG)
            System.out.println("ConfigurationDialog.configureSpecsAndTree()");
		this.model = new ConfigureTreeModel();

        loadConfigSpecsIntoTree();

        //build the tree
		this.tree = new ConfigureTree( model );
		this.tree.addTreeSelectionListener( this );

        //new by jsalerno 050801
        configureConfigPanels();//configurationControllers

		JScrollPane treeScroller = new JScrollPane( this.tree );

		JPanel pan = new JPanel();
		pan.setLayout( new BorderLayout() );
		pan.setPreferredSize( new Dimension( 125, 225 ) );
		pan.add( BorderLayout.CENTER, treeScroller );

		this.editorPanel = new EditorPanel();
		this.editorPanel.setLayout( new BorderLayout() );
		this.editorPanel.setBorder( new EmptyBorder( 5, 5, 5, 5 ) );

		contentPanel = new JPanel();
		contentPanel.setLayout( new BorderLayout() );

		this.title = new JLabel( "Properties", JLabel.LEFT );
		this.title.setPreferredSize( new Dimension( 30, 30 ) );
		this.title.setBackground( new Color( 224, 224, 255 ) );
		this.title.setForeground( Color.black );
		this.title.setOpaque( true );
		this.title.setFont
			( new Font( this.getFont().getName(), Font.BOLD, 14 ) );
		this.title.setBorder
			( new CompoundBorder
				( new LineBorder( Color.black ),
					new EmptyBorder( 5, 5, 5, 5 ) ) );
		this.splitter =
			new JSplitPane
				( JSplitPane.HORIZONTAL_SPLIT,
					true, pan, contentPanel );

		this.splitter.setDividerSize( 5 );

		contentPanel.add( BorderLayout.NORTH, this.title );
		contentPanel.add( BorderLayout.CENTER, this.editorPanel );

		this.getContentPane().add( BorderLayout.CENTER, this.splitter );

        //then, get a ConfigurationPanel's EditorPanel reference, and place it
        //into the display
        initEditorPanel();

        //repaint eveeryting
        validate();

    }

    private void loadConfigSpecsIntoTree()
    {
        if(DEBUG)
            System.out.println("ConfigurationDialog.loadConfigSpecsIntoTree()");
        for(int i = 0; i < configurationControllers.length; i++)
        {
            configurationControllers[i].setConfigurationTreeModel(model);
            configurationControllers[i].insertSpecIntoConfigTree();
            if(DEBUG)
            {
                System.out.println(configurationControllers[i].getPrefsName() + " loaded into model " + model);
            }
        }
    }

    /**
     * Set up the controller and the editor
     */
    private void initEditorPanel()
    {
        currentController = configurationControllers[0];
        setConfigPanel();
    }

    /**
     * Set up the initial config panel display
     */
    private void setConfigPanel()
    {
        if(DEBUG)
            System.out.println("setConfigPanel = "+getCurrentConfigPanel());
        editorPanel.removeAll();
		editorPanel.add( BorderLayout.CENTER, getCurrentConfigPanel() );
    }

    /**
     * @return a ref to the current config panel ui
     */
    private ConfigurationPanel getCurrentConfigPanel()
    {
        ConfigurationPanel cp = currentController.getConfigurationPanel();
        return(cp);
    }

    /**
     * @return a ref to the current controller's user prefs working copy
     */
    private UserPrefs getCurrentUserPrefs()
    {
        return(currentController.getWorkingCopy());
    }

    /**
     * @return a ref to the current controller
     */
    public ConfigurationController getCurrentController()
    {
        return(currentController);
    }

    /**
     * @param the button to place
     * @return a new panel after placing the button
     */
	private JPanel
	buttonPanel( JButton button )
		{
		JPanel panel = new JPanel();
		panel.setBorder(new EmptyBorder(4, 4, 4, 4));
		panel.setLayout(new BorderLayout());
		panel.add("Center", button);
		return panel;
		}

    /**
     * Select for editing the property which carries the param name
     * @param the property name
     */
	public void
	editProperty( String prop )
		{
		this.currentController.editProperty( prop );
		}

    /**
     * Select for editing the properties which carry the param names
     * @param the property names
     */
	public void
	editProperties( String[] props )
		{
        if(DEBUG)
            System.out.println("ConfigurationDialog.editProperties(String[] props)");
		this.currentController.editProperties( props );
		}

    /**
     * Expand the tree in order to facilitate editing of the chosen path
     * @param path to the variable
     */
	public void
	editPath( String path )
		{
		String[] paths = { path };
		this.editPaths( paths );
		}

    /**
     * Expand the tree in order to facilitate editing of the chosen paths
     * @param paths to the variables
     */
	public void
	editPaths( String[] paths )
		{
		for ( int i = paths.length - 1 ; i >= 0 ; --i )
			{
			ConfigureTreeNode node =
				this.model.getPathNode( paths[ i ] );

			if ( node != null )
				{
				TreePath tPath = new TreePath( node.getPath() );
				this.tree.expandPath( tPath );
				if ( i == 0 )
					this.tree.setSelectionPath( tPath );
				}
			}
		}

    /**
     * The ActionListener interface
     * @param the event
     */
    public void
	actionPerformed( ActionEvent event )
		{
		boolean doExit = false;
		String command = event.getActionCommand();

		if ( command.equals( "SAVE" ) )
        {
            saveCurrentEdit();
            save(currentController);
        }
		else if ( command.equals( "CANCEL" ) )
        {
            saveCurrentEdit();
            cancel(currentController);
        }
		else if ( command.equals( "CLOSE" ) )
        {
            int response = checkSave(currentController, true);
            doExit = true;
        }

        //lastly, do we close the screen ?
		if ( doExit )
        {
			this.dispose();
        }
    }

	public boolean
	getSaveClicked()
		{
		return this.saveClicked;
		}

	public void
	setDividerLocation( double divPct )
		{
		this.splitter.setDividerLocation( divPct );
		}

	public String
	treePath( TreePath treePath )
		{
		ConfigureTreeNode node;
		Object[] list = treePath.getPath();
		StringBuffer path = new StringBuffer();

		for ( int i = 1 ; i < list.length ; i++ )
			{
			node = (ConfigureTreeNode) list[i];
			if ( i > 1 )
				path.append(".");
			path.append( node.getName() );
			}

		return path.toString();
		}

    private void saveCurrentEdit()
    {
        if(currentController != null)
            currentController.saveCurrentEdit();
    }

    private boolean resolveCurrentController(TreeSelectionEvent tse)
        throws Exception
    {
        //first, update our working copy of the prefs within the editor so that
        //any 'cached' changes are not lost. This simply makes a note of the current
        //node's edit status and new value(s) - it does not commit anything back to
        //the original prefs
        saveCurrentEdit();

        //We allow users to keep editing attributes within the context of the
        //current controller without forcing a save, BUT if the user selects a node
        //from another controller, then we must prompt whether to save the
        //changes [or not], or to cancel the navigation to the new node (and
        //hence reselect the node in the current controller which just lost focus).
        TreePath path = tse.getPath();
        String pathInTree = treePath(path);
        ConfigurationController newController = identifyControllerSelected(pathInTree);
        boolean isNewController = !(isSameController(newController));
        if(DEBUG)
            System.out.println("isNewController = "+isNewController);
        if(isNewController)
        {
            //So, see if we need to save anything first
            int saved = checkSave(currentController, false);
            //this will return JOptionPane.YES_OPTION by default, otherwise just look
            //  for usr cancellation out of the action
            if(saved == JOptionPane.CANCEL_OPTION)
            {
                //the user cancelled out....we must re-select the previously
                //selected path in the original controller
                setTreeListenerOff();
                //scroll to the visible path
                tree.scrollPathToVisible(lastPath);
                //start listening again
                setTreeListenerOn();
            }
            else
            {
                //the user did not cancel out of the save, so we can proceed
                currentController = newController;
                setLastPath(path);
            }
        }
        return(isNewController);
    }

    private void setTreeListenerOff()
    {
        listenToTreeEvents = false;
    }

    private void setTreeListenerOn()
    {
        listenToTreeEvents = true;
    }

    private ConfigurationController identifyControllerSelected(String pathInTree)
        throws Exception
    {
        ConfigurationController selectedController = null;

        for(int i = 0; i < configurationControllers.length; i++)
        {
            if(configurationControllers[i].containsPath(pathInTree))
            {
                selectedController = configurationControllers[i];
                break;
            }
        }
        if(selectedController == null)
        {
            throw new Exception("'" + pathInTree + "' could not be found");
        }
        if(DEBUG)
            System.out.println("the new controller is '"+selectedController+"'");
        return(selectedController);
    }

    private void setLastPath(TreePath path)
    {
        if(DEBUG)
            System.out.println("setting 'lastPath' to '"+lastPath+"'");
        lastPath = path;
    }

    private boolean isSameController(ConfigurationController newC)
    {
        return(currentController == newC);
    }

    public int checkSave()
    {
        return(checkSave(currentController, true));
    }

    private int checkSave(ConfigurationController ctrl, boolean closing)
    {
        //just make sure the last edit has been copied into the working copy
        saveCurrentEdit();

        int response = JOptionPane.YES_OPTION;
        if(ctrl.changed())
        {
            response = askSave(ctrl, closing);
        }
        return(response);
	}

    /**
     * There are 3 outcomes here :
     * 1. YES - save the changes
     * 2. NO - don't save the changes
     * 3. CANCEL - i did not mean to click on another tree node (hence, this option
     *  shown only when a user has in fact selected an alternate tree node
     * @param the controller behind the attributes being viewed/edited
     * @param whether the window is already in the process of being closed (ie.
     *      ths user should not be presented with a CANCEL option here)
     */
    private int askSave(ConfigurationController ctrl, boolean closing)
    {
        if(DEBUG)
            System.out.println("askSave("+ctrl+")");
        int choice = confirmSave(ctrl.getPrefsName(), closing);
        switch(choice)
        {
            case(JOptionPane.YES_OPTION):
                save(ctrl);
                break;
            case(JOptionPane.NO_OPTION):
                cancel(ctrl);
                break;
            case(JOptionPane.CANCEL_OPTION):
                //this can happen only if the user selected an alternate tree node;
                //The option will <bold>not</bold> be presented to the user when he has explicitly
                //  closed the window himself
                break;
        }
        return(choice);
	}

    private int confirmSave(String modelName, boolean closing)
    {
        if(DEBUG)
            System.out.println("confirmSave("+modelName+")");
        String prompt = "Cache Changes to "+modelName;
        String title = "*In-Memory* Save";
        if(closing)
        {
            return(showQuestionDialog(prompt, title, JOptionPane.YES_NO_OPTION));
        }
        else
        {
            return(showQuestionDialog(prompt, title, JOptionPane.YES_NO_CANCEL_OPTION));
        }
    }

    private void save(ConfigurationController ctrl)
    {
        //then, commit the changes
        this.saveClicked = true;
        this.commit();
        //then, turn off the save button options
        disableSaveOptions();
    }

    private void cancel(ConfigurationController ctrl)
    {
        rollback(ctrl);
        //then, turn off the save button options
        disableSaveOptions();
    }

    private void rollback(ConfigurationController ctrl)
    {
        ctrl.undoUncommitted();
        setConfigPanel();
    }

	public int showQuestionDialog(String prompt, String title, int option)
	{
        return(ConfigurationDialog.showConfirmJDialog(
                	this,
					prompt,
					title,
					option,
					JOptionPane.QUESTION_MESSAGE,
                	null)
				);
	}

    /**
     * Display a confirm dialog to the user with the specified attributes
     * @param the parent component for relative placement
     * @param the prompt to display with the dialog
     * @param the dialog title
     * @param the type of button option to present to the user
     * @param the message to display within the dialog
     * @param the icon to display within the dialog
     * @return the int (Swing) mapping of the button chosen
     */
	public static int showConfirmJDialog(Component c, String prompt, String title, int option, int msg, Icon icn)
	{
        int answer = JOptionPane.showConfirmDialog(
                	c,
					prompt,
					title,
					option,
					msg,
                	icn);
        c.requestFocus();
        return(answer);
	}

    public void
	valueChanged( TreeSelectionEvent event )
    {
        if(DEBUG)
            System.out.println("listenToTreeEvents = "+listenToTreeEvents);
        if(! listenToTreeEvents)
            return;

        try
        {
            boolean isNewController = resolveCurrentController(event);
            //ok, whether it's a new controller or not, we need to set the content
            //pane to reflect the [new] attribute view to match the newly selected node
            setConfigPanel();

            ConfigurationPanel ccp = getCurrentConfigPanel();
		    Object obj = tree.getLastSelectedPathComponent();
		    if ( obj == getCurrentConfigPanel().getCurrSelection() )
			    return;

		    String newTitle = ccp.valueChanged(obj);
            title.setText(newTitle);
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
		this.editorPanel.repaint( 250 );
    }

	public void commit()
    {
        for(int i = 0; i < configurationControllers.length; i++)
        {
            configurationControllers[i].commit();
        }

    }

    public void propertyModified(UserPrefs prefs, ConfigureSpec spec, ConfigureEditor editor)
    {
        if(DEBUG)
        {
            System.out.println("ConfigurationDialog.propertyModified()");
            System.out.println("\tprefs = "+prefs);
            System.out.println("\tpropertyName = "+spec.getPropertyName());
            System.out.println("\teditor = "+editor);
        }
        enableSaveOptions();
    }

    /**
     * This is where any editor can ask us for a list by its name
     * @param the name by which the list will have been cached
     * @return a simple string array - not a ref to some editable object
     *
    public String[] getListArray(String listName)
    {

    }*/
}