package com.ice.config.editor;

public interface Range
{
    public void setMinimum(Number min);
    public void setMaximum(Number max);
    public Number getMinimum();
    public Number getMaximum();
    public boolean minSet();
    public boolean maxSet();
}