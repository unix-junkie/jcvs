package com.ice.config.demo;

import com.ice.config.*;
import com.ice.pref.UserPrefs;
import com.ice.jcvsii.ResourceMgr;

/**
 * Title:        Netwxs
 * Description:  Internet Mobile Exchange
 * Copyright:    Copyright (c) Net:wxs Pty Ltd
 * Company:      Net:WxS Pty Ltd
 * @author Julian Salerno, julian@practica.com.au
 * @version 1.0
 */

public abstract class DemoConfiguration extends AbstractConfiguration
{
    protected ConfigurationController demoConfigurationController;

	protected UserPrefs	    defaultDemoPrefs;
    protected UserPrefs		demoPrefs;
    protected UserPrefs		demoSpec;
	protected String		demoPrefsFilename, demoPrefsDefaultsFilename;

    public DemoConfiguration(String name)
    {
        super(name);//userHome

        this.demoSpec = null;
        this.demoPrefs = null;
        this.defaultDemoPrefs = null;
    }

	public void initializePreferences( String prefix , String userHome)
    {
        super.initializePreferences(prefix, userHome);

        //the data
		this.defaultDemoPrefs = new UserPrefs( "Demo.DemoConfigDefaults", null );
        setUserHome(defaultDemoPrefs);

		this.demoPrefs = new UserPrefs( "Demo.DemoReleaseConfig", defaultDemoPrefs );
        setUserHome(demoPrefs);

		this.demoSpec = new UserPrefs( "Demo.DemoConfigSpec", null );
        setUserHome(demoSpec);

    }

    public void setPropertyPrefixes(String prefix)
    {
		this.defaultDemoPrefs.setPropertyPrefix(prefix);
		this.demoPrefs.setPropertyPrefix(prefix);
		this.demoSpec.setPropertyPrefix(prefix);
    }

    public void loadConfigurations(String loadMode, IncrementalBoundedRangeModel iModel)
    {
        loadDemoPreferences(loadMode);
        iModel.increment();
        if(DEBUG)
            demoPrefs.list(System.out);
    }

	public void loadDemoPreferences(String loadMode)
    {
        loadPreferences(loadMode, this.demoPrefs, this.getDemoPrefsFilename());
        loadPreferences(loadMode, this.defaultDemoPrefs, this.getDemoPrefsDefaultsFilename());
    }

/*
	public void loadConfigEditorSpecifications(String loadMode)
    {
        loadConfigEditorSpecification(loadMode, getDemoSpecName(), demoSpec);
    }
*/
//    protected abstract String getDemoSpecName();

	public String getDemoPrefsFilename(){return this.demoPrefsFilename;}
	public String getDemoPrefsDefaultsFilename(){return this.demoPrefsDefaultsFilename;}

	protected int establishOSDistinctions()
    {
		int osType = super.establishOSDistinctions();
        return(osType);
    }

	public void savePreferences()
    {
        saveDemoProperties("demo software properties");
    }

	public synchronized void saveDemoProperties( String header )
    {
        storePreferencesToProperties(this.demoPrefs, this.getDemoPrefsFilename(), header);
    }

    public UserPrefs getDemoPrefs(){return(demoPrefs);}

    public String getDialogTitle()
    {
        /**@todo: implement this com.ice.config.AbstractConfiguration abstract method*/
        return("Demo Configuration");
    }

    /**
     * Return the number of controllers which this class will/has create(d)
     *
    public abstract int getNumControllers();
*/
    public String getPropertyPrefix()
    {
        return("");
    }
}