package com.ice.config;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import javax.help.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;

import java.util.Hashtable;
import java.util.Enumeration;

import com.ice.cvsc.CVSProject;
import com.ice.cvsc.CVSCUtilities;
import com.ice.pref.UserPrefs;
import com.ice.util.AWTUtilities;

import com.ice.jcvsii.MainPanel;
import com.ice.jcvsii.ResourceMgr;
import com.ice.jcvsii.HTMLDialog;
import com.ice.jcvsii.ProjectFrame;
import com.ice.jcvsii.ProjectFrameMgr;
import com.ice.jcvsii.ResourceMgr;
import com.ice.config.DefaultConfiguration;
import com.ice.config.Configuration;
import com.ice.config.ActionEventDescriptor;
import com.ice.config.editor.PrefsAwareDialog;

/**
* This class represents the common aspects of any implementor of <code>MainFrame</code>.
*
* This class is an enhancement and a replacement for the old <code>MainFrame</code> class.
* <code>MainFrame</code> is now an interface which all main frames must implement.
*
* @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
* @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
*
* @version $Revision: 1.12 $
*/
public      abstract
class		AbstractMainFrame extends JFrame
implements	ActionListener, MainFrame
{
	private     Configurator        configurator;
    protected   Rectangle           frameBounds;
    /** the menu **/
	private JMenuBar		menuBar;
	private JMenu			fileMenu;
	private JMenu			configurationsMenu;
	private JMenu			helpMenu;

    /** We keep a ref to all opened <code>Configuration</code>'s
     *  (Config editing occurs in a separate thread).
     *  This number should be 1, but you never know (OS dependencies ...)

     *  The hash is trimmed each time a <code>Configuration</code> edit thread
     *  terminates normally (ie. via a close of the code>ConfigurationDialog</code>.
     *  However, some platforms allow the parent frame of even <strong>modal</strong>
     *  dialogs to be accessed and closed. (eg. Red Hat Linux 6.2, Gnome/KDE).

     *  For this reason, any configs which remain in the hash when the parent frame
     *  (ie. this) is closed can be dealt with appropriately.
     *  The trigger to the method <code>closeWindows()</code> is <code>savePreferences()</code>
     *  which is iself called in response to a window close event on this MainFrame
     *  or any subclass instance. The <code>quit()</code> method tells the <code>Configurator</code>
     *  to <code>performShutDown()</code> which ultimately leads to a call on this MainFrame
     *  to <code>savePreferences()</code>.
     */
    private Hashtable windowHash = new Hashtable();

	public AbstractMainFrame( Configurator configurator, String title, Rectangle frameBounds )
    {
		super( title );
        this.configurator = configurator;
        this.frameBounds = frameBounds;
    }

    public void init()
    {
        if(DEBUG)
            System.out.println("AbstractMainFrame.init");
        initialize();
        //create a menu bar
        createMenuBar();
        //now create some menus to place onto the bar
        //and create menu items within each menu
        establishMenuBar();
        //we add a window listener, but other listeners may be required
        addListeners();
        //this is where we go and build our screens
        initView();
    }

    public abstract void initialize();

    public void addListeners()
    {
        final Configurator conf = configurator;
		this.addWindowListener(
			new WindowAdapter()
				{
				public void
				windowClosing( WindowEvent e )
					{ quit(); }
				}
			);
    }

    public void initView()
    {
		this.pack();
		if ( frameBounds != null )
        {
			this.setBounds( frameBounds );
		}
        //call back for instance configurators to add their own additional content
        buildScreens();
        setResizable(false);
    }

    protected abstract void buildScreens();
    public Frame getFrame()
    {
        return(this);
    }

	public void addConfiguration(Configuration configuration)
    {
        if(DEBUG)
            System.out.println("AbstractMainFrame.addConfiguration();");
        ActionEventDescriptor aed = configuration.getActionEventDescriptor();
        if(aed == null)
        {
            System.err.println("Configuration '"+configuration.getName()+"' cannot be represented in the Configurations menu because no ActionEventDescriptor has been specified");
        }
        else
        {
            addActionEventDescriptor(configuration);
        }
    }

    private void addActionEventDescriptor(Configuration configuration)
    {
        ActionEventDescriptor aed = configuration.getActionEventDescriptor();
        //Create a menu item to edit the configuration
		JMenuItem menuItem = new JMenuItem(aed.getActionCommandString());

		menuItem.setActionCommand(aed.getActionCommandString());
		menuItem.setAccelerator(KeyStroke.getKeyStroke( aed.getAcceleratorKey() ) );

        menuItem.setEnabled(aed.getDefaultEnabledState());
        final Configuration conf = configuration;
        final MainFrame mf = this;
		menuItem.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                SwingUtilities.invokeLater(
				    new Runnable()
                    {
					    public void run()
                        {
                            try
                            {
                                registerScreen(conf);
                                editConfiguration(conf, mf);
                                //ok, the window was closed cleanly
                                deregisterScreen(conf);
                            }
                            catch(Exception ex)
                            {
                                ex.printStackTrace();
                            }
                        }
                    }
                );
            }
         });
        if(DEBUG)
            System.out.println("adding menuItem "+menuItem);
        this.configurationsMenu.add(menuItem);
    }

	private void registerScreen(Configuration config)
    {
        windowHash.put(config.getName(), config);
    }

	private void deregisterScreen(Configuration config)
    {
        windowHash.remove(config.getName());
    }

    private void closeWindows()
    {
        //any windows that were not cleanly de-registered will still be in the hash
        Enumeration windows = windowHash.elements();
        while(windows.hasMoreElements())
        {
            Configuration config = (Configuration)windows.nextElement();
            config.close();
            //then de-regiuster it
            deregisterScreen(config);
        }
    }

	public void
	loadPreferences()
		{
		}

	public void
	savePreferences()
    {
        closeWindows();

        //let's catch any unclosed windows now and see if they need saving
		Rectangle bounds = this.getBounds();

		if ( bounds.x >= 0 && bounds.y >= 0
				&& bounds.width > 0 && bounds.height > 0 )
        {
			UserPrefs defaults = DefaultConfiguration.getPreferences();
            if(defaults != null)
            {
                defaults.setBounds( DefaultConfiguration.MAIN_WINDOW_BOUNDS, bounds );
			}
        }
    }

    public void quit()
    {
        configurator.performShutDown();
        /**
         * we DO NOT run a SwingUtilities thread in this case because the net
         * effect is to (potentially) close all windows and when a "SAVE?" dialog
         * is (possibly) throw there would be no obvious window to which it refers.
         *
        SwingUtilities.invokeLater(new Runnable()
        {
            public void
            run()
            {
                configurator.performShutDown();
            }
        });
         */
    }

    public abstract void showAboutBox();
    public abstract void showBugReportScreen();
    public abstract void showHomePageScreen();

    public void editConfiguration( Configuration config, MainFrame mframe )
        throws Exception
    {
        config.editConfiguration(mframe);
	}

    public void actionPerformed( ActionEvent event )
    {

		String command = event.getActionCommand();

		if ( command.equals( "QUIT" ) )
        {
		    quit();
        }
		else if ( command.equals( "ABOUT" ) )
        {
		    showAboutBox();
        }
		else if ( command.equals( "BUGREPORT" ) )
        {
            showBugReportScreen();
        }
		else if ( command.equals( "HOMEPAGE" ) )
        {
		    showHomePageScreen();
        }
		else
        {
			System.err.println( "UNKNOWN Command '" + command + "'" );
        }
    }

	public void
	showHTMLDialog( String titleKey, String msgKey )
		{
		String msgStr =
			ResourceMgr.getInstance().getUIString( msgKey );

		String title =
			ResourceMgr.getInstance().getUIString( titleKey );

		HTMLDialog dlg =
			new HTMLDialog
				( null, title, true, msgStr );

		Dimension newSz = new Dimension( 560, 420 );
		dlg.setSize( newSz );
		Point location =
			AWTUtilities.computeDialogLocation( dlg );
		dlg.setLocation( location.x, location.y );

		dlg.show();
    }

	private void createMenuBar()
    {
		this.menuBar = new JMenuBar();
    }

    public JMenuBar getMyMenuBar()
    {
        if(this.menuBar == null)
            createMenuBar();
        return(menuBar);
    }

    private JMenu getFileMenu()
    {
        if(this.fileMenu == null)
            createFileMenu();
        return(fileMenu);
    }

    private void createFileMenu()
    {
		ResourceMgr rmgr = ResourceMgr.getInstance();

		this.fileMenu = new JMenu( rmgr.getUIString( "menu.file.name" ) );
		this.menuBar.add( this.fileMenu );
	}

//    protected abstract void establishMenuBar();

	private void establishMenuBar()
    {
		JMenuItem	item;
		this.menuBar = new JMenuBar();
		this.addFileMenu( this.menuBar );
		this.addHelpMenu( this.menuBar );
		this.setJMenuBar( this.menuBar );
    }

	protected void addToFileMenu( JMenuItem item )
    {
        if(this.menuBar == null)
            createMenuBar();
        if(this.fileMenu == null)
            createFileMenu();
    }

    private void addMenuToMenuBar(JMenuBar mbar, JMenu  menu)
    {
        mbar.add(menu);
    }

	private void addFileMenu( JMenuBar mbar )
    {
		JMenuItem	item;

		ResourceMgr rmgr = ResourceMgr.getInstance();

        addMenuToMenuBar(getMyMenuBar(), getFileMenu());
/*
		this.fileMenu = new JMenu( rmgr.getUIString( "menu.file.name" ) );
		mbar.add( this.fileMenu );
*/
        this.configurationsMenu = new JMenu( rmgr.getUIString( "menu.configurations.name" ) );
		mbar.add( this.configurationsMenu );
		item = new JMenuItem( rmgr.getUIString( "menu.file.quit.name" ) );
		this.fileMenu.add( item );
		item.addActionListener( this );
		item.setActionCommand( "QUIT" );
		item.setAccelerator
			( KeyStroke.getKeyStroke
				( KeyEvent.VK_Q, Event.CTRL_MASK ) );
		}

	private void
	addHelpMenu( JMenuBar mbar )
		{
		JMenuItem	item;

		ResourceMgr rmgr = ResourceMgr.getInstance();

		this.helpMenu = new JMenu( rmgr.getUIString( "menu.help.name" ) );
		mbar.add( this.helpMenu );

		boolean haveJH = false;
		try {
			Class cls = Class.forName( "javax.help.HelpSet" );
			haveJH = true;
			}
		catch ( ClassNotFoundException ex )
			{
			haveJH = false;
			}

		if ( haveJH )
			{
			this.addJavaHelpItem();
			}
		else
			{
			System.out.println( "JavaHelp is not available." );
//			CVSLog.logMsgStderr( "JavaHelp is not available." );
			}

		item = new JMenuItem( rmgr.getUIString( "menu.help.homepage.name" ) );
		this.helpMenu.add( item );
		item.addActionListener( this );
		item.setActionCommand( "HOMEPAGE" );

		item = new JMenuItem( rmgr.getUIString( "menu.help.bugreport.name" ) );
		this.helpMenu.add( item );
		item.addActionListener( this );
		item.setActionCommand( "BUGREPORT" );

		this.helpMenu.addSeparator();

		item = new JMenuItem( rmgr.getUIString( "menu.help.about.name" ) );
		this.helpMenu.add( item );
		item.addActionListener( this );
		item.setActionCommand( "ABOUT" );
		}

	/**
	 * We push this down to prevent JIT's from dying without JavaHelp classes.
	 */

	private void
	addJavaHelpItem()
		{
        //temp
        return;
/*
		JMenuItem	item;
		String helpSetUrlName = "com/ice/jcvsii/doc/help/help.hs";
		ResourceMgr rmgr = ResourceMgr.getInstance();

		try {
			ClassLoader loader =
				MainFrame.class.getClassLoader();

			URL hsURL =
				HelpSet.findHelpSet( loader, helpSetUrlName );

			if ( hsURL == null )
				{
				throw new Exception
					( "HelpSet URL is null (not found?)" );
				}

			HelpSet hs =
				new HelpSet( loader, hsURL );

			HelpBroker hb = hs.createHelpBroker();

			item = new JMenuItem( rmgr.getUIString( "menu.help.javahelp.name" ) );
			this.helpMenu.add( item );
			item.addActionListener( new CSH.DisplayHelpFromSource( hb ) );

			this.helpMenu.addSeparator();
			}
		catch ( Exception ex )
			{
			JOptionPane.showMessageDialog( this,
				"Could not open HelpSet '" + helpSetUrlName
					+ "',\n" + ex.getMessage(),
				"Warning", JOptionPane.WARNING_MESSAGE );
			}
*/
		}


	public static void
	setWaitCursor( Container cont, boolean busy )
    {
		Cursor curs = busy
				? Cursor.getPredefinedCursor( Cursor.WAIT_CURSOR )
				: Cursor.getPredefinedCursor( Cursor.DEFAULT_CURSOR );

		cont.setCursor( curs );

		for ( int i = 0, sz = cont.getComponentCount() ; i < sz ; ++i )
			{
			Component comp = cont.getComponent( i );
			Class contCls = Container.class;
			Class compCls = comp.getClass();
			if ( contCls.isAssignableFrom( compCls ) )
            {
				AbstractMainFrame.setWaitCursor( (Container)comp, busy );
            }
			else
            {
				comp.setCursor( curs );
            }
        }
    }
}