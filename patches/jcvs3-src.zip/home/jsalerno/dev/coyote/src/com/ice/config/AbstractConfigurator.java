package com.ice.config;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;

import com.ice.pref.*;

import com.ice.jcvsii.ResourceMgr;
import com.ice.app.AppSplash;
import com.ice.config.IncrementalBoundedRangeModel;
import com.ice.config.DefaultConfiguration;
import com.ice.config.Configuration;
import com.ice.config.Initiator;

/**
 * A <code>Configurator</code> is a jvm-runnable, and all concrete implementations should
 *  have a main(String[] argv) method.
 * A list of <code>Configuration</code>'s is held here.
 * <code>instanceMain()</code> is called from <code>initialize</code> your application.
 * This class implements <code>Configurator</code> and the key interface method notably is:
 * <code>getPrefsPersistenceModel()</code>.
 *
 * @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
 * @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
 *
 * @version $Revision: 1.10 $
 */
public abstract class AbstractConfigurator implements Configurator
{
    //a convenient place for bulk Configuration processing
    protected Configuration[] configurations;
    //the base file path for the property files associated with the runtime config files
    protected String configBasePath;
    //the main frame for presentation of the configurator instance
	protected MainFrame		mainFrame;
    /** keep a reference to the startup application args **/
	protected String[] appArgs;

	public void initialize( String[] argv, String name , String rsrcName )
        throws Exception
    {
        instanceMain(argv, name, rsrcName);
    }

	protected void instanceMain( String[] argv, String name , String rsrcName )
        throws Exception
    {
        if(DEBUG)
            System.out.println("AbstractConfigurator.instanceMain");
        //initialize the res mgr
        ResourceMgr.initializeResourceManager( name, rsrcName );
        //process the user's args
		processArguments( argv );
        //let's determine by how much we need to increment the progress bar
        //  as the controllers are loaded
        int extent = determineExtent(getNumControllers());
        //create a bounded range model, but make it an incremental one so that
        //  the only thing we need to do is call <code>increment()</code> on it.
		IncrementalBoundedRangeModel model =
			new IncrementalBoundedRangeModel( 0, 0, 0, 100, extent );
        //now build a splash screen which will contain the progress bar
		AppSplash splash = new AppSplash(
            getSplashScreenName(),
            model,
            getPathToSplashImageResource(),
            getConfigToolDisplayName() );
        //and then show it
		splash.show();

		// NOTE This focus request must be here after
		//      showing the parent to get keystrokes properly.
		splash.requestFocus();
        //start a thread to run the controller load sequence
		(new Initiator( splash, model, this )).start();
    }

    /**
     * Process the user's startup args.
     *
     * And we cache the app args for later use.
     * We process the VM args.
     * And then we process the VM args.
     *
     * We examine for:
     *  "-osname"
     *  "-user"
     *  "-home"
     *
     * @param the main args as supplied at startup
     */
	protected void processArguments( String[] argv )
        throws Exception
    {
        if(DEBUG)
            System.out.println("AbstractConfigurator.processArguments");
        //keep a local copy
        storeAppArgs(argv);
        //process the VM args
        processVMArgs();
        //process the app args
        processApplicationArgs();
        //create the configurations used by the configurator
        configurations = createConfigurations();
        //establish the (single) base path where the properties live
        configBasePath = establishConfigBasePath();
        //set the <code>UserPrefs</code> user home according to the config base path
        setConfigBaseHome(configBasePath);
    }

    protected int determineExtent(int[] controllerCountArray)
        throws Exception
    {
        if(controllerCountArray == null)
            throw new Exception("You must specify a valid set of controllers");

        int total = 0;
        for(int i = 0; i < controllerCountArray.length; i++)
        {
            total += controllerCountArray[i];
        }

        if(total == 0)
            throw new Exception("You must specify a valid set of controllers");

        int extent = 100/total;
        return(extent);
    }

    private void storeAppArgs(String[] argv){this.appArgs = argv;}
    public String[] getApplicationArgs(){return(appArgs);}
    public Configuration[] getConfigurations(){return(configurations);}
    public String getConfigBasePath(){return(configBasePath);}

    protected int[] getNumControllers()
    {
        int[] controllerCntArray = new int[configurations.length];
        for(int i = 0; i < configurations.length; i++)
        {
            controllerCntArray[i] = configurations[i].getNumControllers();
        }
        return(controllerCntArray);
    }

    protected void processApplicationArgs()
    {
        if(DEBUG)
            System.out.println("AbstractConfigurator.processApplicationArgs");
        String userHome = null;
        String osSuffix = null;
        String userSuffix = null;

		for ( int i = 0 ; i < appArgs.length ; ++i )
        {
			if ( appArgs[i].equals( "-osname" ) )
				{
                osSuffix = appArgs[++i];
				}
			else if ( appArgs[i].equals( "-user" ) )
				{
                userSuffix = appArgs[++i];
				}
			else if ( appArgs[i].equals( "-home" ) )
				{
                userHome = appArgs[++i];
				}
			else
				{
				System.err.println
					( "   appArgs[" +i+ "] '" +appArgs[i]+ "' ignored." );
            }
        }
    }

    /**
     * As it says :-).
     * Tell the main frame to save it preferences first.
     * Then, exit.
     */
	public void performShutDown()
    {
		shutDownActions();
        systemExit();
    }

	protected void shutDownActions()
    {
		this.mainFrame.savePreferences();
    }

	private void systemExit()
    {
		System.exit( 0 );
    }

    protected abstract Configuration[] createConfigurations();
    protected abstract String establishConfigBasePath();
    protected abstract String getSplashScreenName();
    protected abstract String getPathToSplashImageResource();
    protected abstract String getConfigToolDisplayName();
    protected abstract void processVMArgs() throws Exception;
    protected abstract void createMainFrame(Rectangle bounds);

    protected void setConfigBaseHome(String cbp)
        throws Exception
    {
        if(isDirectory(cbp))
        {
            setUserHome(cbp);
        }
        else
        {
            destroyConfigurations();
            throw new Exception("The base config path '"+cbp+"' is invalid. Config App will now terminate abnormally");
        }
    }

    private void destroyConfigurations()
    {
        for(int i = 0; i < configurations.length; i++)
        {
            configurations[i] = null;
        }
    }

    private boolean isDirectory(String path)
    {
        File dir = new File(path);
        return(dir.isDirectory());
    }

    private void setUserHome(String configBasePath)
    {
        for(int i = 0; i < configurations.length; i++)
        {
            if(configurations[i] != null)
                configurations[i].setUserHome(configBasePath);
        }
    }

    public void checkCriticalProperties() throws Exception
    {
        for(int i = 0; i < configurations.length; i++)
        {
            if(configurations[i] != null)
                configurations[i].checkCriticalProperties(mainFrame);
        }
    }

    public void addEditMenuItems() throws Exception
    {
        for(int i = 0; i < configurations.length; i++)
        {
            if(configurations[i] != null)
            {
                mainFrame.addConfiguration(configurations[i]);
            }
        }
    }

	public MainFrame getMainFrame(Rectangle bounds)
    {
        if(mainFrame == null)
        {
            createMainFrame(bounds);
        }
		return mainFrame;
    }
}