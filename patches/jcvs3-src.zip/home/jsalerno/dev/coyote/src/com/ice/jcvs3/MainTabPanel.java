
package com.ice.jcvs3;

import java.awt.Container;
import java.awt.Cursor;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.ice.config.MainPanelInterface;
import com.ice.jcvsii.*;

public
class		MainTabPanel
extends		JPanel
	{
	protected MainPanelInterface		parent;
//	protected MainPanel		parent;

	public
	MainTabPanel( MainPanel parent )
		{
            this((MainPanelInterface)parent);
        }

	public
	MainTabPanel( MainPanelInterface parent )
		{
		super();
		this.parent = parent;
		this.setBorder( new EmptyBorder( 4, 4, 4, 4 ) );
		}

	public MainPanelInterface
//	public MainPanel
	getMainPanel()
		{
		return this.parent;
		}

	public com.ice.config.MainFrame
//	public MainFrame
	getMainFrame()
		{
		return this.parent.getMainFrame();
		}

	public void
	savePreferences()
		{
		}

	//
	// HACK
	// The setCursor() code is broken.
	// (Geez, Sun, talk about critical and obvious!).
	// So, we set the cursor on the top level ancestor, which
	// appears to do what we want. Hopefully, we can fix this
	// later on to setCursor() on "this" instead!
	//

	protected void
	setWaitCursor()
		{
		Container frame = this.getTopLevelAncestor();
		MainFrame.setWaitCursor( frame, true );
		}

	protected void
	resetCursor()
		{
		Container frame = this.getTopLevelAncestor();
		MainFrame.setWaitCursor( frame, false );
		}

	}

