package com.ice.config;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.util.Vector;
import java.util.Enumeration;

import com.ice.pref.UserPrefs;
/**
 * The public api for the editing of configurations.
 *
 * @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
 * @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
 *
 * @version $Revision: 1.6 $
 */
public interface ConfigurationController
{
    public boolean DEBUG = System.getProperty("debugController") != null;

    /**
     * @return a reference to the 'working copy' of the loaded UserPrefs
     */
    public UserPrefs getWorkingCopy();
    /**
     * @return a reference to the 'original' loaded UserPrefs
     */
    public UserPrefs getUserPrefs();
    /**
     * @return a reference to the 'edit spec' of the loaded UserPrefs
     */
    public UserPrefs getSpecs();

    /**
     * Tell the controller to insert its edit spec paths into the config tree
     */
	public void insertSpecIntoConfigTree();

    /**
     * @return the editor factory used for creating editors withi this controller's domain
     */
    public ConfigureEditorFactory getEditorFactory();
    /**
     * @param set the editor factory used for creating editors withi this controller's domain
     */
    public void setEditorFactory(ConfigureEditorFactory factory);

    /**
     * @param set the configuration panel used to view properties within this controller's domain
     */
    public void setConfigurationPanel(ConfigurationPanel configPanel);
    /**
     * @return the configuration panel used to view properties within this controller's domain
     */
    public ConfigurationPanel getConfigurationPanel();

    /**
     * @return the controller's edit spec as a vector
     */
    public Vector getSpecsAsVector();

    /**
     * @param set the configuration tree model used to view properties within this controller's domain
     */
    public void setConfigurationTreeModel(ConfigureTreeModel treeModel);
    /**
     * @return the configuration tree model used to view properties within this controller's domain
     */
    public ConfigureTreeModel getConfigurationTreeModel();

    /**
     * Edit a property with the given name
     * @param the property name
     */
	public void editProperty( String prop );
    /**
     * Edit propertied with the given names
     * @param the property names
     */
	public void editProperties( String[] props );

    /**
     * Save the edit which is current
     */
    public void saveCurrentEdit();

    /**
     * Tell the caller whether this controller can match the path pattern
     * @param the path pattern
     * @return the found status
     */
    public boolean containsPath(String path);

    /**
     * Commit the changes to file that have happened within this controller
     */
    public void commit();

    /**
     * Undo the changes that have happened within this controller
     */
    public void undoUncommitted();

    /**
     * @return the name of the prefs file used to create this controller
     */
    public String getPrefsName();

    /**
     * Has there been a change in the UserPrefs ?
     * @return change status
     */
     public boolean changed();

}