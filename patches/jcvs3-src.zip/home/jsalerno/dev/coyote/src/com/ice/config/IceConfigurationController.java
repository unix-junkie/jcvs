package com.ice.config;

/**
 * Title:        Netwxs
 * Description:  Internet Mobile Exchange
 * Copyright:    Copyright (c) Net:wxs Pty Ltd
 * Company:      Net:WxS Pty Ltd
 * @author Julian Salerno, julian@practica.com.au
 * @version 1.0
 */
import com.ice.pref.UserPrefs;
import com.ice.jcvsii.ExecCommandEditor;
import com.ice.jcvsii.ServerCommandEditor;
import com.ice.jcvsii.LookAndFeelEditor;

public class IceConfigurationController extends DefaultConfigurationController
{

    public IceConfigurationController(UserPrefs prefs, UserPrefs specs)
        throws Exception
    {
        super(prefs, specs);
    }

    protected void createFactory()
    {
		this.factory = new DefaultConfigureEditorFactory( specs );
    }

    protected void addEditors() throws Exception
    {
        super.addEditors();

		((DefaultConfigureEditorFactory)factory).addEditor( "cmdexec", new ExecCommandEditor() );
		((DefaultConfigureEditorFactory)factory).addEditor( "srvrcmd", new ServerCommandEditor() );
		((DefaultConfigureEditorFactory)factory).addEditor( "plafcls", new LookAndFeelEditor() );
    }
}