package com.ice.config.editor;

import javax.swing.text.PlainDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;

public abstract class NumberDocument extends PlainDocument implements Range
{
    protected Number min;
    protected Number max;

    protected boolean minSet = false;
    protected boolean maxSet = false;

    public void setMinimum(Number min)
    {
        this.min = min;
        this.minSet = true;
    }

    public void setMaximum(Number max)
    {
        this.max = max;
        this.maxSet = true;
    }
    public Number getMinimum(){return(min);}
    public Number getMaximum(){return(max);}

    public boolean minSet(){return(minSet);}
    public boolean maxSet(){return(maxSet);}

    public NumberDocument()
    {
        super();
    }

    public void insertString(int offset, String s, AttributeSet atset)
        throws BadLocationException
    {
        try
        {
            //just check the int validity b4 anything else
            Number number = validateNumber(s);
            //ok, now check the range bounds
            checkRange(number);
        }
        catch(NumberFormatException nfe)
        {
            java.awt.Toolkit.getDefaultToolkit().beep();
            return;
        }
        catch(NumberOutOfRangeException noore)
        {
            System.out.println(noore.getMessage());;
            java.awt.Toolkit.getDefaultToolkit().beep();
            return;
        }
        super.insertString(offset, s, atset);
    }

    protected String getNextStringValue(String lastCharTyped)
        throws NumberFormatException, BadLocationException
    {
        Content content = getContent();
        int length = content.length();
        String val = content.getString(0, length-1);
        String returnStr = val+lastCharTyped;
        return(returnStr);
    }

    protected void checkRange(Number val) throws NumberOutOfRangeException
    {
        if(minSet())
            checkMin(val);
        if(maxSet())
            checkMax(val);
    }

    protected abstract Number validateNumber(String s)
        throws NumberFormatException, BadLocationException;

    protected abstract void checkMin(Number val) throws NumberOutOfRangeException;
    protected abstract void checkMax(Number val) throws NumberOutOfRangeException;

    protected void checkMinSate(int state, Number val) throws NumberOutOfRangeException
    {
        if(state < 0)
            throw new NumberOutOfRangeException("The value '"+val+"' exceeds the lower limit of '"+getMinimum()+"'");
    }

    protected void checkMaxSate(int state, Number val) throws NumberOutOfRangeException
    {
        if(state > 0)
            throw new NumberOutOfRangeException("The value '"+val+"' exceeds the upper limit of '"+getMaximum()+"'");
    }
}