package com.ice.config.demo;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;

import com.ice.pref.*;
import com.ice.jcvsii.ResourceMgr;
import com.ice.app.AppSplash;
import com.ice.config.*;

import com.ice.util.URLUtilities;

public class DemoConfigurator2 extends DemoConfigurator
{
    protected DemoConfiguration demoConfiguration2;
    /**
     * Start this sucker up.
     * Call <code>instanceMain(argv)</code> on the configurator <code>instance</code>
     */
	static public void main( String[] argv )
    {
		Configurator app = new DemoConfigurator2();
		DemoConfigurator.instance = (DemoConfigurator2)app;
        try
        {
		    app.initialize( argv, "demo2", "com.ice.config.demo.rsrcui");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public DemoConfiguration getDemoConfiguration2(){return(demoConfiguration2);}

    protected Configuration[] createConfigurations()
    {
		demoConfiguration = DemoConfiguration1.getInstance();
        demoConfiguration2 = DemoConfiguration2.getInstance();
        //build an array for faceless access to the Configurations
        return(new Configuration[]{demoConfiguration, demoConfiguration2});
    }

    protected String getSplashScreenName()
    {
        return("Demo 2 Configurator");
    }

    protected String getConfigToolDisplayName()
    {
        return("Demo 2 Configuration Tool");
    }

}