package com.ice.config;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.awt.Frame;
/**
 * This interface defines the bahviour of all main frames used by configurators.
 *
 * @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
 *
 * @version $Revision: 1.4 $
 */
public interface MainFrame
{
	/** Set to true to get processing debugging on stderr. **/
	public boolean DEBUG = System.getProperty("debugViews") != null;

    public void init();
	public void loadPreferences();
	public void savePreferences();
	public void addConfiguration(Configuration configuration);
    public void editConfiguration( Configuration config, MainFrame frame ) throws Exception;

    //some ui-specific procedures which <bold>all</bold> apps should provide
    public void showAboutBox();
    public void showBugReportScreen();
    public void showHomePageScreen();

    //some api to cover the awt aspect of the main frame - broken 1.1 awt design really
    public Frame getFrame();
}