
package com.ice.config.editor;

import javax.swing.text.Document;
import javax.swing.text.PlainDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.JTextComponent;

import com.ice.config.*;
import com.ice.pref.UserPrefs;


public
class		ConfigDoubleEditor
extends		ConfigNumberEditor
	{

	public
	ConfigDoubleEditor()
		{
		super( "Double" );
		}

    protected void setFieldDocumentEditor()
    {
        numField.setDocument(new DoubleDocument());
	}

	public String
	getTypeTitle()
		{
		return "Double";
		}

	public String
	formatNumber( UserPrefs prefs, ConfigureSpec spec )
		{
		double dbl =
			prefs.getDouble( spec.getPropertyName(), 0.0 );

		return Double.toString( dbl );
		}

	public boolean
	isChanged( UserPrefs prefs, ConfigureSpec spec, String numText )
		{
		double cur = Double.valueOf( numText ).doubleValue();
		double old = prefs.getDouble( spec.getPropertyName(), 0 );
		return ( cur != old );
		}

}

