package com.ice.config;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.awt.*;
import java.io.*;
import java.util.*;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.BoundedRangeModel;
import javax.activation.*;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import com.ice.jcvsii.ConfigConstants;
import com.ice.jcvsii.ResourceMgr;
import com.ice.pref.*;
import com.ice.config.*;
import com.ice.config.editor.*;
import com.ice.util.AWTUtilities;
import com.ice.util.ResourceUtilities;
import com.ice.util.TempFileManager;
/**
 * This is a special <code>Configuration</code> class.
 * It is a place for application preferences (such as window sizes & file-naming policies)
 *  which may be used by many different applications.
 * Because it is quite a well-defined class with very particular purposes, you
 *  should almost always NOT extend this class, but rather the <code>AbstractConfiguration</code>
 *  class.
 *
 * @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
 * @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
 *
 * @version $Revision: 1.10 $
 */
public
class		DefaultConfiguration
extends     AbstractConfiguration
implements	PropertyChangeListener, ConfigConstants
{
	static public final String		RCS_ID = "$Id: DefaultConfiguration.java,v 1.10 2002/03/10 21:55:29 jsalerno Exp $";
	static public final String		RCS_REV = "$Revision: 1.10 $";

    /** the number of controllers required by this class **/
    public static final int NUM_APP_CONTROLLERS = 1;
    /** the name of the config spec used for the ui **/
    protected static final String APP_CONFIG_SPEC_NAME = "/com/ice/config/configspec.properties";

	/**
	 * The instance of the DEFAULT Preferences.
	 */
	private UserPrefs				defaultAppUserPrefs;

	/**
	 * The instance of the USER Specs.
	 */
	private UserPrefs				appEditSpec;

	/**
	 * The instance of the USER Preferences.
	 */
	private UserPrefs				userAppPrefs;

    /** File names **/
	private String					userPrefsFilename;
	private String					lastDitchTempDirname;

    //the app controller for default preferences
    ConfigurationController appConfigurationController;

	/**
	 * We create an instance when the Class is loaded
	 * and work with the instance.
	 */
	static
    {
		DefaultConfiguration.instance = new DefaultConfiguration("default_configuration");
    }

	/**
	 * The instance of the DEFAULT DefaultConfiguration.
	 */
	private static DefaultConfiguration			instance;

    /**
     * @return a handle to the singleton instance
     */
	public static DefaultConfiguration getInstance()
    {
		return DefaultConfiguration.instance;
    }

    /**
     * @return a handle to the User Preferences behind the singleton instance
     */
	public static UserPrefs getPreferences()
    {
		return DefaultConfiguration.getInstance().getPrefs();
    }

    /**
     * Constructor.
     * set <code>UserPrefs</code> references to null.
     */
	public
	DefaultConfiguration(String name)
    {
        super(name);

        //the application preferences
        this.userAppPrefs = null;
        //the configspec.properties
        this.appEditSpec = null;
        this.defaultAppUserPrefs = null;
    }

    /**
     * @return a reference to the <code>userAppPrefs</code> <code>UserPrefs</code> instance
     */
	public UserPrefs getPrefs()
    {
		return this.userAppPrefs;
    }

    /**
     * @return the filename of the user prefs instance
     */
	public String getUserPrefsFilename()
    {
		return this.userPrefsFilename;
    }

	/**
	 * This is guarenteeed to return a String which is the best
	 * representation of the temporary directory that we can come
	 * up with.
	 */
	public String getTemporaryDirectory()
    {
		return this.getPrefs().getProperty
			( GLOBAL_TEMP_DIR, this.lastDitchTempDirname );
    }

	/**
	 * This method sets up some fields that depend on the
	 * OS we are running on. Yeah, yeah, write once...
	 */
	protected int establishOSDistinctions()
    {
		int osType = super.establishOSDistinctions();
        switch(osType)
        {
            case(MAC_OS):
    			System.err.println( "Assuming a Macintosh platform." );
	    		this.userPrefsFilename = "jCVS Preferences";
		    	this.lastDitchTempDirname = "";
                break;
            case(WINDOWS):
    			System.err.println( "Assuming a Windows platform." );
	    		this.userPrefsFilename = "/com/ice/config/default_editor.properties";
		    	this.lastDitchTempDirname = ".";
			    break;
            case(OS2):
    			System.err.println( "Assuming an OS/2 platform." );
	    		this.userPrefsFilename = "jcvsii.txt";
		    	this.lastDitchTempDirname = ".";
			    break;
            case(UNIX):
            case(SOLARIS):
    			System.err.println( "Assuming a UNIX platform." );
	    		this.userPrefsFilename = ".jcvsii";
		    	this.lastDitchTempDirname = ".";
                break;
            default:
    			System.err.println( "Assuming a UNIX platform." );
	    		this.userPrefsFilename = ".jcvsii";
		    	this.lastDitchTempDirname = ".";
                break;
        }
        return(osType);
    	}

    /**
     * This method is where <code>UserPrefs</code> instances are created.
     * Default prefs are created first, then the instance user prefs, and then the edit specs.
     * Calls thru to <code>establishOSDistinctions()</code>.
     * @param the prefix to be used for property file lookups based upon prefixes
     * @param the user-home for the property files used by this <code>Configuration</code>
     */
	public void initializePreferences( String prefix , String userHome)
    {
        super.initializePreferences(prefix, userHome);

		//
		// NOTE
		// WARNING !!!
		//
		// These two statements are required with the JRE 1.2.
		// If they are not included, and there is no user preferences
		// file at user.home, then the lack of the preferences being
		// loaded causes a very queer ClassLoader error where the
		// activation classes will not be found by the method in the
		// package itself, even while our package *can* find the
		// classes! Wow! Here is the stack trace:
		//
		// java.lang.NoClassDefFoundError: javax/activation/MailcapCommandMap
		//    at javax.activation.MailcapCommandMap.class$(MailcapCommandMap.java:100)
		//    at javax.activation.MailcapCommandMap.<init>(MailcapCommandMap.java:139)
		//    at javax.activation.MailcapCommandMap.<init>(MailcapCommandMap.java:200)
		//    at com.ice.jcvsii.DefaultConfiguration.loadMailCap(DefaultConfiguration.java:816)
		//    at com.ice.jcvsii.JCVS$Initiator.run(JCVS.java:223)
		//
		// Anyway, these two lines appear to solve the problem by
		// loading these two "problem classes" before our code
		// (apparently) messes up the activation class loader.
		//

		// This creates a new UserPrefs with System.getProperties()
		// as its default properties.

		this.defaultAppUserPrefs = new UserPrefs( "jCVSII.Defaults" );
        setUserHome(defaultAppUserPrefs);

		// This creates a new UserPrefs with this.defaultAppUserPrefs as its
		// default properties. This will be the properties that are
		// stored in the user's home directory as the application's
		// configuration settings.

		this.userAppPrefs = new UserPrefs( "jCVSII.DefaultConfiguration", this.defaultAppUserPrefs );
        setUserHome(userAppPrefs);

		UserPrefs.setInstance( this.userAppPrefs );

		this.appEditSpec = new UserPrefs( "jCVSII.ConfigSpec", null );
        setUserHome(appEditSpec);
    }

    /**
     * This method is a convenience method to set the prefix for <code>UserPrefs</code>
     *  defined in this class.
     * Typically, all propAerties would use the same prefix.
     * @param the prefix to be used for property file lookups based upon prefixes
     */
    public void setPropertyPrefixes(String prefix)
    {
		this.appEditSpec.setPropertyPrefix( "" );
		this.userAppPrefs.setPropertyPrefix( prefix );
		this.defaultAppUserPrefs.setPropertyPrefix( prefix );
    }

    /**
     * This is method which we can call to determine whether we need to bail out or not
     */
	public void checkCriticalProperties( MainFrame parent ) throws Exception
    {
		Vector need = new Vector();
		ResourceMgr rmgr = ResourceMgr.getInstance();
		String tempDir = this.userAppPrefs.getProperty( GLOBAL_TEMP_DIR, null );

		if ( tempDir == null )
        {
			need.addElement( GLOBAL_TEMP_DIR );
        }
		else
        {
			File tempDirF = new File( tempDir );

			if ( ! tempDirF.exists() )
				{
				String[] fmtArgs = { tempDirF.getPath() };
				String msg =
					rmgr.getUIFormat( "misc.tempdir.needs.config.msg", fmtArgs );
				String title =
					rmgr.getUIFormat( "misc.tempdir.needs.config.title", fmtArgs );
				JOptionPane.showMessageDialog
					( parent.getFrame(), msg, title, JOptionPane.WARNING_MESSAGE );

				need.addElement( GLOBAL_TEMP_DIR );
				}
			else if ( ! tempDirF.canWrite() )
				{
				String[] fmtArgs = { tempDirF.getPath() };
				String msg =
					rmgr.getUIFormat( "misc.tempdir.cannot.write.msg", fmtArgs );
				String title =
					rmgr.getUIFormat( "misc.tempdir.cannot.write.title", fmtArgs );
				JOptionPane.showMessageDialog
					( parent.getFrame(), msg, title, JOptionPane.WARNING_MESSAGE );

				need.addElement( GLOBAL_TEMP_DIR );
				}
			}

		if ( need.size() > 0 )
			{
			String[] editProps = new String[ need.size() ];
			need.copyInto( editProps );
			this.editConfiguration( parent, editProps );
			}

		tempDir = this.userAppPrefs.getProperty( GLOBAL_TEMP_DIR, "" );
		TempFileManager.initialize( tempDir, "jcvs", ".tmp" );
    }

	/**
	 * This method sets up properties based on the preferences. These
	 * properties are established at the very end of the configuration
	 * initialization process. It is also responsible for installing
	 * any <em>global</em> property change listeners we need.
	 *

	public void
	initializeGlobalProperties()
		{
		String format =
			this.userAppPrefs.getProperty
				( PROJECT_MODIFIED_FORMAT, "EEE MMM dd HH:mm:ss yyyy" );

		EntryNode.setTimestampFormat( format );

		this.loadServerDefinitions();

		this.loadExecCmdDefinitions();

		boolean debugSetting;

		debugSetting =
			this.userAppPrefs.getBoolean
				( GLOBAL_PROJECT_DEEP_DEBUG, false );

		CVSProject.deepDebug = debugSetting;

		debugSetting =
			this.userAppPrefs.getBoolean
				( GLOBAL_PROJECT_DEBUG_ENTRYIO, false );

		CVSProject.debugEntryIO = debugSetting;

		boolean traceAll =
			this.userAppPrefs.getBoolean( GLOBAL_CVS_TRACE_ALL, false );

		CVSProject.overTraceTCP = traceAll;
		CVSProject.overTraceRequest = traceAll;
		CVSProject.overTraceResponse = traceAll;
		CVSProject.overTraceProcessing = traceAll;

		// Subscribe to property changes.
		String[] subs =
			{
			GLOBAL_TEMP_DIR,
			GLOBAL_CVS_TRACE_ALL,
			GLOBAL_PROJECT_DEEP_DEBUG,
			GLOBAL_PROJECT_DEBUG_ENTRYIO,
			PROJECT_MODIFIED_FORMAT,
			PLAF_LOOK_AND_FEEL_CLASSNAME
			};

		for ( int i = 0 ; i < subs.length ; ++i )
			{
			this.userAppPrefs.addPropertyChangeListener( subs[i], this );
			}
		}
*/

    /**
     * The <code>PropertyChangeListener</code> method
     * @param the property change evt
     */
	public void
	propertyChange( PropertyChangeEvent evt )
		{
        System.out.println("evt = "+evt);
		String propName = evt.getPropertyName();
/*
		if ( propName.equals( GLOBAL_CVS_TRACE_ALL ) )
			{
			boolean newSetting =
				this.userAppPrefs.getBoolean
					( GLOBAL_CVS_TRACE_ALL, false );

			CVSProject.overTraceTCP = newSetting;
			CVSProject.overTraceRequest = newSetting;
			CVSProject.overTraceResponse = newSetting;
			CVSProject.overTraceProcessing = newSetting;
			}
		else if ( propName.equals( GLOBAL_PROJECT_DEEP_DEBUG ) )
			{
			boolean newSetting =
				this.userAppPrefs.getBoolean
					( GLOBAL_PROJECT_DEEP_DEBUG, false );

			CVSProject.deepDebug = newSetting;
			}
		else if ( propName.equals( GLOBAL_PROJECT_DEBUG_ENTRYIO ) )
			{
			boolean newSetting =
				this.userAppPrefs.getBoolean
					( GLOBAL_PROJECT_DEBUG_ENTRYIO, false );

			CVSProject.debugEntryIO = newSetting;
			}
		else if ( propName.equals( GLOBAL_TEMP_DIR ) )
			{
			String tempDir =
				this.userAppPrefs.getProperty( GLOBAL_TEMP_DIR, "" );

			TempFileManager.clearTemporaryFiles();

			TempFileManager.initialize( tempDir, "jcvs", ".tmp" );
			}
		else if ( propName.equals( PROJECT_MODIFIED_FORMAT ) )
			{
			String format =
				this.userAppPrefs.getProperty
					( PROJECT_MODIFIED_FORMAT, "EEE MMM dd HH:mm:ss yyyy" );

			EntryNode.setTimestampFormat( format );
			}
		else if ( propName.equals( PLAF_LOOK_AND_FEEL_CLASSNAME ) )
			{
			String plafClassName =
				this.userAppPrefs.getProperty
					( DefaultConfiguration.PLAF_LOOK_AND_FEEL_CLASSNAME, null );

			if ( plafClassName == null
					|| plafClassName.equals( "DEFAULT" ) )
				{
				plafClassName =
					UIManager.getSystemLookAndFeelClassName();
				}

			try { UIManager.setLookAndFeel( plafClassName ); }
				catch ( Exception ex ) { }

			MainFrame frm = JCVS.getMainFrame();
			SwingUtilities.updateComponentTreeUI( frm );

			Enumeration enum = ProjectFrameMgr.enumerateProjectFrames();
			for ( ; enum.hasMoreElements() ; )
				{
				SwingUtilities.updateComponentTreeUI
					( (ProjectFrame) enum.nextElement() );
				}
			}
*/
		}
/*
	public Vector
	getServerDefinitions()
		{
		return this.servers;
		}


	public String
	getExecCommandKey( String verb, String extension )
		{
		return extension + "." + verb;
		}


	public String
	getExecCommandArgs( String verb, String extension )
		{
		String result = null;

		String key = this.getExecCommandKey( verb, extension );

		PrefsTuple tup = this.execCmdTable.getTuple( key );

		if ( tup != null )
			{
			result = tup.getValueAt( EXEC_DEF_CMD_IDX );
			}

		return result;
		}


	public String
	getExecCommandEnv( String verb, String extension )
		{
		String result = null;

		String key = this.getExecCommandKey( verb, extension );

		PrefsTuple tup = this.execCmdTable.getTuple( key );

		if ( tup != null )
			{
			result = tup.getValueAt( EXEC_DEF_ENV_IDX );
			}

		return result;
		}


	public PrefsTupleTable
	getExecCmdDefinitions()
		{
		return this.execCmdTable;
		}


	public void
	loadExecCmdDefinitions()
		{
		this.execCmdTable =
			this.userAppPrefs.getTupleTable
				( GLOBAL_EXT_VERB_TABLE, null );

		if ( this.execCmdTable == null )
			{
			this.execCmdTable = new PrefsTupleTable();
			}
		}


	public void
	loadServerDefinitions()
		{
		this.servers = new Vector();

		this.enumerateServerDefinitions( this.defServers.keys() );

		this.enumerateServerDefinitions( this.userServers.keys() );
		}
*/
	/**
	 * This is used to sort the list of hosts presented in the
	 * dialog, although it is a general purpose utility.
	 * Insertionsort - O(n^2) but it is short.
	 *
	 * @author Urban Widmark <urban@svenskatest.se>
	 *
	private void
	sortServerVector( Vector v )
		{
	    for ( int i = 1 ; i < v.size() ; ++i )
			{
			ServerDef B = (ServerDef) v.elementAt( i );

			int j = i;
			for ( ; j > 0 ; --j )
				{
				ServerDef A = (ServerDef) v.elementAt( j - 1 );
				if ( A.compareTo( B ) <= 0 )
					break;
				v.setElementAt( A, j );
				}

			v.setElementAt( B, j );
			}
		}


	public void
	enumerateServerDefinitions( Enumeration enum )
		{
		for ( ; enum.hasMoreElements() ; )
			{
			String key = (String) enum.nextElement();

			if ( ! key.startsWith( "server." ) )
				continue;

			if ( ! this.userServers.getBoolean( key, false ) )
				continue;

			String token = key.substring( "server.".length() );

			String method =
				this.userServers.getProperty
					( "param." + token + ".method", "pserver" );

			String name =
				this.userServers.getProperty( "param." + token + ".name", null );
			String module =
				this.userServers.getProperty( "param." + token + ".module", "" );
			String host =
				this.userServers.getProperty( "param." + token + ".host", "" );
			String user =
				this.userServers.getProperty( "param." + token + ".user", "" );
			String repos =
				this.userServers.getProperty( "param." + token + ".repos", "" );
			String desc =
				this.userServers.getProperty( "param." + token + ".desc", "" );

			if ( name != null )
				this.servers.addElement
					( new ServerDef
						( name, method, module, user, host, repos, desc ) );
			// UNDONE report missing name!
			}

		// Sort the servers so they display nicely.
		// @author Urban Widmark <urban@svenskatest.se>
		sortServerVector( this.servers );
		}
*/
/*
	public void
	loadProjectPreferences( CVSProject project, UserPrefs prefs )
		{
        System.out.println("loadProjectPreferences();");
		String propFilename = this.getUserPrefsFilename();

		String prefsPath =
			CVSCUtilities.exportPath(
				CVSProject.getAdminPrefsPath
					( CVSProject.rootPathToAdminPath
						( project.getLocalRootPath() ) ) );

		File prefsF = new File( prefsPath );

		try {
			UserPrefsFileLoader loader = (UserPrefsFileLoader)
				UserPrefsLoader.getLoader( UserPrefsLoader.FILE_LOADER );

			loader.setFile( prefsF );
			loader.loadPreferences( prefs );

			if ( this.debug )
			System.err.println
				( "Loaded project preferences from '"
					+ prefsF.getPath() + "'" );
			}
		catch ( IOException ex )
			{
			if ( this.debug )
			System.err.println
				( "No project preferences found at '"
					+ prefsF.getPath() + "'" );
			}
		}

	public void
	saveProjectPreferences( CVSProject project, UserPrefs prefs )
		{
		String propFilename = this.getUserPrefsFilename();

		String prefsPath =
			CVSCUtilities.exportPath(
				CVSProject.getAdminPrefsPath
					( CVSProject.rootPathToAdminPath
						( project.getLocalRootPath() ) ) );

		File prefsF = new File( prefsPath );

		try {
			UserPrefsFileLoader loader = (UserPrefsFileLoader)
				UserPrefsLoader.getLoader( UserPrefsLoader.FILE_LOADER );

			loader.setFile( prefsF );
			loader.storePreferences( prefs );

			if ( this.debug )
			System.err.println
				( "Saved project preferences into '"
					+ prefsF.getPath() + "'" );
			}
		catch ( IOException ex )
			{
			System.err.println
				( "Failed storing project preferences into '"
					+ prefsF.getPath() + "', " + ex.getMessage() );
			}
		}
*/
    /**
     * Load the user preferences using
     * @param the specified file read mode
     * @param the destination IserPrefs object
     * @param the filename
     */
	public void
	loadUserPreferences(String loadMode)
		{
            loadPreferences(
                loadMode,
                this.userAppPrefs,
                this.getUserPrefsFilename());
/*
		String propFilename = this.getUserPrefsFilename();

		File prefsF =
			new File( this.userAppPrefs.getUserHome(), propFilename );

		if ( ! prefsF.exists() )
			{
			System.err.println
				( "No user preferences found at '"
					+ prefsF.getPath() + "'" );
			return;
			}

		if ( ! prefsF.canRead() )
			{
			System.err.println
				( "ERROR Can not read user preferences at '"
					+ prefsF.getPath() + "'" );
			return;
			}

		try {
			UserPrefsStreamLoader loader = (UserPrefsStreamLoader)
				UserPrefsLoader.getLoader( UserPrefsConstants.STREAM_LOADER );

			InputStream in = new FileInputStream( prefsF );

			loader.setInputStream( in );
			loader.loadPreferences( this.userAppPrefs );
			in.close();

			System.err.println
				( "Loaded user preferences from '"
					+ prefsF.getPath() + "'" );
			}
		catch ( IOException ex )
			{
			ex.printStackTrace();
			}
*/
		}

/*
	public void
	loadHubPreferences()
		{
//        Thread.dumpStack();
		String propFilename = this.getHubPrefsFilename();

		File prefsF =
			new File( this.ixmHubPrefs.getUserHome(), propFilename );

		if ( ! prefsF.exists() )
			{
			System.err.println
				( "No user preferences found at '"
					+ prefsF.getPath() + "'" );
			return;
			}

		if ( ! prefsF.canRead() )
			{
			System.err.println
				( "ERROR Can not read user preferences at '"
					+ prefsF.getPath() + "'" );
			return;
			}

		try {
			UserPrefsStreamLoader loader = (UserPrefsStreamLoader)
				UserPrefsLoader.getLoader( UserPrefsConstants.STREAM_LOADER );

			InputStream in = new FileInputStream( prefsF );

			loader.setInputStream( in );
			loader.loadPreferences( this.ixmHubPrefs );
			in.close();

			System.err.println
				( "Loaded user preferences from '"
					+ prefsF.getPath() + "'" );
			}
		catch ( IOException ex )
			{
			ex.printStackTrace();
			}
		}
*/
/*
	public void
	loadClientPreferences()
		{
//        Thread.dumpStack();
		String propFilename = this.getClientPrefsFilename();

		File prefsF =
			new File( this.ixmClientPrefs.getUserHome(), propFilename );

		if ( ! prefsF.exists() )
			{
			System.err.println
				( "No user preferences found at '"
					+ prefsF.getPath() + "'" );
			return;
			}

		if ( ! prefsF.canRead() )
			{
			System.err.println
				( "ERROR Can not read user preferences at '"
					+ prefsF.getPath() + "'" );
			return;
			}

		try {
			UserPrefsStreamLoader loader = (UserPrefsStreamLoader)
				UserPrefsLoader.getLoader( UserPrefsConstants.STREAM_LOADER );

			InputStream in = new FileInputStream( prefsF );

			loader.setInputStream( in );
			loader.loadPreferences( this.ixmClientPrefs );
			in.close();

			System.err.println
				( "Loaded user preferences from '"
					+ prefsF.getPath() + "'" );
			}
		catch ( IOException ex )
			{
			ex.printStackTrace();
			}
		}
*/
    /**
     * Load the config editor specs
     * @param the specified file read mode
     * @param the filename
     */
	public void
	loadConfigEditorSpecifications(String mode)
    {
        loadConfigEditorSpecification(mode, APP_CONFIG_SPEC_NAME, appEditSpec);
    }

/*
    public void loadConfigurations(ConfigurationLoaderListener cll)
    {
        cll.percentLoaded(0);
        loadDefaultPreferences();
    }
*/
    /**
     * Load the default user preferences using
     * @param the specified file read mode
     */
	public void
	loadDefaultPreferences(String loadMode)
		{
        UserPrefs thePrefs = this.defaultAppUserPrefs;
        String specURL = "/com/ice/config/defaults.properties";
        if(loadMode.equalsIgnoreCase(UserPrefsConstants.STREAM_LOADER))
        {
            loadPrefsAsStream(thePrefs, specURL);
        }
        else if(loadMode.equalsIgnoreCase(UserPrefsConstants.FILE_LOADER))
        {
            loadPrefsAsFile(thePrefs, specURL);
        }
        else
        {
            //default to stream
            loadPrefsAsStream(thePrefs, specURL);
        }
/*
		String defURL = "/com/ice/config/defaults.properties";
//		String defURL = "/com/ice/jcvsii/defaults.properties";

		UserPrefsStreamLoader loader = (UserPrefsStreamLoader)
			UserPrefsLoader.getLoader( UserPrefsConstants.STREAM_LOADER );

		InputStream in = null;

		try {
			in = ResourceUtilities.openNamedResource( defURL );

			loader.setInputStream( in );
			loader.loadPreferences( this.defaultAppUserPrefs );

			System.err.println
				( "Loaded default preferences from '" + defURL + "'" );
			}
		catch ( IOException ex )
			{
			System.err.println
				( "ERROR loading default preferences from '"
					+ defURL + "'\n      " + ex.getMessage() );
			}
		finally
			{
			if ( in != null )
				{
				try { in.close(); }
				catch ( IOException ex ) { }
				}
			}
*/
		}

    /**
     * Create the <code>ConfigurationController</code>'s needed by this class.
     * Calls the final protected method of class <code>AbstractConfiguration</code>,
     * <code>copyIntoConfigurationControllers(ConfigurationController[] newControllers)</code>,
     * to insert the newly defined controllers into the list of controllers this configuration
     * needs to be aware of.
     * @throws Exception if the <code>ConfigurationController</code> cannot be created successfully.
     */
    protected void constructConfigurationControllers() throws Exception
    {
        ConfigurationController[] defaultControllers = new ConfigurationController[NUM_APP_CONTROLLERS];
        defaultControllers[0] = appConfigurationController = new IceConfigurationController(this.userAppPrefs, this.appEditSpec);
        copyIntoConfigurationControllers(defaultControllers);
    }

    /**
     * Enumerate to stdout the properties in the UserPrefs instance
     */
    protected void enumerate(String title, UserPrefs prefs)
    {
        Enumeration prefskeys = prefs.keys();
        while(prefskeys.hasMoreElements())
        {
            Object key = prefskeys.nextElement();
            Object value = prefs.get(key);
            System.out.println(key + " = " + value);
        }
    }

    /**
     * Load the preference files and increment the model accordingly.
     * @param the incremental range model which tracks our load progress
     */
    public void loadConfigurations(String loadMode, IncrementalBoundedRangeModel iModel)
    {
        loadDefaultPreferences(loadMode);
        iModel.increment();
        loadUserPreferences(loadMode);
        iModel.increment();
    }

    /**
     * @return the dialog title we would like to show
     */
    public String getDialogTitle()
    {
        return("Configuration Dialog");
    }

    /**
     * Save the properties used in this class.
     */
	public void savePreferences()
		{
        saveUserPreferences();
		}

    /**
     * Save the user properties
     */
	public void saveUserPreferences()
    {
		String propFilename = this.getUserPrefsFilename();

		File prefsF = new File( this.userAppPrefs.getUserHome(), propFilename );

		try
        {
			UserPrefsFileLoader loader = (UserPrefsFileLoader)
				UserPrefsLoader.getLoader( UserPrefsLoader.FILE_LOADER );

			loader.setFile( prefsF );

			loader.storePreferences( this.userAppPrefs );

			System.err.println
				( "Stored user preferences to '" + prefsF.getPath() + "'" );
        }
		catch ( IOException ex )
        {
			System.err.println
				( "ERROR storing user preferences to '"
					+ prefsF.getPath() + "'\n      " + ex.getMessage() );
        }
    }

/*
	public void
	loadDefaultServerDefinitions()
		{
		String defURL = "/com/ice/jcvsii/servers.properties";

		UserPrefsStreamLoader loader = (UserPrefsStreamLoader)
			UserPrefsLoader.getLoader( UserPrefsConstants.STREAM_LOADER );

		InputStream in = null;

		try {
			in = ResourceUtilities.openNamedResource( defURL );

			loader.setInputStream( in );
			loader.loadPreferences( this.defServers );

			System.err.println
				( "Loaded default server definitions from '" + defURL + "'" );
			}
		catch ( IOException ex )
			{
			System.err.println
				( "ERROR loading default server definitions from '"
					+ defURL + "'\n      " + ex.getMessage() );
			}
		finally
			{
			if ( in != null )
				{
				try { in.close(); }
				catch ( IOException ex ) { }
				}
			}
		}


	public void
	loadUserServerDefinitions()
		{
		String propFilename = this.getUserServersFilename();

		File prefsF =
			new File( this.userAppPrefs.getUserHome(), propFilename );

		try {
			InputStream in = new FileInputStream( prefsF );

			UserPrefsStreamLoader loader = (UserPrefsStreamLoader)
				UserPrefsLoader.getLoader( UserPrefsConstants.STREAM_LOADER );

			loader.setInputStream( in );
			loader.loadPreferences( this.userServers );
			in.close();

			System.err.println
				( "Loaded user server definitions from '"
					+ prefsF.getPath() + "'" );
			}
		catch ( IOException ex )
			{
			System.err.println
				( "No user server definitions found at '"
					+ prefsF.getPath() + "'" );
			}
		}
*/
/*
	public void
	loadMailCap()
		{
	    File capF;
		InputStream in = null;
		String where = "";

		if ( this.mailcapFileName != null )
			{
			capF = new File( this.mailcapFileName );
			}
		else
			{
			// REVIEW We are using a questionable algorithm here.
			String defMailcapFilename =
				this.getDefaultMailcapFilename();

			String mailcapFileName =
				this.userAppPrefs.getProperty
					( GLOBAL_MAILCAP_FILE, defMailcapFilename );

			capF = new File
				( this.userAppPrefs.getUserHome(), mailcapFileName );
			}

		try {
			if ( capF.exists() && capF.isFile() && capF.canRead() )
				{
				where = capF.getPath();
				in = new FileInputStream( capF );
				}
			else
				{
				where = DEFAULT_MAILCAP_FILENAME;
				in = ResourceUtilities.openNamedResource( where );
				}

			if ( in != null )
				{
				System.err.println
					( "Loading mailcap from '" + where + "'" );
				CommandMap.setDefaultCommandMap
					( new MailcapCommandMap( in ) );
				System.err.println
					( "Loaded mailcap from '" + where + "'" );
				}
			}
		catch ( IOException ex )
			{
			CommandMap.setDefaultCommandMap
				( new MailcapCommandMap() );
			System.err.println
				( "Using default mailcap definition." );
			}
		finally
			{
			if ( in != null )
				{
				try { in.close(); }
				catch ( IOException ex ) {}
				}
			}
		}


	public void
	loadMimeTypes()
		{
	    File mimeF;
		InputStream in = null;
		String where = "";

		if ( this.mimeFileName != null )
			{
			mimeF = new File( this.mimeFileName );
			}
		else
			{
			// REVIEW We are using a questionable algorithm here.
			String defMimeFilename =
				this.getDefaultMimetypesFilename();

			String mimeFileName =
				this.userAppPrefs.getProperty
					( GLOBAL_MIMETYPES_FILE, defMimeFilename );

			mimeF =
				new File( this.userAppPrefs.getUserHome(), mimeFileName );
			}

		try {
			if ( mimeF.exists() && mimeF.isFile() && mimeF.canRead() )
				{
				where = mimeF.getPath();
				in = new FileInputStream( mimeF );
				}
			else
				{
				where = DEFAULT_MIMETYPES_FILENAME;
				in = ResourceUtilities.openNamedResource( where );
				}

			if ( in != null )
				{
				FileTypeMap.setDefaultFileTypeMap
					( new MimetypesFileTypeMap( in ) );
				System.err.println
					( "Loaded mime types from '" + where + "'" );
				}
			}
		catch ( IOException ex )
			{
			FileTypeMap.setDefaultFileTypeMap
				( new MimetypesFileTypeMap() );
			System.err.println
				( "Using default mime types definition." );
			}
		finally
			{
			if ( in != null )
				{
				try { in.close(); }
				catch ( IOException ex ) {}
				}
			}
		}
*/
    /**
     * Return the number of controllers which this class will/has create(d)
     */
    public int getNumControllers()
    {
        return(NUM_APP_CONTROLLERS);
    }

    protected void createActionEventDescriptor()
    {
/*
        //get a handle to the resource manager so that we can look up the name to use
        ResourceMgr rmgr = ResourceMgr.getInstance();
        String menuItemName = rmgr.getUIString( "menu.configuration.edit.default" );
        String shortcutKey = rmgr.getUIString( "menu.configuration.edit.default.accelerator" );
        aed = new ActionEventDescriptor(menuItemName, shortcutKey, true);
  */
    }


    public String getPropertyPrefix()
    {
        return("jcvsii.");
    }
}