package com.ice.config.demo;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;

import com.ice.pref.*;
import com.ice.jcvsii.ResourceMgr;
import com.ice.app.AppSplash;
import com.ice.config.*;

import com.ice.util.URLUtilities;

public class DemoConfigurator1 extends DemoConfigurator
{
    /**
     * Start this sucker up.
     * Call <code>instanceMain(argv)</code> on the configurator <code>instance</code>
     */
	static public void main( String[] argv )
    {
		Configurator app = new DemoConfigurator1();
		DemoConfigurator.instance = (DemoConfigurator1)app;
        try
        {
		    app.initialize( argv, "demo1", "com.ice.config.demo.rsrcui");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            System.exit(1);
        }
    }

    protected Configuration[] createConfigurations()
    {
		demoConfiguration = DemoConfiguration1.getInstance();

        //build an array for faceless access to the Configurations
        return(new Configuration[]{demoConfiguration});
    }

    protected String getSplashScreenName()
    {
        return("Demo 1 Configurator");
    }

    protected String getConfigToolDisplayName()
    {
        return("Demo 1 Configuration Tool");
    }

}