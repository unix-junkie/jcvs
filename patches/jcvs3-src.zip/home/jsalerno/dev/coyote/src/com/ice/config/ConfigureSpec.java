package com.ice.config;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import javax.swing.*;
import java.util.Vector;
/**
 * This class allows the editors to deal with the data for a UserPrefs element appropriately.
 * An attribute, whose metadata is reflected here, can also be set to
 *  be not-visible and not-editable.
 * @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
 * @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
 *
 * @version $Revision: 1.6 $
 */
public
class		ConfigureSpec
implements	ConfigureConstants, java.io.Serializable
	{

	private String		key;
	private String		type;
	private String		path;
	private String		propName;
	private String		description;
	private String		help;

	private String[]	choices;

    /** added jsalerno - we can elect to have attributes immutable **/
    private boolean editable;
    /** added jsalerno - we can elect to have attributes invisible **/
    private boolean visible;

	public
	ConfigureSpec
			( String key, String type, String path,
				String name, String desc, String help,
				String[] choices )
		{
        this(key, type, path, name, desc, help, choices, true, true);
        }

	public ConfigureSpec(
        String key,
        String type,
        String path,
        String name,
        String desc,
        String help,
        String[] choices,
        boolean editable,
        boolean visible)
    {
		this.key = key;
		this.type = type;
		this.path = path;
		this.propName = name;
		this.description = desc;
		this.help = help;
		this.choices = choices;

		this.editable = editable;
		this.visible = visible;
		}

	public String
	getKey()
		{
		return this.key;
		}

	public String
	getName()
		{
		int index = this.path.lastIndexOf( "." );
		if ( index == -1 )
			return this.path;
		else
			return this.path.substring( index + 1 );
		}

	public String
	getPropertyPath()
		{
		return this.path;
		}

	public String
	getPropertyType()
		{
		return this.type;
		}

	public String
	getPropertyName()
		{
		return this.propName;
		}

	public String
	getDescription()
		{
		return this.description;
		}

	public String
	getHelp()
		{
		return this.help;
		}

	public String[]
	getChoices()
		{
		return this.choices;
		}

	public boolean
	isStringArray()
		{
		return this.type.equals( CFG_STRINGARRAY );
		}

	public boolean
	isTupleTable()
		{
		return this.type.equals( CFG_TUPLETABLE );
		}

	public String
	toString()
		{
		return "[" + this.type + "," + this.propName
			+ "," + this.description + "]";
		}

    public boolean visible(){return(visible);}
    public boolean editable(){return(editable);}
	}

