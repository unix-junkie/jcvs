package com.ice.jcvsii;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.text.MessageFormat;
import java.util.ResourceBundle;
import java.util.MissingResourceException;
/**
 * The resource manager for basically loading bundles
 *
 * @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
 * @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
 *
 * @version $Revision: 1.2 $
 */
public
class		ResourceMgr
	{
	static public final String		RCS_ID = "$Id: ResourceMgr.java,v 1.2 2002/01/02 01:59:38 jsalerno Exp $";
	static public final String		RCS_REV = "$Revision: 1.2 $";

	/**
	 * The instance of the ONLY ResourceMgr.
	 */
	private static ResourceMgr		instance;

	/**
	 * Set to true to get processing debugging on stderr.
	 */
	private boolean					debug;

	/**
	 * The manager's name. Currently, used only to improved debugging output.
	 */
	private String					name;
    //added jsalerno 070801
    private String rsrcName;
	/**
	 * The user interface resource bundle. This includes strings like menu
	 * items, window titles, user prompts, field labels, etc.
	 */
	private ResourceBundle			ui;


	public static ResourceMgr
	getInstance()
		{
		return ResourceMgr.instance;
		}

	public static void
	initializeResourceManager( String name )
		{
            initializeResourceManager(name, "com.ice.jcvsii.rsrcui");
        }

	public static void
	initializeResourceManager( String name , String rsrcName)
		{
		ResourceMgr.instance = new ResourceMgr( name , rsrcName);
		ResourceMgr.instance.initializeResources(rsrcName);
		}

	public
	ResourceMgr()
		{
		this.name = "DEFAULT";
		}

	public
	ResourceMgr( String name , String rsrcName)
		{
		this.name = name;
		this.rsrcName = rsrcName;
		}

	public String
	getUIString( String key )
		{
		return this.ui.getString( key );
		}

	public String
	getUIFormat( String key, Object[] args )
		{
		return MessageFormat.format
			( this.ui.getString( key ), args );
		}

	private void
	printResourceInfo( String name, ResourceBundle rb )
		{
		System.err.println
			( "Loaded resource bundle '" + name + "'." );

	//  JDK2 required...
	//	System.err.println
	//		( "   " + name + ".Locale = " + rb.getLocale() );
		}

	public void
	initializeResources()
		{
            initializeResources("com.ice.jcvsii.rsrcui");
        }

	public void
	initializeResources(String rbnm)
		{
//		String rbnm;
		try {
			// USER INTERFACE BUNDLE
//			rbnm = "com.ice.jcvsii.rsrcui";
			this.ui = ResourceBundle.getBundle( rbnm );
			this.printResourceInfo( rbnm, this.ui );
			}
		catch ( MissingResourceException ex )
			{
			ex.printStackTrace();
			}
		}

	}


// myResourceBundle.getString("OkKey")

