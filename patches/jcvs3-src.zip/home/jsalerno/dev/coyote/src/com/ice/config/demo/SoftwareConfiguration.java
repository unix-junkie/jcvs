package com.ice.config.demo;

import com.ice.config.*;
import com.ice.pref.UserPrefs;
import com.ice.jcvsii.ResourceMgr;

/**
 * Title:        Netwxs
 * Description:  Internet Mobile Exchange
 * Copyright:    Copyright (c) Net:wxs Pty Ltd
 * Company:      Net:WxS Pty Ltd
 * @author Julian Salerno, julian@practica.com.au
 * @version 1.0
 */

public class SoftwareConfiguration extends AbstractConfiguration
{
    private static SoftwareConfiguration instance;
    protected static final String SOFTWARE_CONFIG_SPEC_NAME = "/com/ice/config/demo/softwareConfigSpec.properties";
    public static final int NUM_SOFTWARE_CONTROLLERS = 1;
    private ConfigurationController runtimeConfigurationController;

	static
		{
		SoftwareConfiguration.instance = new SoftwareConfiguration("software");
		}

	public static SoftwareConfiguration
	getInstance()
		{
		return SoftwareConfiguration.instance;
		}

	private UserPrefs				defaultSoftwarePrefs;
    private UserPrefs				softwarePrefs;
    private UserPrefs				softwareSpec;
	private String					softwarePrefsFilename, softwarePrefsDefaultsFilename;

    public SoftwareConfiguration(String name)
    {
        super(name);//userHome

        //the hub.properties
            this.softwareSpec = null;
            this.softwarePrefs = null;
		    this.defaultSoftwarePrefs = null;

    }

	public void initializePreferences( String prefix , String userHome)
    {
        super.initializePreferences(prefix, userHome);

        //the data
		this.defaultSoftwarePrefs = new UserPrefs( "Runtime.SoftwareReleaseConfigDefaults", null );
        setUserHome(defaultSoftwarePrefs);

		this.softwarePrefs = new UserPrefs( "Runtime.SoftwareReleaseConfig", defaultSoftwarePrefs );
        setUserHome(softwarePrefs);

		this.softwareSpec = new UserPrefs( "Runtime.SoftwareConfigSpec", null );
        setUserHome(softwareSpec);

    }

    public void setPropertyPrefixes(String prefix)
    {
		this.defaultSoftwarePrefs.setPropertyPrefix(prefix);
		this.softwarePrefs.setPropertyPrefix(prefix);
		this.softwareSpec.setPropertyPrefix(prefix);
    }

    public void loadConfigurations(String loadMode, IncrementalBoundedRangeModel iModel)
    {
        loadSoftwarePreferences(loadMode);
        iModel.increment();
        if(DEBUG)
            softwarePrefs.list(System.out);
    }

	public void loadSoftwarePreferences(String loadMode)
    {
        loadPreferences(loadMode, this.softwarePrefs, this.getSoftwarePrefsFilename());
        loadPreferences(loadMode, this.defaultSoftwarePrefs, this.getSoftwarePrefsDefaultsFilename());
    }

	public void loadConfigEditorSpecifications(String loadMode)
    {
        loadConfigEditorSpecification(loadMode, SOFTWARE_CONFIG_SPEC_NAME, softwareSpec);
    }

	public String getSoftwarePrefsFilename(){return this.softwarePrefsFilename;}
	public String getSoftwarePrefsDefaultsFilename(){return this.softwarePrefsDefaultsFilename;}

	protected int establishOSDistinctions()
    {
		int osType = super.establishOSDistinctions();
        switch(osType)
        {
            default:
    			this.softwarePrefsFilename = "/com/ice/config/demo/software.properties";
    			this.softwarePrefsDefaultsFilename = "/com/ice/config/demo/software_defaults.properties";
                break;
        }
        return(osType);
    }

    /**
     * Construct the software runtime conbfiguration controllers
     * @throws IOException if something goes drastically wrong
     */
    protected void constructConfigurationControllers() throws Exception
    {
        ConfigurationController[] runtimeConfigurationControllers = new ConfigurationController[NUM_SOFTWARE_CONTROLLERS];
        runtimeConfigurationControllers[0] = runtimeConfigurationController =
            new DefaultConfigurationController(this.softwarePrefs, this.softwareSpec);

        copyIntoConfigurationControllers(runtimeConfigurationControllers);;
    }

	public void savePreferences()
    {
        saveSoftwareProperties("demo software properties");
    }

	public synchronized void saveSoftwareProperties( String header )
    {
        storePreferencesToProperties(this.softwarePrefs, this.getSoftwarePrefsFilename(), header);
    }

    public UserPrefs getSoftwarePrefs(){return(softwarePrefs);}

    public String getDialogTitle()
    {
        /**@todo: implement this com.ice.config.AbstractConfiguration abstract method*/
        return("Runtime Configuration");
    }

    /**
     * Return the number of controllers which this class will/has create(d)
     */
    public int getNumControllers()
    {
        return(NUM_SOFTWARE_CONTROLLERS);
    }

    protected void createActionEventDescriptor()
    {
        //get a handle to the resource manager so that we can look up the name to use
        ResourceMgr rmgr = ResourceMgr.getInstance();
        String menuItemName = rmgr.getUIString( "menu.configuration.edit.runtime" );
        String shortcutKey = rmgr.getUIString( "menu.configuration.edit.runtime.accelerator" );
        aed = new ActionEventDescriptor(menuItemName, shortcutKey, true);
    }

    public String getPropertyPrefix()
    {
        return("");
    }
}