package com.ice.config.demo;

import com.ice.config.*;
import com.ice.pref.UserPrefs;
import com.ice.jcvsii.ResourceMgr;

/**
 * Title:        Netwxs
 * Description:  Internet Mobile Exchange
 * Copyright:    Copyright (c) Net:wxs Pty Ltd
 * Company:      Net:WxS Pty Ltd
 * @author Julian Salerno, julian@practica.com.au
 * @version 1.0
 */

public class DemoConfiguration1 extends DemoConfiguration
{
    private static DemoConfiguration1 instance;
    protected static final String DEMO_1_CONFIG_SPEC_NAME = "/com/ice/config/demo/demo1ConfigSpec.properties";
    public static final int DEMO_1_NUM_CONTROLLERS = 1;
/*
    protected String getDemoSpecName()
    {
        return(DEMO_CONFIG_SPEC_NAME);
    }
*/
	static
		{
		DemoConfiguration1.instance = new DemoConfiguration1("demo1");
		}

	public static DemoConfiguration
	getInstance()
		{
		return DemoConfiguration1.instance;
		}

    public DemoConfiguration1(String name)
    {
        super(name);
    }

	protected int establishOSDistinctions()
    {
		int osType = super.establishOSDistinctions();
        switch(osType)
        {
            default:
    			this.demoPrefsFilename = "/com/ice/config/demo/demo1.properties";
    			this.demoPrefsDefaultsFilename = "/com/ice/config/demo/demo1_defaults.properties";
                break;
        }
        return(osType);
    }

    /**
     * Construct the software runtime conbfiguration controllers
     * @throws Exception if something goes drastically wrong
     */
    protected void constructConfigurationControllers() throws Exception
    {
        ConfigurationController[] demoConfigurationControllers =
            new ConfigurationController[DEMO_1_NUM_CONTROLLERS];
        demoConfigurationControllers[0] = demoConfigurationController =
            new DefaultConfigurationController(this.demoPrefs, this.demoSpec);

        copyIntoConfigurationControllers(demoConfigurationControllers);;
    }

	public void loadConfigEditorSpecifications(String loadMode)
    {
        loadConfigEditorSpecification(loadMode, DEMO_1_CONFIG_SPEC_NAME, demoSpec);
    }

    public String getDialogTitle()
    {
        /**@todo: implement this com.ice.config.AbstractConfiguration abstract method*/
        return("Demo Configuration 1");
    }

    /**
     * Return the number of controllers which this class will/has create(d)
     */
    public int getNumControllers()
    {
        return(DEMO_1_NUM_CONTROLLERS);
    }

    protected void createActionEventDescriptor()
    {
        //get a handle to the resource manager so that we can look up the name to use
        ResourceMgr rmgr = ResourceMgr.getInstance();
        String menuItemName = rmgr.getUIString( "menu.configuration.edit.demo1" );
        String shortcutKey = rmgr.getUIString( "menu.configuration.edit.demo1.accelerator" );
        aed = new ActionEventDescriptor(menuItemName, shortcutKey, true);
    }

    public String getPropertyPrefix()
    {
        return("");
    }
}