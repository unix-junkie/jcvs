package com.ice.config.editor;

import javax.swing.table.AbstractTableModel;
import javax.swing.event.TableModelEvent;

public abstract class MutableTableModel extends AbstractTableModel
{
    private boolean listening = false;
    public void setListening(boolean listen)
    {
        this.listening = listen;
    }
    public boolean listening(){return(listening);}
    public void fireTableChanged(TableModelEvent e)
    {
        if(listening())
            super.fireTableChanged(e);
    }
}