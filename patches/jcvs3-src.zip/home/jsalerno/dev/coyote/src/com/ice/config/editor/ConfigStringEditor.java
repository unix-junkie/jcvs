package com.ice.config.editor;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

import com.ice.config.*;
import com.ice.pref.UserPrefs;
import com.ice.util.AWTUtilities;

public
class		ConfigStringEditor
extends		ConfigureEditor
	{
	protected JTextField	strField;


	public
	ConfigStringEditor()
		{
		super( "String" );
		}

	public void
	requestInitialFocus()
		{
		this.strField.requestFocus();
		this.strField.selectAll();
		}

	protected JPanel
	createEditPanel()
		{
		JPanel result = new JPanel();
		result.setLayout( new GridBagLayout() );
		result.setBorder( new EmptyBorder( 5, 3, 3, 3 ) );

		int col = 0;
		int row = 0;

		this.strField = new JTextField( "" );
		AWTUtilities.constrain(
			result, this.strField,
			GridBagConstraints.HORIZONTAL,
			GridBagConstraints.WEST,
			0, row++, 1, 1,  1.0, 0.0,
			new Insets( 3, 0, 0, 0 ) );

		return result;
		}

	public void
	edit( UserPrefs prefs, ConfigureSpec spec, ConfigPropertyChangeListener changeListener )
		{
		super.edit( prefs, spec, changeListener);
        setUIValue(prefs, spec);
		}

    protected void setUIValue(UserPrefs prefs, ConfigureSpec spec)
    {
        super.setUIValue(prefs, spec);

		String val = prefs.getProperty( spec.getPropertyName(), null );

		if ( val != null )
        {
			this.strField.setText( val );
        }
		else
        {
			this.strField.setText( "" );
		}
    }

    protected void setPrefsValue(UserPrefs prefs, ConfigureSpec spec)
    {
		String propName = spec.getPropertyName();

		String oldVal = prefs.getProperty( propName, "" );
		String newVal = this.strField.getText();

		if ( ! newVal.equals( oldVal ) )
        {
			prefs.setProperty( propName, newVal );

            System.out.println("ConfigStringEditor.saveChanges() to "+propName);
            System.out.println("\told val\t "+oldVal);
            System.out.println("\tnew val\t "+newVal);

        }
    }

	public void
	saveChanges( UserPrefs prefs, ConfigureSpec spec )
		{
            setPrefsValue(prefs, spec);
		}

    protected void addListeners(ConfigPropertyChangeListener changeListener)
    {
        addKeyListener(strField, changeListener);
    }

	protected void disableComponent()
    {
        strField.setEditable(false);
    }

	protected void enableComponent()
    {
        strField.setEditable(true);
    }
}