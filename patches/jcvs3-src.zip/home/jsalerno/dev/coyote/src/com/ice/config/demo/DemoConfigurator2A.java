package com.ice.config.demo;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;

import com.ice.pref.*;
import com.ice.jcvsii.ResourceMgr;
import com.ice.app.AppSplash;
import com.ice.config.*;

import com.ice.util.URLUtilities;

public class DemoConfigurator2A extends DemoConfigurator
{
    /**
     * Start this sucker up.
     * Call <code>instanceMain(argv)</code> on the configurator <code>instance</code>
     */
	static public void main( String[] argv )
    {
		Configurator app = new DemoConfigurator2A();
		DemoConfigurator.instance = (DemoConfigurator2A)app;
        try
        {
		    app.initialize( argv, "demo2A", "com.ice.config.demo.rsrcui");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            System.exit(1);
        }
    }

    protected Configuration[] createConfigurations()
    {
		demoConfiguration = DemoConfiguration2A.getInstance();

        //build an array for faceless access to the Configurations
        return(new Configuration[]{demoConfiguration});
    }

    protected String getSplashScreenName()
    {
        return("Demo 2A Configurator");
    }

    protected String getConfigToolDisplayName()
    {
        return("Demo 2A Configuration Tool");
    }

}