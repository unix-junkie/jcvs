package com.ice.config;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.io.*;
import java.awt.*;
import java.text.DateFormat;
import java.util.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import javax.swing.border.*;
import javax.swing.event.*;

import com.ice.util.AWTUtilities;
import com.ice.pref.UserPrefs;
import com.ice.pref.PrefsTupleTable;
import com.ice.config.editor.*;
import com.ice.jcvsii.ResourceMgr;
/**
 * Each panel is driven by a single <code>ConfigurationController<code>.
 * There is a ref to the tree component for path selection and expansion.
 * There is also a <code>ConfigPropertyChangeListener</code> to notify of property changes.
 *  <code>ConfigurationController</code>'s.
 * This class replaces the <code>ConfigPanel</code>.
 *
 * @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
 * @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
 *
 * @version $Revision: 1.16 $
 */
public
class		ConfigurationPanel
extends		JPanel
implements	ConfigureConstants
{
    /** the panel in which to place contents **/
	protected JPanel		editorPanel = null;
    /** the editor in use **/
	protected ConfigureEditor		currEditor = null;
    /** the currently selected node **/
	protected ConfigureTreeNode		currSelection = null;
    /** the tree containing the nodes **/
    protected ConfigureTree tree;
    /** the controller with whom we are in communication **/
    protected ConfigurationController configurationController;
    /** the title that should be displayed to reflect our current node selection **/
    protected String title = null;

    /** jsalerno **/
    protected ConfigPropertyChangeListener changeListener;

    /**
     * Constructor
     */
	public
	ConfigurationPanel(
        ConfigurationController configurationController,
        ConfigureTree tree,
        ConfigPropertyChangeListener changeListener)
    {
        super();

		this.configurationController = configurationController;
		this.tree = tree;
        this.changeListener = changeListener;

        configurationController.setConfigurationPanel(this);

		this.setLayout( new BorderLayout() );
		this.setBorder( new EmptyBorder( 5, 5, 5, 5 ) );

		this.editorPanel = new EditorPanel();
		this.editorPanel.setLayout( new BorderLayout() );
		this.editorPanel.setBorder( new EmptyBorder( 5, 5, 5, 5 ) );

		this.add( BorderLayout.CENTER, this.editorPanel );
    }

    /**
     * @return the editor factory used for creating editors withi this panel's controller's domain
     */
	public ConfigureEditorFactory
	getEditorFactory()
		{
		return this.configurationController.getEditorFactory();
		}

    /**
     * @param set the editor factory used for creating editors withi this panel's controller's domain
     */
	public void
	setEditorFactory( ConfigureEditorFactory factory )
		{
		this.configurationController.setEditorFactory(factory);
		}

    /**
     * Commit the changes to file that have happened within this panel's controller
     */
	public void
	commit()
		{
        if(Configuration.DEBUG)
            System.out.println("ConfigurationPanel '"+configurationController.getPrefsName()+"' .commit()");
        Vector specVector = configurationController.getSpecsAsVector();
		for ( Enumeration enum = specVector.elements() ; enum.hasMoreElements() ; )
			{
			ConfigureSpec spec =
				(ConfigureSpec) enum.nextElement();

			ConfigureEditor editor =
                this.configurationController.getEditorFactory().createEditor( spec.getPropertyType() );

            if(Configuration.DEBUG)
            {
                System.out.println("\tspec = \t"+ spec.getName());
                System.out.println("\teditor = \t"+ editor);
                System.out.println("\tcurrSelection = \t"+ currSelection);
                System.out.println();
			}
            if ( ( editor != null ) && (this.currSelection != null) )
				{
				editor.commit(
                    spec,
                    this.configurationController.getWorkingCopy(),
                    this.configurationController.getUserPrefs() );
				}
			else
				{
				// UNDONE report this!!!
				}
			}
		}

    /**
     * Commit the changes to file that have happened within this panel's controller
     */
	public void
	undoUncommitted()
		{
        /**
         * We need to deal with the currently-visible edit panel before we rollback
         *  the non-visible properties
         */
        undoCurrentEdit();

        /**
         * Then we walk thru each of the specs and rollback the working copies
         *  to values matching the originals. We do this using the commit() function.
         */
        Vector specVector = configurationController.getSpecsAsVector();
		for ( Enumeration enum = specVector.elements() ; enum.hasMoreElements() ; )
			{
			ConfigureSpec spec =
				(ConfigureSpec) enum.nextElement();
			ConfigureEditor editor =
                this.configurationController.getEditorFactory().createEditor( spec.getPropertyType() );

			if ( ( editor != null ) && (this.currSelection != null) )
				{
				editor.commit(
                    spec,
                    this.configurationController.getUserPrefs(),
                    this.configurationController.getWorkingCopy() );
				}
			else
				{
				// UNDONE report this!!!
                //  - not necessarily
				}
			}
		}

	private void
	undoEdit(ConfigureEditor editor, ConfigureSpec spec)
		{
		if ( this.currSelection != null && this.currEditor != null )
			{
			this.currEditor.saveChanges
				( this.configurationController.getWorkingCopy(), this.currSelection.getConfigureSpec() );
			}
		}

    /**
     * Save the edit which is current
     */
	public void
	saveCurrentEdit()
		{
		if ( this.currSelection != null && this.currEditor != null )
			{
			this.currEditor.saveChanges(
                this.configurationController.getWorkingCopy(),
                this.currSelection.getConfigureSpec() );
			}
		}

    /**
     * Undo the edit which is current
     */
	public void
	undoCurrentEdit()
		{
		if ( this.currSelection != null && this.currEditor != null )
			{
                try
                {
                    this.currEditor.preUndo();
			        this.currEditor.undoChanges(
                        this.configurationController.getUserPrefs(),
                        this.currSelection.getConfigureSpec() );
                    this.currEditor.postUndo();
                }
                catch(UnsupportedOperationException uoe)
                {
                    Thread.dumpStack();
                }
			}
		}



    /**
     * The user has edited a property.
     * @param the value of the new object
     */
	public String
	valueChanged( Object obj)
		{
        if(Configuration.DEBUG)
        {
            System.out.println("ConfigurationPanel.valueChanged("+obj+")");
        }
		if ( obj == this.currSelection )
        {
			return(title);
        }
		this.saveCurrentEdit();

		synchronized ( this.editorPanel.getTreeLock() )
			{
			this.editorPanel.removeAll();
			title = "";

			if ( obj != null )
				{
				ConfigureTreeNode node =
					this.currSelection =
						(ConfigureTreeNode) obj;

				if ( node.isLeaf() )
					{
					ConfigureSpec spec = node.getConfigureSpec();

					if ( spec != null )
						{
						this.currEditor =
							this.configurationController.getEditorFactory().createEditor
								( node.getConfigureSpec().getPropertyType() );

						if ( this.currEditor == null )
							this.currEditor =
    							this.configurationController.getEditorFactory().createEditor(CFG_DEFAULT);

						StringBuffer sb = new StringBuffer();

						sb.append( spec.getName() );

						if ( this.currEditor != null )
							{
							if ( this.currEditor.isModified
									( spec, this.configurationController.getWorkingCopy(), this.configurationController.getUserPrefs() ) )
								{
								sb.append( " *" );
								}
							}
						else
							{
							sb.append( " (NO EDITOR)" );
							}

            			title = sb.toString();

						if ( this.currEditor != null )
							{
							this.currEditor.preEdit();
							this.currEditor.edit( this.configurationController.getWorkingCopy(), spec, changeListener );
							this.currEditor.postEdit();

							this.editorPanel.add
								( BorderLayout.CENTER, this.currEditor );

							this.editorPanel.revalidate();

							this.currEditor.requestInitialFocus();
							}
						}
					}
				else
					{
					this.currEditor = null;
					this.currSelection = null;
                    title = node.getName();
					}
				}
			}

		this.editorPanel.repaint( 250 );
        return(title);
		}

    /**
     * Add an editor to this list of editors this panel's controller's factory keeps
     * @param the name of the editor
     * @param the editor object
     */
	public void
	addEditor( String type, ConfigureEditor editor )
		{
		if ( this.configurationController.getEditorFactory() instanceof DefaultConfigureEditorFactory )
			{
			((DefaultConfigureEditorFactory) this.configurationController.getEditorFactory()).addEditor
				( type, editor );
			}
		else
			{
			(new Throwable
				( "can not add editor, factory is not class "
						+ "DefaultConfigureEditorFactory" )).
					printStackTrace();
			}
		}

    /**
     * Edit a property with the given name
     * @param the property name
     */
	public void
	editProperty( String propName )
		{
		String[] propNames = { propName };
		this.editProperties( propNames );
		}

    /**
     * Edit propertied with the given names
     * @param the property names
     */
	public void
	editProperties( String[] propNames )
		{
        if(Configuration.DEBUG)
            System.out.println("ConfigurationPanel.editProperties(String[] propNames)");
        Vector specVector = configurationController.getSpecsAsVector();
		int numSpecs = specVector.size();

		Vector pathV = new Vector();

		for ( int i = propNames.length - 1 ; i >= 0 ; --i )
			{
			String propName = propNames[i];

			for ( int j = 0 ; j < numSpecs ; ++j )
				{
				ConfigureSpec spec = (ConfigureSpec)
					specVector.elementAt(j);

				if ( spec.getPropertyName().equals( propName ) )
					{
					pathV.addElement( spec.getPropertyPath() );
					break;
					}
				}
			}

		if ( pathV.size() > 0 )
			{
			String[] paths = new String[ pathV.size() ];
			pathV.copyInto( paths );
			this.editPaths( paths );
			}
		}

    /**
     * Change the value of the selected path to
     * @param the desired selection
     */
	public void
	editPath( String path )
		{
		String[] paths = { path };
		this.editPaths( paths );
		}

    /**
     * Change the value of the selected path to expand
     * @param the desired selections
     */
	public void
	editPaths( String[] paths )
		{
        ConfigureTreeModel treeModel = configurationController.getConfigurationTreeModel();
		for ( int i = paths.length - 1 ; i >= 0 ; --i )
			{
			ConfigureTreeNode node = treeModel.getPathNode( paths[ i ] );

			if ( node != null )
				{
				TreePath tPath = new TreePath( node.getPath() );
				tree.expandPath( tPath );
				if ( i == 0 )
					tree.setSelectionPath( tPath );
				}
			}
		}

    /**
     * @return a reference to the 'working copy' of the loaded UserPrefs
     */
    public UserPrefs getPrefs()
    {
        return(configurationController.getWorkingCopy());
    }

    /**
     * @return a reference to the 'original' loaded UserPrefs
     */
    public UserPrefs getOriginalPrefs()
    {
        return(configurationController.getUserPrefs());
    }

    /**
     * @return a reference to the current node selection
     */
    public ConfigureTreeNode getCurrSelection()
    {
        return(currSelection);
    }
}