package com.ice.config;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.util.Vector;
import java.util.Enumeration;

import com.ice.pref.UserPrefs;
/**
 * This class provides for the reading of specs.
 *
 * @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
 * @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
 *
 * @version $Revision: 1.7 $
 */
public
class		ConfigureUtil
implements	ConfigureConstants
	{

	public static Vector
	readConfigSpecification( UserPrefs specs )
		throws InvalidSpecificationException
		{
		String specSfx = ".spec";
		Vector result = new Vector();
		String propPfx = specs.getPropertyPrefix();

		for ( Enumeration enum = specs.keys()
				; enum.hasMoreElements() ; )
			{
			String key = (String) enum.nextElement();

			if ( ! key.endsWith( specSfx ) )
				continue;

			// Strip off the property prefix to prepare for getProperty().
			String keyBase = specs.getBaseName( key );

			// Get the property type using this key.
			String type = specs.getProperty( keyBase, null );
/*
			if ( type == null )
                type = "string";
*/
			// Strip off the ".spec" suffix.
			keyBase =
				keyBase.substring
					( 0, (keyBase.length() - specSfx.length()) );

			// Get the other property parameters using the various suffixes.
			String path =
				specs.getProperty( keyBase + ".path", null );
			String name =
				specs.getProperty( keyBase + ".name", null );
			String desc =
				specs.getProperty( keyBase + ".desc", null );
			String help =
				specs.getProperty( keyBase + ".help", null );
			String visible =
				specs.getProperty( keyBase + ".visible", null );
			String editable =
				specs.getProperty( keyBase + ".editable", null );

            boolean isVisible = (visible == null) ? true :
                (visible.equalsIgnoreCase("true") ? true : false) ;

            boolean isEditable = (editable == null) ? true :
                (editable.equalsIgnoreCase("true") ? true : false) ;

			String reason = "";
			boolean invalid = false;
			if ( type == null )
				{
				invalid = true;
				reason = "the spec has no property type";
				}
			else if ( path == null )
				{
				invalid = true;
				reason = "the spec has no config tree path";
				}
			else if ( name == null )
				{
				invalid = true;
				reason = "the spec has no property name";
				}
			else if (
                ( type.equals( "choice" ) )
                ||
                ( type.equals( "combo" ) )
                ||
                ( type.equals( "combo.editable" ) )
            )
//			else if ( type.equals( "choice" ) )
				{
				Vector sV = new Vector();
				for ( int ci = 0 ; ci < 32 ; ++ci )
					{
					String item =
						specs.getProperty
							( (keyBase + ".choice." + ci), null );
					if ( item == null )
						break;
					sV.addElement( item );
					}

				if ( sV.size() < 2 )
					{
					invalid = true;
					reason = "choice config has no choices (need 2 or more)";
					}
				else
					{
					String[] choices = new String[ sV.size() ];
					sV.copyInto( choices );

					ConfigureSpec spec =
						new ConfigureSpec
							( keyBase,
								type.trim(),
								path.trim(),
								name.trim(),
								( (desc == null) ? desc : desc.trim() ),
								( (help == null) ? help : help.trim() ),
								choices,
                                isEditable,
                                isVisible
							);

					result.addElement( spec );
					}
				}
			else
				{
				ConfigureSpec spec =
					new ConfigureSpec
						( keyBase,
							type.trim(),
							path.trim(),
							name.trim(),
							( (desc == null) ? desc : desc.trim() ),
							( (help == null) ? help : help.trim() ),
							null,
                            isEditable,
                            isVisible
						);

				result.addElement( spec );
				}

			if ( invalid )
				{
				throw new InvalidSpecificationException
					( "invalid configuration specification for '"
						+ keyBase + "', " + reason );
				}
			}

		return result;
		}

	}