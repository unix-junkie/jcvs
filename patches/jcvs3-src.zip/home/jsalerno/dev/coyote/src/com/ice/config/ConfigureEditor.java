package com.ice.config;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.table.*;
import javax.swing.text.*;

import java.util.Enumeration;
import java.util.Vector;


import com.ice.pref.*;
import com.ice.util.AWTUtilities;
/**
 * The common functionality of all editors is coded here.
 *
 * @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
 * @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
 *
 * @version $Revision: 1.19 $
 */
public
abstract
class		ConfigureEditor
extends		JPanel
	{
	protected UserPrefs			uprefs = null;
	protected ConfigureSpec		uspec = null;

	protected boolean			helpIsShowing = false;

	protected JPanel			helpPanel = null;
	protected JTextArea			helpText = null;
	protected JButton			helpButton = null;

	protected JPanel			editPanel = null;
	protected JScrollPane		editScroller = null;

	protected JPanel			editorPanel = null;
	protected JPanel			descPan = null;
	protected JTextArea			descText = null;
	protected int				descOffset = 25;

    //we may want any editor to have a number document listener for changes, so ..
    protected Vector        documentListeners = new Vector();
    protected boolean       listenersAdded;

    /** introduced jsalerno - this is to listen for changes
     *  essentially to activate the SAVE and CANCEL buttons.
     *  We allow a single listener for changes during this edit **
    protected ConfigPropertyChangeListener changeListener;*/

	abstract public void
		saveChanges( UserPrefs prefs, ConfigureSpec spec );

    /**
     * This is support for rollback of the value of the working copy of the
     * UserPrefs component, but more importantly, is where the support for the
     *  rollback of the *currently-on-screen* editor is provided.
     * Non-visible editors are easily rolled back with an 'inverse' commit statement
     *  whereas we need to make sure that the current edit panel on-screen is
     *  also rolled back if changes have been made to it.
     *
	abstract public void
		undoChanges( UserPrefs prefs, ConfigureSpec spec );
<pre>
        This was originally abstract, but the order must be maintained:
        1. setUIValue
        2. setPrefsValue

        otherwise, the UI will never roll back successfully, so we make
        these the abstractions

        of course, if you need to, you can override this behaviour, say, to
        insert your own editor hooks
</pre>
	*/
    public void
	undoChanges( UserPrefs prefs, ConfigureSpec spec )
		{
            setUIValue(prefs, spec);
            setPrefsValue(prefs, spec);
    }

    public void preUndo()
    {
        setDocumentListenersOff();
    }

    public void postUndo()
    {
        setDocumentListenersOn();
    }

    public void preEdit()
    {
        setDocumentListenersOff();
    }

    public void postEdit()
    {
        setDocumentListenersOn();
    }

    /**
     * Do we support rollback of already-made edits ?
     * There are a number of ways this could have been handled.
     * We could have written a nice reflective piece of code which looked for the
     *  presence of the <code>undoChanges()</code> method.
     * But, if that method is absent, then it is also likely that this method
     *  is absent !!!
     * So, we can delegate this responsibility down to the editor components themselves.
     *
	abstract public boolean supportsRollback();
*/
	abstract public void
		requestInitialFocus();

	abstract protected JPanel
		createEditPanel();

	protected abstract void disableComponent();
	protected abstract void enableComponent();

    protected void setUIValue(UserPrefs prefs, ConfigureSpec spec)
    {
        if(spec.editable())
        {
            if(Configuration.DEBUG)
                System.out.println("...enabling "+spec.getName());
            enableComponent();
        }
        else
        {
            if(Configuration.DEBUG)
                System.out.println("...disabling "+spec.getName());
            disableComponent();
        }
    }

    abstract protected void
        setPrefsValue(UserPrefs prefs, ConfigureSpec spec);

	public
	ConfigureEditor( String type )
		{
		super();
		this.establishContents( type );
		}

	public void
	edit( UserPrefs prefs, ConfigureSpec spec )
    {
        edit(prefs, spec, null);
    }

	public void
	edit( UserPrefs prefs, ConfigureSpec spec, ConfigPropertyChangeListener changeListener )
		{
        //we make sure our local variables point to those which are being used in the edit
        this.uprefs = prefs;
        this.uspec = spec;

		String help = spec.getHelp();
		String desc = spec.getDescription();

		if ( this.helpIsShowing )
			{
			this.toggleHelp();
			}

		if ( desc != null && desc.length() > 0 )
			{
			this.descText.setText( desc );
			this.descPan.setVisible( true );
			}
		else
			{
			this.descPan.setVisible( false );
			}

		this.descPan.revalidate();

		if ( help != null && help.length() > 0 )
			{
			this.helpButton.setEnabled( true );
			this.helpText.setText( help );
			this.helpText.revalidate();
			}
		else
			{
			this.helpButton.setEnabled( false );
			this.helpText.setText( "No Help Available." );
			}

		this.helpPanel.revalidate();

        /** introduced jsalerno
         *  Now, before we let the instances do their thing, we force the subclass
         *  to hook up its listeners in order to have UI control with SAVE and
         *  CANCEL buttons. We must ensure a call to
         *  <code>ConfigureEditor.addListeners()</code> has been
         *  made before the subclass calls its own edit method body. That will
         *  guarantee that the changes are reflected in the UI controls
         */
            /**
             * We check for null for backwards compatibility with the 5.2.2 codebase
             * where the editor.edit() calls have no knowledge of a ConfidPropertyChangeListener.
             *
             * We also add listeners only where edits are possible
             *
             * We also add listeners only once
             */
        if(changeListener != null)
        {
            if(Configuration.DEBUG)
                System.out.println("listenersAdded = "+listenersAdded);
            if(!listenersAdded)
            {
                addListeners(changeListener);
                listenersAdded = true;
            }
        }
    }

    protected abstract void addListeners(ConfigPropertyChangeListener listener);

    protected void addNumberDocumentListener(JTextComponent c, final ConfigPropertyChangeListener listener)
    {
        //We delegate the work of handling number formats (where requested) out
        //  to a NumberDocumentListener. That object makes a callback on this
        //  when a config change event has been fired.

        //This is better than a Key Listener, because we can control the user's
        //  input effectively.

        //Make sure the appropriate Document has been assigned to your
        //  JTextComponent before this call is made.
        //  eg. numField.setDocument(new FloatDocument()); as in ConfigFloatEditor

        //we hold references to these particular listeners because we need to
        //turn them on/off
        documentListeners.add(new NumberDocumentListener(this, c, listener));
    }

    /**
     * Many subclasses may need to simply add <code>ItemListener</code>'s to a
     * component which implements that interface
     * @param the item listener itself
     * @param the property change listener which is to be notified of property mods
     */
    protected void addItemListener(ItemSelectable c, final ConfigPropertyChangeListener listener)
    {
        c.addItemListener(new ItemListener()
        {
            public void itemStateChanged(ItemEvent event)
            {
                System.out.println(event.getItem());
                if(event.getStateChange() == ItemEvent.DESELECTED)
                    fireConfigChangeEvent(listener);
            }
        });
    }
/*
	public void
	itemStateChanged( ItemEvent evt )
		{
		int stateChg = evt.getStateChange();

		if ( stateChg == ItemEvent.SELECTED )
			{
			String key = (String) evt.getItem();
			PrefsTuple tup = this.cmdTable.getTuple( key );
			if ( tup != null )
				{
				this.cmdText.setText
					( tup.getValueAt( Config.EXEC_DEF_CMD_IDX ) );
				this.envText.setText
					( tup.getValueAt( Config.EXEC_DEF_ENV_IDX ) );
				}
			else
				{
				// UNDONE report this to the user?
				this.cmdText.setText( "" );
				this.envText.setText( "" );
				}
			}
		else if ( stateChg == ItemEvent.DESELECTED )
			{
			this.saveCurrentCommand( (String) evt.getItem() );
			this.cmdText.setText( "" );
			this.envText.setText( "" );
			}
		}
*/
    protected void addActionListener(AbstractButton button, final ConfigPropertyChangeListener listener)
    {
        button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                fireConfigChangeEvent(listener);
            }
        });
    }

    protected void addKeyListener(Component c, final ConfigPropertyChangeListener listener)
    {
        c.addKeyListener(new KeyAdapter()
        {
            public void keyReleased(KeyEvent event)
            {
                if(!event.isActionKey())
                {
                    fireConfigChangeEvent(listener);
                }
            }
        });
    }

    protected void addTableListener(JTable c, final ConfigPropertyChangeListener listener)
    {
        c.getModel().addTableModelListener(new TableModelListener()
        {
            public void tableChanged(TableModelEvent event)
            {
                fireConfigChangeEvent(listener);
            }
        });
    }
/*
    protected void addComboListener(JComboBox c, final ConfigPropertyChangeListener listener)
    {
        c.addItemListener(new ItemListener()
        {
            public void itemStateChanged(ItemEvent event)
            {
                if(!event.getStateChange())
                {
                    fireConfigChangeEvent(listener);
                }
            }
        });
    }
*/
    /**
     * Inform all registered <code>ConfigPropertyChangeListener</code>'s
     * notification via that interafce's <code>propertyModified</code> method.
     */
    public void fireConfigChangeEvent(ConfigPropertyChangeListener cpcl)
    {
        if(Configuration.DEBUG)
            System.out.println("fireConfigChangeEvent("+cpcl+");");
        if(uspec.editable())
        {
            cpcl.propertyModified(uprefs, uspec, this);
        }
        else
        {
            //debug
            if(Configuration.DEBUG)
                System.out.println(uspec.getName()+" NOT EDITABLE");
        }
    }

	public void
	commit( ConfigureSpec spec, UserPrefs prefs, UserPrefs orig )
		{
		if ( this.isModified( spec, prefs, orig ) )
			{
			this.commitChanges( spec, prefs, orig );
			}
		}

	/**
	 * This will commit the changes from prefs to orig. This method
	 * provides a number of default commits that will cover the majority
	 * of properties, and covers all of the default editors. You will
	 * need to override this method if your property type is not handled
	 * here.
	 */

	public void
	commitChanges( ConfigureSpec spec, UserPrefs prefs, UserPrefs orig )
		{
		String propName = spec.getPropertyName();

		if ( this.isStringArray( spec ) )
			{
			String[] strAry =
				prefs.getStringArray( propName, null );

			orig.removeStringArray( propName );
			if ( strAry != null )
				{
				orig.setStringArray( propName, strAry );
				}
			}
		else if ( this.isTupleTable( spec ) )
			{
			PrefsTupleTable table =
				prefs.getTupleTable( propName, null );

			orig.removeTupleTable( propName );
			if ( table != null )
				{
				orig.setTupleTable( propName, table );
				}
			}
		else
			{
			String value = prefs.getProperty( propName );
			orig.setProperty( propName, value );
			}
		}

	public boolean
	isTupleTable( ConfigureSpec spec )
		{
		return spec.isTupleTable();
		}

	public boolean
	isStringArray( ConfigureSpec spec )
		{
		return spec.isStringArray();
		}

	/**
	 * This will check for changes in prefs relative to orig. This method
	 * provides a number of default checks that will cover the majority
	 * of properties, and covers all of the default editors. You will
	 * need to override this method if your property type is not handled
	 * here.
	 */

	public boolean
	isModified( ConfigureSpec spec, UserPrefs prefs, UserPrefs orig )
		{
		String propName = spec.getPropertyName();

		if ( this.isTupleTable( spec ) )
			{
			PrefsTupleTable nt =
				prefs.getTupleTable( propName, null );

			PrefsTupleTable ot =
				orig.getTupleTable( propName, null );

			if ( nt != null && ot != null )
				{
				if ( ! nt.equals( ot ) )
					return true;
				}
			else if ( nt != null || ot != null )
				{
				return true;
				}
			}
		else if ( this.isStringArray( spec ) )
			{
			String[] na =
				prefs.getStringArray( propName, null );
			String[] oa =
				orig.getStringArray( propName, null );

			if ( na != null && oa != null )
				{
				if ( na.length != oa.length )
					return true;

				for ( int i = 0 ; i < na.length ; ++i )
					if ( ! na[i].equals( oa[i] ) )
						return true;
				}
			else if ( na != null || oa != null )
				{
				return true;
				}
			}
		else
			{
			String ns = prefs.getProperty( propName );
			String os = orig.getProperty( propName );

			if ( ns != null && os != null )
				{
				if ( ! ns.equals( os ) )
					return true;
				}
			else if ( ns != null || os != null )
				{
				return true;
				}
			}

		return false;
		}

	/**
	 * Override for your own tip.
	 */
	protected String
	getHelpButtonToolTipText()
		{
		return "Show Help Text";
		}

	protected JPanel
	establishHelpPanel()
		{
		JLabel lbl;

		JPanel result = new JPanel();

		result.setLayout( new BorderLayout() );
		result.setBorder( new EmptyBorder( 5, 3, 3, 3 ) );

		this.helpText = new JTextArea();
		this.helpText.setEnabled( false );
		this.helpText.setEditable( false );
		this.helpText.setDisabledTextColor( Color.black );
		this.helpText.setLineWrap( true );
		this.helpText.setWrapStyleWord( true );
		this.helpText.setOpaque( false );
		this.helpText.setMargin( new Insets( 2, 4, 2, 4 ) );

		result.add( BorderLayout.CENTER, this.helpText );

		return result;
		}

	private void
	toggleHelp()
		{
		if ( this.helpIsShowing )
			{
			this.editScroller.getViewport().remove( this.helpPanel );
			this.editScroller.getViewport().setView( this.editPanel );
			this.editScroller.revalidate();
			}
		else
			{
			this.editScroller.getViewport().remove( this.editPanel );
			this.editScroller.getViewport().setView( this.helpPanel );
			this.editScroller.revalidate();
			}

		this.repaint( 50 );
		this.helpIsShowing = ! this.helpIsShowing;
		}

	private JPanel
	establishEditPanel( String type )
		{
		int col = 0;
		int row = 0;

		JPanel result = new JPanel();
		result.setLayout( new GridBagLayout() );

		this.editorPanel = this.createEditPanel();

		AWTUtilities.constrain(
			result, this.editorPanel,
			GridBagConstraints.BOTH,
			GridBagConstraints.CENTER,
			0, row++, 1, 1, 1.0, 1.0 );

		this.descText = new JTextArea( "" );
		this.descText.setEnabled( false );
		this.descText.setEditable( false );
		this.descText.setDisabledTextColor( Color.black );
		this.descText.setLineWrap( true );
		this.descText.setWrapStyleWord( true );
		this.descText.setOpaque( false );

		this.descPan = new JPanel();
		this.descPan.setLayout( new BorderLayout() );
		this.descPan.add( "Center", descText );
		this.descPan.setBorder
			( new CompoundBorder
				( new TitledBorder
					( new EtchedBorder( EtchedBorder.RAISED ), "Description" ),
					new EmptyBorder( 10, 15, 15, 15 )
				)
			);

		AWTUtilities.constrain(
			result, this.descPan,
			GridBagConstraints.BOTH,
			GridBagConstraints.SOUTH,
			0, row++, 1, 1, 1.0, 1.0,
			new Insets( this.descOffset, 5, 5, 5 ) );

		JPanel fillerPan = new JPanel();
		AWTUtilities.constrain(
			result, fillerPan,
			GridBagConstraints.BOTH,
			GridBagConstraints.SOUTH,
			0, row++, 1, 1, 1.0, 1.0 );

		return result;
		}

	private void
	establishContents( String type )
		{
		this.setLayout( new BorderLayout() );

		JPanel typePan = new JPanel();
		typePan.setLayout( new GridBagLayout() );

		JLabel lbl = new JLabel( type );
		lbl.setBorder( new EmptyBorder( 3, 3, 5, 3 ) );
		AWTUtilities.constrain(
			typePan, lbl,
			GridBagConstraints.HORIZONTAL,
			GridBagConstraints.WEST,
			0, 0, 1, 1, 1.0, 0.0 );

		try {
			Image iHelp =
				AWTUtilities.getImageResource
					( "/com/ice/jcvsii/images/icons/confighelp.gif" );
			Icon helpIcon = new ImageIcon( iHelp );
			this.helpButton = new JButton( helpIcon )
				{
				public boolean isFocusTraversable() { return false; }
				};
			this.helpButton.setMargin( new Insets( 1,3,1,3 ) );
			}
		catch ( IOException ex )
			{
			this.helpButton = new JButton( "?" );
			}

		this.helpButton.setToolTipText( this.getHelpButtonToolTipText() );

		this.helpButton.addActionListener
			( new ActionListener()
				{
				public void
				actionPerformed( ActionEvent evt )
					{ toggleHelp(); }
				}
			);
		AWTUtilities.constrain(
			typePan, this.helpButton,
			GridBagConstraints.NONE,
			GridBagConstraints.EAST,
			1, 0, 1, 1, 0.0, 0.0 );

		this.helpPanel = this.establishHelpPanel();

		this.editPanel = this.establishEditPanel( type );
		this.editScroller = new JScrollPane( this.editPanel );

		this.add( BorderLayout.CENTER, this.editScroller );
		this.add( BorderLayout.NORTH, typePan );
    }

    protected void setDocumentListenersOff()
    {
        setDocumentListeners(false);
    }

    protected void setDocumentListenersOn()
    {
        setDocumentListeners(true);
    }

    protected void setDocumentListeners(boolean state)
    {
        synchronized(documentListeners)
        {
            for(int i = 0; i < documentListeners.size(); i++)
            {
                ((NumberDocumentListener)documentListeners.elementAt(i)).setListening(state);
            }
        }
    }

}