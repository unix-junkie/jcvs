
package com.ice.config.editor;

import javax.swing.text.Document;
import javax.swing.text.PlainDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.JTextComponent;

import com.ice.config.*;
import com.ice.pref.UserPrefs;


public
class		ConfigLongEditor
extends		ConfigNumberEditor
	{

	public
	ConfigLongEditor()
		{
		super( "Long" );
		}

    protected void setFieldDocumentEditor()
    {
        numField.setDocument(new LongDocument());
	}

	public String
	getTypeTitle()
		{
		return "Long";
		}

	public String
	formatNumber( UserPrefs prefs, ConfigureSpec spec )
		{
		long num =
			prefs.getLong( spec.getPropertyName(), 0 );

		return Long.toString( num );
		}

	public boolean
	isChanged( UserPrefs prefs, ConfigureSpec spec, String numText )
		{
		long cur = Long.parseLong( numText );
		long old = prefs.getLong( spec.getPropertyName(), 0 );
		return ( cur != old );
		}

}