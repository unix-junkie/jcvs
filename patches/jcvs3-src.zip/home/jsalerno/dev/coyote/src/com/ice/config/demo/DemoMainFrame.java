package com.ice.config.demo;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import javax.help.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;

import com.ice.cvsc.CVSProject;
import com.ice.cvsc.CVSCUtilities;
import com.ice.pref.UserPrefs;
import com.ice.util.AWTUtilities;

import com.ice.jcvsii.MainPanel;
import com.ice.jcvsii.ResourceMgr;
import com.ice.jcvsii.HTMLDialog;
import com.ice.jcvsii.ProjectFrame;
import com.ice.jcvsii.ProjectFrameMgr;
import com.ice.jcvsii.ResourceMgr;

import com.ice.config.*;
import com.ice.config.editor.PrefsAwareDialog;

import com.ice.util.URLUtilities;
/**
* @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
*
* @version $Revision: 1.3 $
*/
public class DemoMainFrame extends AbstractMainFrame
{
	private DemoConfigurator			demoConfigurator;

	public DemoMainFrame( DemoConfigurator demoConfigurator, String title, Rectangle bounds )
    {
		super( demoConfigurator, title, bounds );
		this.demoConfigurator = demoConfigurator;
    }

    public void initialize()
    {
/*
demo.displayImage1=/com/ice/config/demo/images/config1.jpg
demo.displayImage2=/com/ice/config/demo/images/config2.jpg
demo.version=1.3
demo.authors=Julian Salerno\t\tjulian@netwxs.com.au
demo.about_image=/com/ice/config/demo/images/about_image.jpg
*/
        if(DEBUG)
            System.out.println("DemoMainFrame.initialize");

        DemoConfiguration demoConfiguration = demoConfigurator.getDemoConfiguration();
        UserPrefs demoPrefs = demoConfiguration.getDemoPrefs();

        String pathToImage = (String)demoPrefs.get("demo.displayImage1");
        String basePath = demoPrefs.getUserHome();
        String fullPath = URLUtilities.createNativePathFromMixedEnvironemnts(new String[]{basePath, pathToImage});
        ImageIcon imageIcon = new ImageIcon(fullPath);
        JLabel lbl = new JLabel( imageIcon );
/*
        if(DEBUG)
        {
            System.out.println("\tpathToImage = "+pathToImage);
            System.out.println("\tbasePath = "+basePath);
            System.out.println("\tfullPath = "+fullPath);
        }
        pathToImage = (String)demoPrefs.get("wordprocessor.gpl_image");
        basePath = demoPrefs.getUserHome();
        fullPath = URLUtilities.createNativePathFromMixedEnvironemnts(new String[]{basePath, pathToImage});
        ImageIcon imageIcon2 = new ImageIcon(fullPath);
        JLabel lbl2 = new JLabel( imageIcon2 );
*/
        JPanel labelPanel = new JPanel(new GridLayout(1,2));
		labelPanel.add( lbl );
//		labelPanel.add( lbl2 );
		this.getContentPane().add( labelPanel );

        boolean resize = false;
        int height = this.getHeight();
        int width = this.getWidth();
        if(labelPanel.getSize().getHeight() > this.getHeight())
        {
            height = (int)labelPanel.getSize().getHeight() + 25;
            resize = true;
        }
        if(labelPanel.getSize().getWidth() > this.getWidth())
        {
            width = (int)labelPanel.getSize().getWidth() + 25;
            resize = true;
        }
        if(resize)
            this.setSize(width, height);

        //now, any other configurations to process in batch fashion ?
        Configuration[] configs = demoConfigurator.getConfigurations();
    }

    protected void buildScreens()
    {
//        this.getContentPane().add(new JTextArea("hello"));
    }

	public void loadPreferences()
    {
        //no need to do anything in this particular app
    }

	public void savePreferences()
    {
        super.savePreferences();
    }

    public void valueChanged(ListSelectionEvent e)
    {
        System.out.println("valueChanged();");
    }

    public void showAboutBox()
    {
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                DemoConfiguration demoConfiguration = demoConfigurator.getDemoConfiguration();
                UserPrefs demoPrefs = demoConfiguration.getDemoPrefs();
                PrefsAwareDialog dlg = new DemoPrefsAwareDialog( getFrame(), demoPrefs );
                dlg.show();
            }
        });
    }

    public void showBugReportScreen()
    {
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                showHTMLDialog( "info.howto.report.bug.title",
								"info.howto.report.bug.html" );
            }
        });
    }

    public void showHomePageScreen()
    {
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                showHTMLDialog( "info.homepage.title",
								"info.homepage.html" );
            }
        });
    }
}