package com.ice.config;

import javax.swing.JPanel;

public interface MainPanelInterface
{
    public MainFrame getMainFrame();
    public void loadPreferences();
    public void savePreferences();
    public JPanel getPanel();
	public void setAllTabsEnabled( boolean enabled );
}