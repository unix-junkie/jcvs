package com.ice.config;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;

import com.ice.pref.*;

import com.ice.jcvsii.ResourceMgr;
import com.ice.jcvsii.ConfigConstants;
import com.ice.app.AppSplash;
import com.ice.config.IncrementalBoundedRangeModel;
import com.ice.config.DefaultConfiguration;
import com.ice.config.AbstractConfigurator;
import com.ice.config.Configuration;
/**
 * This provides a startup thread for each <code>Configurator</code>.
 * We conform to a <code>IncrementalBoundedRangeModel</code> for the startup splash view.
 *
 * This class replaces the <code>JCVS.Initiator</code> inner class.
 *
 * @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
 * @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
 *
 * @version $Revision: 1.4 $
 */
public class Initiator extends Thread
{
    public static final boolean DEBUG = System.getProperty("debugStartup") != null;

    AppSplash splash;
    IncrementalBoundedRangeModel model;
    Configurator configurator;

    public Initiator( AppSplash s, IncrementalBoundedRangeModel m, Configurator configurator)
    {
        super( "Model" );
        this.splash = s;
        this.model = m;
        this.configurator = configurator;
    }

    public void run()
    {
        // This sleep is used to give the repaint thread time
        // to properly refresh the Splash window before we race
        // along and finish initializing before the progress bar
		// can even begin to track out operation.
		//
		try { this.sleep( 100 ); }
			catch ( InterruptedException ex ) { }

        String loadMode = configurator.getPrefsPersistenceMode();
        UserPrefs prefs = null;

        Configuration[] configs = configurator.getConfigurations();
        for(int i = 0; i < configs.length; i++)
        {
            String prefix = configs[i].getPropertyPrefix();
            configs[i].initializePreferences(prefix);
            configs[i].loadConfigEditorSpecifications(loadMode);
            configs[i].setPropertyPrefixes(prefix);
            configs[i].loadConfigurations(loadMode, model);
            if(configs[i] instanceof DefaultConfiguration)
            {
                prefs = ((DefaultConfiguration)configs[i]).getPreferences();
            }
        }
			// NOTE
			// Resources should be loaded after the user preferences, as
			// their initialization may depend on something that the user
			// has configured. On the other hand, the should be loaded
			// before any other configuration initialization, which in
			// turn may be dependent on the resources!
			//

            Rectangle bounds = new Rectangle( 20, 20, 540, 360 );
            if(prefs != null)
            {
			    String plafClassName =
				    prefs.getProperty
					    ( DefaultConfiguration.PLAF_LOOK_AND_FEEL_CLASSNAME, null );

			    if ( plafClassName == null
					|| plafClassName.equals( "DEFAULT" ) )
				{
				    plafClassName =
					UIManager.getSystemLookAndFeelClassName();
				}

			    try { UIManager.setLookAndFeel( plafClassName ); }
                catch ( Exception ex ) { }

                bounds =
	    			prefs.getBounds
		    			( DefaultConfiguration.MAIN_WINDOW_BOUNDS,
			    			bounds );

            }

			MainFrame mainFrame = configurator.getMainFrame(bounds);
            mainFrame.init();

            //tell the model to set itself 'complete'
			this.model.setValue( this.model.getMaximum() );
            //allow UI awt events to complete
			try { this.sleep( 500 ); }
				catch ( InterruptedException ex ) {}
            //get rid of the spalsh screen
			this.splash.dispose();
            //tell the view to load the preferences (this may in fact do nothing)
			mainFrame.loadPreferences();
            //tell the frame to show itself
			mainFrame.getFrame().show();
            //force a repaint in case the prefs load was not completed
			mainFrame.getFrame().repaint( 100 );

            try
            {
                configurator.checkCriticalProperties();
                configurator.addEditMenuItems();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
}