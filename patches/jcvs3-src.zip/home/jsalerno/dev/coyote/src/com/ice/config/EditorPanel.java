package com.ice.config;

import javax.swing.Scrollable;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.Dimension;
import java.awt.Rectangle;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

	/**
	 * This panel is used by the editor panel so that we can tell
	 * the scroll pane we are inside to track out width with the
	 * viewport. This essentially eliminates horizontal scrolling
	 * which is quite ugly in this context.
	 */
	public
	class		EditorPanel
	extends		JPanel
	implements	Scrollable
		{
		public Dimension
		getPreferredScrollableViewportSize()
			{
			return this.getPreferredSize();
			}

		public int
		getScrollableBlockIncrement
				( Rectangle visibleRect, int orientation, int direction )
			{
			if ( orientation == SwingConstants.VERTICAL )
				return visibleRect.height - 10;
			else
				return visibleRect.width - 10;
			}

		public boolean
		getScrollableTracksViewportHeight()
			{
			return false;
			}

		public boolean
		getScrollableTracksViewportWidth()
			{
			return true;
			}

		public int
		getScrollableUnitIncrement
				( Rectangle visibleRect, int orientation, int direction )
			{
			if ( orientation == SwingConstants.VERTICAL )
				{
				int unit = visibleRect.height / 10;
				return (unit == 0 ? 1 : (unit > 20 ? 20 : unit));
				}
			else
				{
				int unit = visibleRect.width / 10;
				return (unit == 0 ? 1 : (unit > 20 ? 20 : unit));
				}
			}
		}
