package com.ice.config;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import javax.swing.BoundedRangeModel;
import java.awt.Frame;
import com.ice.pref.UserPrefs;
import java.io.IOException;
import java.io.File;
import java.io.OutputStream;
/**
 * The public api for the management of configurations.
 *
 * @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
 * @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
 *
 * @version $Revision: 1.9 $
 */
public interface Configuration
{
	/** Set to true to get processing debugging on stderr. **/
	public boolean DEBUG = System.getProperty("debugConfiguration") != null;

    /**
     * @param set the debug flag for this configuration instance.
     */
	public void setDebug( boolean debug );

    /**
     * This method is a convenience method to set the prefix for <code>UserPrefs</code>
     *  defined in this class.
     * Typically, all proerties would use the same prefix.
     * @param the prefix to be used for property file lookups based upon prefixes
     */
    public void setPropertyPrefixes(String prefix);

    /**
     * Load the preference files and increment the model accordingly.
     * @param the incremental range model which tracks our load progress
     */
    public void loadConfigurations(String loadMode, IncrementalBoundedRangeModel model);

    /**
     * Load the properties for use in creating UserPrefs
     * @param file load technique : FILE or STREAM
     * @param the <code>UserPrefs</code> instance
     * @param the url to the properties file
     */
	public void loadPreferences(String mode, UserPrefs thePrefs, String specURL);

    /**
     * Load the properties for use in creating editor config specifications
     * @param file load technique : FILE or STREAM
     */
	public void loadConfigEditorSpecifications(String mode);
    /**
     * Load the properties for the editor config specification
     * @param the file-load-mode (FILE or STREAM)
     * @param the url to the file
     * @param the destination <code>UserPrefs</code>
     */
	public void loadConfigEditorSpecification(String mode, String specURL, UserPrefs theEditSpec);

    /**
     * Edit this configuration in a dialog relative to the specified frame
     */
	public void editConfiguration( MainFrame parent ) throws Exception;

    /**
     * Edit this configuration in a dialog relative to the specified frame
     * @param showing the specified properties
     */
	public void editConfiguration( MainFrame parent, String[] editProps ) throws Exception;

    /**
     * We want to close any in-progress edit on this configuration.
     * This most likely means that we should look to close any windows or dialogs related to the edit
     */
    public void close();

    /**
     * This method is where <code>UserPrefs</code> instances are created.
     * Default prefs are created first, then the instance user prefs, and then the edit specs.
     * @param the prefix to be used for property file lookups based upon prefixes
     */
	public void initializePreferences( String prefix );
    /**
     * This method is where <code>UserPrefs</code> instances are created.
     * Default prefs are created first, then the instance user prefs, and then the edit specs.
     * @param the prefix to be used for property file lookups based upon prefixes
     * @param the user-home for the property files used by this <code>Configuration</code>
     */
	public void initializePreferences( String prefix , String userHome);

    /**
     * @param a <code>UserPrefs</code> instance
     * @param a .properties filename
     * @return a <code>File</code> which repreents the .properties file which
     *  defines the <code>UserPrefs</code> with the given filename
     * @throws IOException when something IO goes wrong
     */
	public File getFile(UserPrefs thePrefs, String propsFilename) throws IOException;

    /**
     * @param a <code>UserPrefs</code> instance
     * @param a .properties filename
     * @return an output stream which pipes to the .properties file which
     * defines the <code>UserPrefs</code> with the given filename
     * @throws IOException when something IO goes wrong
     */
	public OutputStream getFileOutputStream(UserPrefs thePrefs, String propsFilename) throws IOException;

    /**
     * Save the properties used in this class.
     */
	public void savePreferences();

    /**
     * This method is where prefs files are written out to the <b>original</b> .properties file
     * from which they were originally read.
     * <b>nb : this means all properties are written back to the file - so
     * make sure all files are successfully read in</b>.
     * This is different to the original config package functionality where only
     * changes to a config property were written to a global .properties file
     * (eg. "jcvsii.txt").
     * Synchronized because we hold references to many properties.
     * @param the <code>File</code> to be written
     * @param the <code>UserPrefs</code> which contain the data
     * @param the header to write
     */
	public void storePreferencesToProperties(UserPrefs thePrefs, String theFile, String header);

    /**
     * Set the user home for UserPrefs properties used by this Configuration
     * @param the path to user-home
     */
    public void setUserHome(String userHome);

    /**
     * This is method which we can call to determine whether we need to bail out or not
     */
	public void checkCriticalProperties( MainFrame parent ) throws Exception;

    /**
     * Return the number of controllers which this class will/has create(d)
     */
    public int getNumControllers();

    public ActionEventDescriptor getActionEventDescriptor();
    public String getName();
    public String getPropertyPrefix();
}