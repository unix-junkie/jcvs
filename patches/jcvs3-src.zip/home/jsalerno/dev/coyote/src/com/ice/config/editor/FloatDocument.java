package com.ice.config.editor;

import javax.swing.text.BadLocationException;

public class FloatDocument extends NumberDocument
{
    public FloatDocument()
    {
        super();
    }

    protected Number validateNumber(String s) throws NumberFormatException, BadLocationException
    {
        //build a complete representation of what the user expects to see in the
        //  field after pressing this char
        return(Float.valueOf(getNextStringValue(s)));
    }

    protected void checkMin(Number val) throws NumberOutOfRangeException
    {
        int state = ((Float)val).compareTo(getMinimum());
        checkMinSate(state, val);
    }

    protected void checkMax(Number val) throws NumberOutOfRangeException
    {
        int state = ((Float)val).compareTo(getMaximum());
        checkMaxSate(state, val);
    }
}