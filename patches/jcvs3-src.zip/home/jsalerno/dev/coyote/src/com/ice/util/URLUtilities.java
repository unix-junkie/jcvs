/*
** Tim Endres' utilities package.
** Copyright (c) 1997 by Tim Endres
**
** This program is free software.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/

package com.ice.util;

import java.net.URL;
import java.io.File;

public class
URLUtilities
	{
    private static final int FILE = 0;
    private static final int URL = 1;

	static public int
	urlDepth( URL url )
		{
		int		result = 0;
		String	file = url.getFile();

		for ( int i = 1 ; i < file.length() ; ++i )
			{
			if ( file.charAt(i) == '/' )
				result++;
			}

		return result;
		}

    //NetUtils functionality moved to here
    /**
     * Create a File path from the (already ordered) string elements
     * @param the string elements
     * @return the string representation of the url
     */
    public static String createNativePathFromMixedEnvironemnts(String[] elements)
    {
        char concatenator = File.separatorChar;
        char opposing = '/';

        if(concatenator == '/')
            opposing = '\\';
        else if(concatenator == '\\')
            opposing = '/';

        for(int i = 0; i < elements.length; i++)
        {
            if(elements[i] != null)
                elements[i] = elements[i].replace(opposing, concatenator);
        }
        return(createUrlByConcatenation(elements, new String(new char[]{concatenator}), FILE));
    }

    /**
     * Create a Url String from the (already ordered) string elements
     * @param the string elements
     * @return the string representation of the url
     */
    public static String createUrlByConcatenation(String[] elements)
    {
        return(createUrlByConcatenation(elements, "/", URL));
    }

    /**
     * Create a Url String from the (already ordered) string elements
     * @param the string elements
     * @param the element concatenator
     * @param the type (viz. FILE, URL)
     * @return the string representation of the url
     */
    public static String createUrlByConcatenation(String[] elements, String concatenator, int type)
    {
        if((elements == null) || (elements.length == 0))
            return(null);

        int length = elements.length;
        StringBuffer url = new StringBuffer();
        for(int i = 0; i < length; i++)
        {
            String token = elements[i];
            if(token != null)
            {
                boolean replaceLeadingConcatenator = false;
                if(i == 0)
                {
                    if((type == URL) && (token.startsWith(concatenator)))
                        replaceLeadingConcatenator = true;
                }
                else
                {
                    if(token.startsWith(concatenator))
                        replaceLeadingConcatenator = true;
                }

                if(replaceLeadingConcatenator)
                    token = token.substring(1, token.length());

                url.append(token);

                if(i < (length-1))
                {
                    //except for the last entry - which could be the SERVLET name (we don't want a trailing '/')
                    if(!token.endsWith(concatenator))
                    {
                        url.append(concatenator);
                    }
                }
            }
        }
        return(url.toString());
    }
	}


