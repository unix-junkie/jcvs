package com.ice.config.editor;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Enumeration;

import com.ice.config.ConfigPropertyChangeListener;
/**
* This class manages a <code>ButtonGroup</code> and listens for selections.
* There is a reference to a <code>TogglePropertyChangeListener</code>, on whom
*   callbacks are made in response to a change event.
* And there is a <code>ConfigPropertyChangeListener</code> who is passed back
*   as argument so that the <code>TogglePropertyChangeListener</code> can notify
*   the appropriate config-property-change-listener
*  <code>ConfigurationController</code>'s.
* This class replaces the <code>ConfigDialog</code>.
*
* @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
*
* @version $Revision: 1.3 $
*/
public class ToggleButtonChangeListener
{
    private ButtonGroup group;
    private TogglePropertyChangeListener tpcl;
    private ConfigPropertyChangeListener changeListener;

    public ToggleButtonChangeListener(
        ButtonGroup group,
        TogglePropertyChangeListener tpcl,
        ConfigPropertyChangeListener changeListener)
    {
        super();
        this.group = group;
        this.tpcl = tpcl;
        this.changeListener = changeListener;

        addToggleActionListener(group, tpcl, changeListener);
    }

    private AbstractButton toggledValue;
    private boolean selectionChanged(AbstractButton newB)
    {
        boolean changed = (toggledValue != newB);
        setToggledValue(newB);
        return(changed);
    }
    public AbstractButton getToggledValue(){return(toggledValue);}
    public void setToggledValue(AbstractButton newV){this.toggledValue = newV;}

    protected void addToggleActionListener(
        ButtonGroup group,
        final TogglePropertyChangeListener tpcl,
        final ConfigPropertyChangeListener changeListener)
    {
        Enumeration buttonElements = group.getElements();
        while(buttonElements.hasMoreElements())
        {
            final AbstractButton bttn = (AbstractButton)buttonElements.nextElement();
            bttn.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent event)
                {
                    boolean changed = selectionChanged(bttn);
                    System.out.println("changed = "+changed);
                    if(changed)
                    {
                        tpcl.propertyChanged(changeListener);
                    }
                }
            });
        }
    }
}