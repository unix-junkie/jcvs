package com.ice.config.editor;

import javax.swing.text.BadLocationException;

public class DoubleDocument extends NumberDocument
{
    public DoubleDocument()
    {
        super();
    }

    protected Number validateNumber(String s) throws NumberFormatException, BadLocationException
    {
        //build a complete representation of what the user expects to see in the
        //  field after pressing this char
        return(Double.valueOf(getNextStringValue(s)));
    }

    protected void checkMin(Number val) throws NumberOutOfRangeException
    {
        int state = ((Double)val).compareTo(getMinimum());
        checkMinSate(state, val);
    }

    protected void checkMax(Number val) throws NumberOutOfRangeException
    {
        int state = ((Double)val).compareTo(getMaximum());
        checkMaxSate(state, val);
    }
}