package com.ice.config.editor;

import java.awt.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.border.*;

import com.ice.config.*;
import com.ice.pref.UserPrefs;


public
class		ConfigChoiceEditor
extends		ConfigureToggleEditor
	{
	protected JPanel			radioPanel;
	protected ButtonGroup		group;
	protected JRadioButton[]	choiceButtons;


	public
	ConfigChoiceEditor()
		{
		super( "Choice" );
		}

	public void
	edit( UserPrefs prefs, ConfigureSpec spec, ConfigPropertyChangeListener changeListener )
		{
        //here, we do the super stuff *LAST* because the radio buttons and groupings
        //need to happen first. This is because the choice option information resides
        //with the <code>ConfigureSpec</code> which is a paremeter to this method.
        setUIValue(prefs, spec);

        //okay, now call the super which will ultimately make the call to <code>addListeners();</code>
		super.edit( prefs, spec, changeListener);
		}

    protected void setUIValue(UserPrefs prefs, ConfigureSpec spec)
    {
        super.setUIValue(prefs, spec);

		this.radioPanel.removeAll();
		String propName = spec.getPropertyName();
		String choice = prefs.getProperty( propName, null );

		this.group = new ButtonGroup();

		String[] choices = spec.getChoices();
		this.choiceButtons = new JRadioButton[ choices.length ];

		for ( int i = 0 ; i < choices.length ; ++i )
			{
			JRadioButton radio = new JRadioButton( choices[i] );
			this.choiceButtons[i] = radio;
			this.group.add( radio );
			this.radioPanel.add( radio );
			radio.setSelected( false );
			if ( choice != null )
				{
				if ( choice.equals( choices[i] ) )
					radio.setSelected( true );
				}
			else if ( i == 0 )
				{
				radio.setSelected( true );
				}
			}

		this.radioPanel.validate();
		this.radioPanel.repaint( 250 );
    }

	public void
	saveChanges( UserPrefs prefs, ConfigureSpec spec )
		{
        setPrefsValue(prefs, spec);
		}

    protected void setPrefsValue(UserPrefs prefs, ConfigureSpec spec)
    {
		String propName = spec.getPropertyName();
		String oldChoice = prefs.getProperty( propName, null );

		for ( int i = 0 ; i < this.choiceButtons.length ; ++i )
        {
			if ( this.choiceButtons[i].isSelected() )
            {
				String newChoice = this.choiceButtons[i].getText();
				prefs.setProperty( propName, newChoice );
				break;
            }
        }
    }

	public void
	requestInitialFocus()
		{
		}

	protected JPanel
	createEditPanel()
		{
		JPanel result = new JPanel();

		result.setLayout( new BoxLayout( result, BoxLayout.Y_AXIS ) );
		result.setBorder( new EmptyBorder( 5, 5, 5, 5 ) );

		return this.radioPanel = result;
		}

    /**
     * Because the setUIValue() method in this class actually <strong>creates</strong>
     * the choice components, we override the undoChanges() call so that we call our own
     * private setUIValue2() method instead. We always follow thru with a setPrefsValue()
     * call
     */
	public void
	undoChanges( UserPrefs prefs, ConfigureSpec spec )
    {
        setUIValue2(prefs, spec);
        setPrefsValue(prefs, spec);
/*
		String propName = spec.getPropertyName();

		String oldVal = prefs.getProperty( propName, "" );
        //just reinstate the original value; if none is selected, then select
        //  the last on the way out
		for ( int i = 0 ; i < choiceButtons.length ; ++i )
        {
            JRadioButton radio = choiceButtons[i];
            String rbName = radio.getText();
			if( oldVal.equals(rbName) )
            {
    			radio.setSelected( true );
                break;
            }
			else if ( i == (choiceButtons.length-1) )
            {
				radio.setSelected( true );
            }
        }
*/
    }

    private void setUIValue2(UserPrefs prefs, ConfigureSpec spec)
    {
		String propName = spec.getPropertyName();

		String oldVal = prefs.getProperty( propName, "" );
        //just reinstate the original value; if none is selected, then select
        //  the last on the way out
		for ( int i = 0 ; i < choiceButtons.length ; ++i )
        {
            JRadioButton radio = choiceButtons[i];
            String rbName = radio.getText();
			if( oldVal.equals(rbName) )
            {
    			radio.setSelected( true );
                break;
            }
			else if ( i == (choiceButtons.length-1) )
            {
				radio.setSelected( true );
            }
        }
    }

    protected void addListeners(ConfigPropertyChangeListener changeListener)
    {
        addToggleActionListener(group, changeListener);
    }

	protected void disableComponent()
    {
		for ( int i = 0 ; i < choiceButtons.length ; ++i )
        {
            choiceButtons[i].setEnabled(false);
        }
    }

	protected void enableComponent()
    {
        if(choiceButtons == null)
            return;

		for ( int i = 0 ; i < choiceButtons.length ; ++i )
        {
            choiceButtons[i].setEnabled(true);
        }
    }
}