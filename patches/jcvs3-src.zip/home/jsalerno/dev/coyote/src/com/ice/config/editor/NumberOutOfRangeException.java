package com.ice.config.editor;

public class NumberOutOfRangeException extends Exception
{

    public NumberOutOfRangeException(String msg)
    {
        super(msg);
    }
}