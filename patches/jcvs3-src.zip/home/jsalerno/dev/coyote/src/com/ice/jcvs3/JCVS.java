/*
** Java CVS client application package.
** Copyright (c) 1997 by Timothy Gerard Endres
**
** This program is free software.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/

package com.ice.jcvs3;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

import javax.swing.*;

import com.ice.config.*;
import com.ice.pref.*;
import com.ice.cvsc.CVSLog;
import com.ice.cvsc.CVSTimestampFormat;
import com.ice.util.ResourceUtilities;

import com.ice.jcvsii.*;

/**
 * The jCVS application class.
 *
 * @version $Revision: 1.5 $
 * @author Timothy Gerard Endres, <a href="mailto:time@ice.com">time@ice.com</a>.
 */

public
class		JCVS
extends     AbstractConfigurator
	{
	static public final String		RCS_ID = "$Id: JCVS.java,v 1.5 2002/03/11 22:54:27 jsalerno Exp $";
	static public final String		RCS_REV = "$Revision: 1.5 $";

	static public final String		VERSION_STR = "5.2.2";

    public static String INSTALL_DIR = System.getProperty("installDir");
    public static String REL_CLASSPATH = System.getProperty("relClassDir");

	static private JCVS		instance;

    //the Configuration object which defines the application functions
    private DefaultConfiguration appConfiguration;


    /**
     * Start this sucker up.
     * Call <code>initialize(argv)</code> on the configurator <code>instance</code>
     */
	static public void main( String[] argv )
    {
		Configurator jcvs = new JCVS();
		JCVS.instance = (JCVS)jcvs;
        try
        {
		    jcvs.initialize( argv, "jcvsii", "com.ice.jcvsii.rsrcui");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            System.exit(1);
        }
    }

	static public String
	getVersionString()
		{
		return VERSION_STR;
		}

	public void performShutDown()
    {
        super.performShutDown();
    }

    protected void shutDownActions()
    {
        super.shutDownActions();
        performJCVSShutDown();
    }

	public void
	performJCVSShutDown()
		{
		ProjectFrameMgr.closeAllProjects();
//		Config.getInstance().savePreferences();

//		System.exit( 0 );
		}
/*
	public void
	performShutDown()
		{
		ProjectFrameMgr.closeAllProjects();

		this.mainFrame.savePreferences();

		Config.getInstance().savePreferences();

		System.exit( 0 );
		}
*/
/*
	public void
	actionPerformed( ActionEvent event )
		{
		String command = event.getActionCommand();

		if ( command.equals( "QUIT" ) )
			{
			this.performShutDown();
			}
		}
*/
	protected void
	processArguments( String[] argv )
    throws Exception
		{
        super.processArguments(argv);
//// ORIGINAL BELOW HERE //////
		UserPrefs prefs = Config.getPreferences();

		for ( int i = 0 ; i < argv.length ; ++i )
			{
			if ( argv[i].equals( "-osname" ) )
				{
				prefs.setOSSuffix( argv[++i] );
				}
			else if ( argv[i].equals( "-user" ) )
				{
				prefs.setUserSuffix( argv[++i] );
				}
			else if ( argv[i].equals( "-home" ) )
				{
				prefs.setUserHome( argv[++i] );
				}
			else
				{
				System.err.println
					( "   argv[" +i+ "] '" +argv[i]+ "' ignored." );
				}
			}
		}
/*
	private
	class		Initiator
	extends		Thread
		{
		JCVSSplash splash;
		BoundedRangeModel model;

		public
		Initiator( JCVSSplash s, BoundedRangeModel m )
			{
			super( "Model" );
			this.splash = s;
			this.model = m;
			}

		public void
		run()
			{
			// This sleep is used to give the repaint thread time
			// to properly refresh the Splash window before we race
			// along and finish initializing before the progress bar
			// can even begin to track out operation.
			//
			try { this.sleep( 100 ); }
				catch ( InterruptedException ex ) { }

			int proval = 0;
			int procnt = 13;
			int proincr = ( this.model.getMaximum() / procnt );

			this.model.setValue( proval += proincr );

			Config cfg = Config.getInstance();

			cfg.initializePreferences( "jcvsii." );

			UserPrefs prefs = Config.getPreferences();

			this.model.setValue( proval += proincr );

			cfg.loadDefaultPreferences();

			this.model.setValue( proval += proincr );

			cfg.loadUserPreferences();

			this.model.setValue( proval += proincr );

			//
			// NOTE
			// Resources should be loaded after the user preferences, as
			// their initialization may depend on something that the user
			// has configured. On the other hand, the should be loaded
			// before any other configuration initialization, which in
			// turn may be dependent on the resources!
			//

			ResourceMgr.initializeResourceManager( "jcvsii" );

			this.model.setValue( proval += proincr );

			cfg.loadConfigEditorSpecification();

			this.model.setValue( proval += proincr );

			if ( prefs.getBoolean( Config.GLOBAL_LOAD_SERVERS, false ) )
				{
				cfg.loadDefaultServerDefinitions();
				}

			this.model.setValue( proval += proincr );

			cfg.loadMimeTypes();

			this.model.setValue( proval += proincr );

			cfg.loadMailCap();

			this.model.setValue( proval += proincr );

			cfg.loadUserServerDefinitions();

			this.model.setValue( proval += proincr );

			cfg.initializeGlobalProperties();

			this.model.setValue( proval += proincr );

			// NOTE Make sure that there is no CVSLog-ing before this point!
			CVSLog.setLogFilename
				( prefs.getProperty
					( Config.GLOBAL_CVS_LOG_FILE,
						CVSLog.DEFAULT_FILENAME ) );

			this.model.setValue( proval += proincr );

			CVSLog.checkLogOpen();

			CVSLog.logMsgStderr( "jCVS II Version " + VERSION_STR );
			CVSLog.logMsgStderr
				( "Licensed under the GNU General Public License." );
			CVSLog.logMsgStderr
				( "License is available at <http://www.gjt.org/doc/gpl/>" );

			CVSLog.logMsgStderr
				( "Property 'os.name' = '" + prefs.getOSSuffix() + "'" );
			CVSLog.logMsgStderr
				( "Property 'user.name' = '" + prefs.getUserSuffix() + "'" );
			CVSLog.logMsgStderr
				( "Property 'user.home' = '" + prefs.getUserHome() + "'" );
			CVSLog.logMsgStderr
				( "Property 'user.dir' = '" + prefs.getCurrentDirectory() + "'" );

			// Establish the CVSTimestamp Formatting Timezone
			String tzPropStr =
				prefs.getProperty( Config.GLOBAL_CVS_TIMEZONE, null );

			if ( tzPropStr != null )
				{
				CVSTimestampFormat.setTimeZoneID( tzPropStr );
				CVSLog.logMsgStderr
					( "CVS Timestamp timezone set to '" + tzPropStr + "'" );
				}

			this.model.setValue( proval += proincr );

			String plafClassName =
				prefs.getProperty
					( Config.PLAF_LOOK_AND_FEEL_CLASSNAME, null );

			if ( plafClassName == null
					|| plafClassName.equals( "DEFAULT" ) )
				{
				plafClassName =
					UIManager.getSystemLookAndFeelClassName();
				}

			try { UIManager.setLookAndFeel( plafClassName ); }
				catch ( Exception ex ) { }

			Rectangle bounds =
				prefs.getBounds
					( Config.MAIN_WINDOW_BOUNDS,
						new Rectangle( 20, 20, 540, 360 ) );

			mainFrame = new MainFrame( JCVS.this, "jCVS II", bounds );

			this.model.setValue( this.model.getMaximum() );

			try { this.sleep( 500 ); }
				catch ( InterruptedException ex ) {}

			this.splash.dispose();

			mainFrame.loadPreferences();

			mainFrame.show();

			mainFrame.repaint( 100 );

			cfg.checkCriticalProperties( mainFrame );
			}
		}
*/
    protected void createMainFrame(Rectangle bounds)
    {
		mainFrame = new JCVSMainFrame( this, getConfigToolDisplayName(), bounds );
    }

    protected Configuration[] createConfigurations()
    {
        appConfiguration = DefaultConfiguration.getInstance();
        //build an array for faceless access to the Configurations
        return(new Configuration[]{appConfiguration});
    }

    protected String establishConfigBasePath()
    {
        /////temporary
        return(".");
//        return(NetUtils.createNativePathFromMixedEnvironemnts(new String[]{INSTALL_DIR, REL_CLASSPATH}));
    }

    protected String getSplashScreenName()
    {
        return("Java CVS Client");
    }

    protected String getPathToSplashImageResource()
    {
        return("/com/ice/jcvsii/images/splash.gif");
    }

    protected String getConfigToolDisplayName()
    {
        return("jCVS 3");
    }

    public String getPrefsPersistenceMode()
    {
        return(UserPrefsConstants.FILE_LOADER);
    }

    //// Abstract Configurator methods which we must implement ////
    protected void processApplicationArgs()
    {
        if(DEBUG)
            System.out.println("JCVS.processApplicationArgs");
        super.processApplicationArgs();
    }

    protected void processVMArgs()
        throws Exception
    {
        if(DEBUG)
            System.out.println("JCVS.processVMArgs");
        INSTALL_DIR = System.getProperty("installDir");
        if(INSTALL_DIR == null)
            throw new Exception("-DinstallDir must be specified in the startup VM args");
        REL_CLASSPATH = System.getProperty("relClassDir");
        if(REL_CLASSPATH == null)
            throw new Exception("-DrelClassDir must be specified in the startup VM args");
    }
}

