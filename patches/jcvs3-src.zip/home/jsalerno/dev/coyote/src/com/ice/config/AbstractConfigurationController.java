package com.ice.config;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.util.Vector;
import java.util.Enumeration;

import com.ice.pref.UserPrefs;
/**
 * This abstract class provides the common attributes and behaviour for
 *  <code>ConfigurationController</code>'s.
 * Original and working copy <code>UserPrefs</code> are managed here,
 *  along with a spec to define the view.
 * The tree-model is stored so that we can add selection paths into it.
 * Previously a ref to the tree itself was stored.
 *
 * @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
 * @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
 *
 * @version $Revision: 1.12 $
 */
public abstract class AbstractConfigurationController implements ConfigurationController
{
    protected UserPrefs origPrefs;
    protected UserPrefs workingCopy;
    protected UserPrefs specs;
    protected ConfigureEditorFactory factory;
    protected Vector specVector;
    protected Vector paths = new Vector();
    protected ConfigureTreeModel treeModel;

    public AbstractConfigurationController(UserPrefs prefs, UserPrefs specs)
        throws Exception
    {
        if(prefs == null)
            throw new Exception("Cannot load null 'prefs'");
        if(specs == null)
            throw new Exception("Cannot load 'prefs' with null 'specs'");
        this.origPrefs = prefs;
        this.specs = specs;
        this.workingCopy = prefs.createWorkingCopy("Configuration Working Copy");

        createFactory();
        addEditors();

        try
        {
            this.specVector = ConfigureUtil.readConfigSpecification( specs );
        }
		catch ( InvalidSpecificationException ex )
        {
			// REVIEW
			// UNDONE
			// Should we not throw this?
            ex.printStackTrace();
			this.specVector = new Vector();
        }
    }

    /**
     * All concrete instances need to create their factory(ies) here
     */
    protected abstract void createFactory();

    /**
     * Add any editors we need to add
     */
    protected void addEditors() throws Exception
    {
        if(factory == null)
            throw new Exception("ConfigureEditorFactory cannot be null. Set it in your implementation of ConfigurationController.createFactory()");
    }

    /**
     * Tell the controller to insert its edit spec paths into the config tree
     */
	public void insertSpecIntoConfigTree()
    {
        if(DEBUG)
            System.out.println(getPrefsName() + " AbstractConfigurationController.insertSpecIntoConfigTree()");
		for ( Enumeration enum = this.specVector.elements(); enum.hasMoreElements() ; )
        {
			ConfigureSpec spec = (ConfigureSpec) enum.nextElement();
			    String path = spec.getPropertyPath();
            if(DEBUG)
                System.out.println("path = "+path);

            this.treeModel.addPath( path, spec );
            this.paths.addElement(path);
        }
    }

    public UserPrefs getWorkingCopy(){return(workingCopy);}
    public UserPrefs getUserPrefs(){return(origPrefs);}
    public UserPrefs getSpecs(){return(specs);}

    public ConfigureEditorFactory getEditorFactory(){return(factory);}
    public void setEditorFactory(ConfigureEditorFactory factory){this.factory = factory;}

    public void setConfigurationPanel(ConfigurationPanel configPanel)
    {
        workingCopy.setConfigurationPanel(configPanel);
    }

    public ConfigurationPanel getConfigurationPanel()
    {
        return(workingCopy.getConfigurationPanel());
    }

    public Vector getSpecsAsVector()
    {
        return(specVector);
    }

    public void setConfigurationTreeModel(ConfigureTreeModel treeModel)
    {this.treeModel = treeModel;}

    public ConfigureTreeModel getConfigurationTreeModel()
    {return(treeModel);}

	public void editProperty( String prop )
    {
		getConfigurationPanel().editProperty( prop );
		}

	public void
	editProperties( String[] props )
		{
		getConfigurationPanel().editProperties( props );
		}

    public void saveCurrentEdit()
    {
        getConfigurationPanel().saveCurrentEdit();
    }

    public boolean containsPath(String path)
    {
        boolean contained = paths.contains(path);
        return(contained);
    }

    public void commit()
    {
        getConfigurationPanel().commit();
    }

    public void undoUncommitted()
    {
        getConfigurationPanel().undoUncommitted();
    }

    public String getPrefsName()
    {
        return(origPrefs.getName());
    }

    /**
     * Has there been a change in any of the properties held by the UserPrefs ?
     * @return change status
     */
     public boolean changed()
     {
        if(DEBUG)
            workingCopy.list(System.out);
        boolean modified = workingCopy.isModified();
        if(DEBUG)
        {
            System.out.println(this.getPrefsName() +" modified : " + modified );
            System.out.println("workingCopy="+workingCopy);
        }
        return(modified);
     }
}