package com.ice.config.editor;
/*
** This program is free software.
**
** Copyright (c) 2001 by Julian Walter Salerno
** @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
** Copyright (c) 1999 by Timothy Gerard Endres
** @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
**
** You may redistribute it and/or modify it under the terms of the GNU
** General Public License as published by the Free Software Foundation.
** Version 2 of the license should be included with this distribution in
** the file LICENSE, as well as License.html. If the license is not
** included	with this distribution, you may find a copy at the FSF web
** site at 'www.gnu.org' or 'www.fsf.org', or you may write to the
** Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139 USA.
**
** THIS SOFTWARE IS PROVIDED AS-IS WITHOUT WARRANTY OF ANY KIND,
** NOT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY. THE AUTHOR
** OF THIS SOFTWARE, ASSUMES _NO_ RESPONSIBILITY FOR ANY
** CONSEQUENCE RESULTING FROM THE USE, MODIFICATION, OR
** REDISTRIBUTION OF THIS SOFTWARE.
**
*/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

import java.util.Enumeration;

import com.ice.config.*;
import com.ice.pref.UserPrefs;
import com.ice.util.AWTUtilities;
/**
 * An editor for boolean types.
 * Note that this class (and all other com.ice.config.editor classes) implements
 *  <code>TogglePropertyChangeListener</code>
 *
 * @author Julian Salerno, <a href="mailto:julian@practica.com.au">julian@practica.com.au</a>.
 * @author Tim Endres, <a href="mailto:timen@ice.com">timen@ice.com</a>.
 *
 * @version $Revision: 1.9 $
 */
public
class		ConfigBooleanEditor
extends		ConfigureToggleEditor
	{
	protected JRadioButton	tButton;
	protected JRadioButton	fButton;
	protected ButtonGroup	group;

	public
	ConfigBooleanEditor()
		{
		super( "Boolean" );
		}

	public void
	edit( UserPrefs prefs, ConfigureSpec spec, ConfigPropertyChangeListener changeListener )
		{
		super.edit( prefs, spec, changeListener );

        setUIValue(prefs, spec);

        //but, we also need to notify the toggle button change listener upon
        //the initial edit call
		boolean val = prefs.getBoolean( spec.getPropertyName(), false );
		if ( val )
        {
            notifyToggleButtonChangeListener(tButton);
        }
		else
        {
            notifyToggleButtonChangeListener(fButton);
        }
    }

    private void notifyToggleButtonChangeListener(JRadioButton button)
    {
        if(tbcl != null)
            tbcl.setToggledValue(button);
	}

    public void
	saveChanges( UserPrefs prefs, ConfigureSpec spec )
		{
/*
		String propName = spec.getPropertyName();

		boolean newVal = this.tButton.isSelected();
		boolean oldVal = prefs.getBoolean( propName, false );

		if ( newVal != oldVal )
			{
			prefs.setBoolean( propName, newVal );
			}
*/
            setPrefsValue(prefs, spec);
		}

    protected void setPrefsValue(UserPrefs prefs, ConfigureSpec spec)
    {
		String propName = spec.getPropertyName();

		boolean newVal = this.tButton.isSelected();
		boolean oldVal = prefs.getBoolean( propName, false );

		if ( newVal != oldVal )
        {
			prefs.setBoolean( propName, newVal );
        }
    }

    protected void setUIValue(UserPrefs prefs, ConfigureSpec spec)
    {
        super.setUIValue(prefs, spec);

		String propName = spec.getPropertyName();
		boolean oldVal = prefs.getBoolean( propName, false );

        //if the original value was "true", then select the True button
		if ( oldVal )
        {
			this.tButton.setSelected( true );
        }
		else
        {
			this.fButton.setSelected( true );
        }
    }
/*
	public void
	undoChanges( UserPrefs prefs, ConfigureSpec spec )
    {
        setPrefsValue(prefs, spec);
        setUIValue(prefs, spec);
    }
*/
	public void
	requestInitialFocus()
		{
		this.tButton.requestFocus();
		}

	protected JPanel
	createEditPanel()
		{
		JPanel result = new JPanel();
		result.setLayout( new GridBagLayout() );
		result.setBorder( new EmptyBorder( 5, 25, 5, 5 ) );

		int col = 0;
		int row = 0;

		this.tButton = new JRadioButton( "True" );
		AWTUtilities.constrain(
			result, this.tButton,
			GridBagConstraints.HORIZONTAL,
			GridBagConstraints.WEST,
			0, row++, 1, 1,  1.0, 0.0 );

		this.fButton = new JRadioButton( "False" );
		AWTUtilities.constrain(
			result, this.fButton,
			GridBagConstraints.HORIZONTAL,
			GridBagConstraints.WEST,
			0, row++, 1, 1,  1.0, 0.0 );

		this.group = new ButtonGroup();
		this.group.add( this.tButton );
		this.group.add( this.fButton );

		return result;
		}

    protected void addListeners(ConfigPropertyChangeListener changeListener)
    {
        addToggleActionListener(group, changeListener);
	}

	protected void disableComponent()
    {
        tButton.setEnabled(false);
        fButton.setEnabled(false);
    }

	protected void enableComponent()
    {
        tButton.setEnabled(true);
        fButton.setEnabled(true);
    }
}