package com.ice.config.demo;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;

import com.ice.pref.*;
import com.ice.jcvsii.ResourceMgr;
import com.ice.app.AppSplash;
import com.ice.config.*;

import com.ice.util.URLUtilities;

public abstract class DemoConfigurator extends AbstractConfigurator
{
	static public final String		RCS_ID = "$Id: DemoConfigurator.java,v 1.3 2002/03/20 04:46:59 jsalerno Exp $";
	static public final String		RCS_REV = "$Revision: 1.3 $";
	static public final String		VERSION_STR = "5.2.2";

    //the instance which this application deals with
	static protected DemoConfigurator		instance;

    //the -DinstallDir VM parameter to specify the base installation directory for our product
    public static String INSTALL_DIR = System.getProperty("installDir");
    //the -DrelClassDir VM parameter to specify the relative path of our
    //  class files relative to the base installation directory for our product
    public static String REL_CLASSPATH = System.getProperty("relClassDir");

    //the Configuration object which defines the application functions
    protected DemoConfiguration demoConfiguration;

	static public String getVersionString()
    {
		return VERSION_STR;
    }

    protected void createMainFrame(Rectangle bounds)
    {
		mainFrame = new DemoMainFrame( this, getConfigToolDisplayName(), bounds );
    }

    /**
     * As it says :-).
     * Tell the main frame to save it preferences first.
     * Then, exit.
     */
	public void performShutDown()
    {
        super.performShutDown();
    }

    protected void shutDownActions()
    {
        super.shutDownActions();
    }

	protected void processArguments( String[] argv )
        throws Exception
    {
        if(DEBUG)
            System.out.println("DemoConfigurator.processArguments");
        super.processArguments(argv);
    }

    public DemoConfiguration getDemoConfiguration(){return(demoConfiguration);}

    //// Abstract Configurator methods which we must implement ////
    protected void processApplicationArgs()
    {
        if(DEBUG)
            System.out.println("DemoConfigurator.processApplicationArgs");
        super.processApplicationArgs();
    }

    protected void processVMArgs()
        throws Exception
    {
        if(DEBUG)
            System.out.println("DemoConfigurator.processVMArgs");
        INSTALL_DIR = System.getProperty("installDir");
        if(INSTALL_DIR == null)
            throw new Exception("-DinstallDir must be specified in the startup VM args");
        REL_CLASSPATH = System.getProperty("relClassDir");
        if(REL_CLASSPATH == null)
            throw new Exception("-DrelClassDir must be specified in the startup VM args");
    }

    protected String establishConfigBasePath()
    {
        return(URLUtilities.createNativePathFromMixedEnvironemnts(new String[]{INSTALL_DIR, REL_CLASSPATH}));
    }

    protected String getPathToSplashImageResource()
    {
        return("/com/ice/config/demo/images/pse-logo.jpg");
    }

    public String getPrefsPersistenceMode()
    {
        return(UserPrefsConstants.FILE_LOADER);
    }
}