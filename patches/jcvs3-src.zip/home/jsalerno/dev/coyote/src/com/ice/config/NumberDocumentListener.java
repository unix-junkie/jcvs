package com.ice.config;

import javax.swing.text.JTextComponent;
import javax.swing.text.Document;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;

import com.ice.config.ConfigureEditor;
import com.ice.config.ConfigPropertyChangeListener;

public class NumberDocumentListener
{
    private boolean                 listening = false;
    //a ref to the editor on whose behalf we are doc-listening
    private ConfigureEditor         editor;

    public NumberDocumentListener(
        ConfigureEditor editor,
        JTextComponent c,
        ConfigPropertyChangeListener listener)
    {
        this.editor = editor;

        addNumberDocumentListener(c, listener);
    }
    protected void addNumberDocumentListener(JTextComponent c, final ConfigPropertyChangeListener listener)
    {
        Document document = c.getDocument();
        document.addDocumentListener(new DocumentListener()
        {
            public void insertUpdate(DocumentEvent event)
            {
                fireDocumentChangedEvent(listener);
            }
            public void removeUpdate(DocumentEvent event)
            {
                fireDocumentChangedEvent(listener);
            }
            public void changedUpdate(DocumentEvent event)
            {
                fireDocumentChangedEvent(listener);
            }
        });
    }

    public void setListening(boolean listen)
    {
        this.listening = listen;
    }

    public boolean listening(){return(listening);}

    private void fireDocumentChangedEvent(ConfigPropertyChangeListener listener)
    {
        if(listening())
            editor.fireConfigChangeEvent(listener);
    }
}