INSTALLATION:
Unpack the jcvs3.zip archive to a destination directory, eg. MY_JCVS3_INSTALL_DIR = /home/jsalerno/tmp/jcvs3-install2

The contents include:

1. a jar containing the ice and jcvs binaries (${MY_JCVS3_INSTALL_DIR}/lib/jcvs3.jar)

2. Then , (in this particular example, inside a subdirectory - but it could be anywhere in the file system) '${MY_JCVS3_INSTALL_DIR}/${RELATIVE_WORKAREA_DIRECTORY}', the property files which your applications will use at runtime.
Notice that these files exist in a 'non-java-package' directory (deliberately) to illustrate that resources and properties can be loaded from your specified location (providing you model your executable script on the demo examples).
This could be really useful when you want only one instance of the codebase installed, but would like to have multiple applications take advantage of the Configurator. 
Or, alternatively, when you write your own Configurator classes (which you must place on the classpath - you would simply add the packages to the ${RELATIVE_WORKAREA_DIRECTORY}. The classes for the demo packages are actually contained in the lib/jcvs3.jar for distribution convenience.

These resources in the ${RELATIVE_WORKAREA_DIRECTORY} directory for the demo configurators are (these are the properties you wish to edit):
	a.  com.ice.config.demo.demo1.properties
	a2. com.ice.config.demo.demo1_defaults.properties
	b.  com.ice.config.demo.demo2.properties
	b2. com.ice.config.demo.demo2_defaults.properties
	c.  com.ice.config.demo.demo2A.properties
	c2. com.ice.config.demo.demo2A_defaults.properties
And some edit-spec resources (these define the editors to use for the properties above):
	a. com.ice.config.demo.demo1ConfigSpec.properties
	b. com.ice.config.demo.demo2ConfigSpec.properties
	c. com.ice.config.demo.demo2AConfigSpec.properties
And some definitions required at runtime (menu lookups etc):
	a. com.ice.config.demo.rsrcui.properties
	b. com.ice.config.demo.rsrcui_en_AU.properties
	You may need to create your own locale-specific property file(s) - simply place them here on the classpath, eg. rsrcui_en_FR.properties
And finally, some images: 
	a. com.ice.config.demo.images.config1.gif
	b. com.ice.config.demo.images.config2.gif
	c. com.ice.config.demo.images.pse-logo.jpg

RUNNING THE APPLICATION:

Here is the template demo_runner.sh script which you must modify.
All of the run_xxx.sh scripts invoke this by calling exec and backgrounding.
Your applications might do the same.

(omit XML tags - here for illustrative purposes only):

<demo_runner_template>
#!/bin/sh
ulimit -s 2048
export JAVA_HOME=/usr/local/jdk1.3.1_01
export MY_JCVS3_INSTALL_DIR=/home/jsalerno/tmp/jcvs3-install2
export RELATIVE_WORKAREA_DIRECTORY=workarea
export CLASSPATH=${JAVA_HOME}/jre/lib/rt.jar:${MY_JCVS3_INSTALL_DIR}/${RELATIVE_WORKAREA_DIRECTORY}:${MY_JCVS3_INSTALL_DIR}/classes:${MY_JCVS3_INSTALL_DIR}/lib/jcvs3.jar:${MY_JCVS3_INSTALL_DIR}/lib/activation.jar:${MY_JCVS3_INSTALL_DIR}/lib/jh.jar
${JAVA_HOME}/jre/bin/java                       \
-DinstallDir=${MY_JCVS3_INSTALL_DIR}            \
-DrelClassDir=${RELATIVE_WORKAREA_DIRECTORY}    \
$1
</demo_runner_template>

This will work assuming you have the following directory structure:
/home/jsalerno/tmp/jcvs3-install2/lib/jcvs3.jar
/home/jsalerno/tmp/jcvs3-install2/workarea/
/home/jsalerno/tmp/jcvs3-install2/workarea/com/ice/config/demo/<.properties files>
/home/jsalerno/tmp/jcvs3-install2/workarea/com/ice/config/demo/images/<image files>
(And this should be the case if you extracted the jcvs3.zip archive into /home/jsalerno/tmp/jcvs3-install2/).

All you need to do then, is edit 3 lines in your version of 'demo_runner.sh':

Edit a single line in the file 'demo_runner.sh' to reflect the JAVA installation path.
...something like : 
	export JAVA_HOME=/usr/local/jdk1.3.1_01 

Edit a single line in the file 'demo_runner.sh' to reflect the Configurator installation path (in this case the 'configurator' is notionally the JCVS application).
...something like : 
	export MY_JCVS3_INSTALL_DIR=/home/jsalerno/tmp/jcvs3-install2 

Edit a single line in the file 'demo_runner.sh' to reflect the relative path to the directory containing your application's resources identified above.
...something like : 
	export RELATIVE_WORKAREA_DIRECTORY=workarea 

Your demo_runner.sh script file should now show (omit XML tags - here for illustrative purposes only):

<my_demo_runner>
export JAVA_HOME=/usr/local/jdk1.3.1_01
export MY_JCVS3_INSTALL_DIR=/home/jsalerno/tmp/jcvs3-install2
export RELATIVE_WORKAREA_DIRECTORY=workarea
export CLASSPATH=${JAVA_HOME}/jre/lib/rt.jar:${MY_JCVS3_INSTALL_DIR}/${RELATIVE_WORKAREA_DIRECTORY}:${MY_JCVS3_INSTALL_DIR}/classes:${MY_JCVS3_INSTALL_DIR}/lib/jcvs3.jar:${MY_JCVS3_INSTALL_DIR}/lib/activation.jar:${MY_JCVS3_INSTALL_DIR}/lib/jh.jar
${JAVA_HOME}/jre/bin/java                       \
-DinstallDir=${MY_JCVS3_INSTALL_DIR}            \
-DrelClassDir=workarea                     	\
$1
</my_demo_runner>

Then, you can simply invoke the demo scripts:
* run_demo1.sh
* run_demo2.sh
* run_demo2a.sh
* jcvsii.sh - this script runs the *original* jCVS-5.2.2-style functionality out of the new codebase.

KNOWN BUGS
There are some minor issues with tuple-table and string-array editor components when using the INSERT and APPEND button functions.
We'll get a fix done soon.

There is unusual behaviour (on Linux Red Hat 6.1 and Sun JVM 1.3.1_01, at least) with the Font editor.
It seems that the names returned in the Font lists don't map especially well to prior selections.
Haven't had time to look at it closely yet, so you may see "Save ?" dialogs if you have selected a property which uses a 'font' editor.

Julian
