#!/bin/sh
ulimit -s 2048
export JAVA_HOME=/usr/local/jdk1.3.1_01
export MY_JCVS3_INSTALL_DIR=/home/jsalerno/tmp/jcvs3-install2
export RELATIVE_WORKAREA_DIRECTORY=workarea
export CLASSPATH=${JAVA_HOME}/jre/lib/rt.jar:${MY_JCVS3_INSTALL_DIR}/${RELATIVE_WORKAREA_DIRECTORY}:${MY_JCVS3_INSTALL_DIR}/lib/jcvs3.jar:${MY_JCVS3_INSTALL_DIR}/lib/activation.jar:${MY_JCVS3_INSTALL_DIR}/lib/jh.jar
${JAVA_HOME}/jre/bin/java 		   	\
-DinstallDir=${MY_JCVS3_INSTALL_DIR}            \
-DrelClassDir=${RELATIVE_WORKAREA_DIRECTORY}    \
$1
