#!/bin/sh
export PATH=${PATH}:.

exec demo_runner.sh \
com.ice.config.demo.DemoConfigurator2A ?
